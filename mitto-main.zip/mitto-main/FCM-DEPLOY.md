# Atualização FCM do backend Mitto

O APK registra o token do dispositivo em `POST /api/push-token`. O backend envia push pelo Firebase Cloud Messaging para mensagens novas e chamadas recebidas.

## Variável obrigatória no servidor

Configure no Railway (ou no ambiente que executa o `server.js`) a variável:

```text
FIREBASE_SERVICE_ACCOUNT_JSON=<conteúdo completo do JSON da service account mitto-fcm-sender>
```

Alternativamente, use `GOOGLE_APPLICATION_CREDENTIALS` apontando para um arquivo JSON disponível somente no servidor. Nunca coloque essa credencial no APK, no frontend ou no Git.

Depois de publicar esta versão do `server.js` e instalar o `package-lock.json`, o domínio deverá responder ao endpoint `POST /api/push-token` em vez de `404`.
