let usuarioAtual = null;
let chatAtualId = null;
let chatAtualTipo = null; // 'private' | 'group'
let chatAtualOutro = null; // { id, username, email, photoUrl } do outro usuário (só em chat privado)
let chatAtualRemovido = false; // true quando o usuário foi removido desse grupo (modo fantasma: só leitura)
let chatAtualModoEnvio = 'todos'; // 'todos' | 'admins' | 'dono' — quem pode mandar mensagem no grupo atual
let chatAtualSouAdmin = false;
let chatAtualSouDono = false;
let chatAtualMembros = []; // [{id, username, photoUrl}] só quando o chat aberto é um grupo — usado nas sugestões de @menção
let mencaoAtiva = null; // { inicio, fim } = posição do "@algo" que está sendo digitado no input, ou null se não tem popup aberto
let respondendoA = null; // { id, userId, userName, snippet } da mensagem sendo respondida
let mensagensCacheAtual = new Map(); // msg.id -> msg, só do chat aberto no momento (pra montar a citação da resposta)
let socket = null;
let contatoDigitando = new Set();
let typingStopTimer = null;
let gravador = null;
let chunksGravacao = [];
let tipoGravando = null;
let filtroConversas = 'todas'; // 'todas' | 'grupo' | 'arquivadas'
let todasAsConversas = []; // cache da última lista carregada
let conversasArquivadasTotal = 0;
let preferenciasChatAtual = { mutedUntil: null, pinned: false, ephemeral: null };
let altaQualidadeAtual = false;
let tokenPushPendente = null;
let tentativasTokenPush = 0;

async function registrarTokenPush(token) {
  if (!token) return;
  tokenPushPendente = String(token);
  if (!usuarioAtual || !usuarioAtual.id) return;
  try {
    const resp = await fetch('/api/push-token', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id, token: tokenPushPendente })
    });
    if (resp.ok) { tokenPushPendente = null; tentativasTokenPush = 0; }
    else if (tentativasTokenPush++ < 6) setTimeout(() => registrarTokenPush(token), 8000);
  } catch (_) { if (tentativasTokenPush++ < 6) setTimeout(() => registrarTokenPush(token), 8000); }
}
window.mittoNativePushToken = registrarTokenPush;

// ---------- Controle de telas ----------
function mostrarTela(nome) {
  document.querySelectorAll('.screen').forEach(el => el.classList.add('oculto'));
  document.getElementById(nome + '-screen').classList.remove('oculto');
  if ((nome === 'login' || nome === 'cadastro') && window.google?.accounts?.id) setTimeout(() => entrarComGoogle().catch(() => {}), 80);
}

// ---------- Navegação mobile (lista de conversas <-> conteúdo principal) ----------
// No celular não cabe sidebar + área principal lado a lado, então elas viram
// duas "telas" cheias controladas por essa classe (ver style.css). No PC essa
// classe não tem efeito nenhum, o layout continua lado a lado como sempre foi.
function mostrarHomeMobile() {
  const shell = document.getElementById('chat-screen');
  if (!shell) return;

  shell.classList.add('mobile-home');
  shell.classList.remove('mostrar-main');
}

function mostrarPainelMobile() {
  const shell = document.getElementById('chat-screen');
  if (!shell) return;

  shell.classList.remove('mobile-home');
  shell.classList.add('mostrar-main');
}

function mostrarListaMobile() {
  const shell = document.getElementById('chat-screen');
  if (!shell) return;

  shell.classList.remove('mobile-home', 'mostrar-main');
}

// ---------- Inicialização ----------
window.onload = () => {
  setTimeout(() => {
    const salvo = localStorage.getItem('usuario');
    if (salvo) {
      usuarioAtual = JSON.parse(salvo);
      entrarNoChat();
    } else {
      mostrarTela('login');
    }
  }, 1700); // tempo da barra de progresso
};

// ---------- Contas (trocar sem logar de novo) ----------
function carregarContas() {
  try { return JSON.parse(localStorage.getItem('contas') || '[]'); }
  catch (e) { return []; }
}
function salvarConta(usuario) {
  usuarioAtual = usuario;
  localStorage.setItem('usuario', JSON.stringify(usuario));
  const resumo = { id: usuario.id, username: usuario.username, email: usuario.email, photoUrl: usuario.photoUrl || null };
  const contas = carregarContas().filter(c => c.id !== usuario.id);
  contas.unshift(resumo);
  localStorage.setItem('contas', JSON.stringify(contas));
}
function garantirContaNaLista() {
  if (!usuarioAtual) return;
  const contas = carregarContas();
  if (!contas.find(c => c.id === usuarioAtual.id)) {
    contas.unshift({ id: usuarioAtual.id, username: usuarioAtual.username, email: usuarioAtual.email, photoUrl: usuarioAtual.photoUrl || null });
    localStorage.setItem('contas', JSON.stringify(contas));
  }
}

function abrirTrocaConta() {
  renderContasDropdown();
  alternarDropdown('menu-contas');
}

function renderContasDropdown() {
  const contas = carregarContas();
  const el = document.getElementById('menu-contas');
  const linhas = contas.map(c => {
    const ativa = usuarioAtual && c.id === usuarioAtual.id;
    return `
      <div class="dropdown-item dropdown-clicavel conta-item ${ativa ? 'conta-ativa' : ''}" onclick="${ativa ? '' : `trocarConta('${c.id}')`}">
        <span class="conta-info">
          <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(c.username, c.photoUrl)}</span>
          <span>${escapeHtml(c.username)}</span>
        </span>
        ${ativa
          ? '<span class="conta-check">✓</span>'
          : `<span class="conta-remover" onclick="removerConta('${c.id}', event)" title="Remover da lista">✕</span>`}
      </div>`;
  }).join('');

  el.innerHTML = linhas + `
    <div class="dropdown-item dropdown-clicavel" onclick="adicionarConta()">
      <span>+ Adicionar conta</span>
    </div>`;
}

function trocarConta(id) {
  const contas = carregarContas();
  const conta = contas.find(c => c.id === id);
  if (!conta) return;
  localStorage.setItem('usuario', JSON.stringify(conta));
  location.reload();
}

function removerConta(id, event) {
  event.stopPropagation();
  const contas = carregarContas().filter(c => c.id !== id);
  localStorage.setItem('contas', JSON.stringify(contas));
  if (usuarioAtual && usuarioAtual.id === id) {
    sair();
    return;
  }
  renderContasDropdown();
}

function adicionarConta() {
  document.getElementById('menu-contas').classList.add('oculto');
  if (socket) { socket.disconnect(); socket = null; }
  mostrarTela('login');
}

function esqueceuSenha() {
  mostrarAviso('Para mudar sua senha, entre na conta e use Configurações > Segurança da conta.');
}

async function abrirMudarSenha() {
  const valores = await abrirModal({ titulo: 'Mudar senha', textoBotao: 'Salvar senha', campos: [
    { id: 'atual', label: 'Senha atual', placeholder: 'Digite a senha atual', tipoInput: 'password' },
    { id: 'nova', label: 'Nova senha', placeholder: 'Mínimo de 8 caracteres', tipoInput: 'password' }
  ] });
  if (!valores || !valores.atual || !valores.nova) return;
  try {
    const resp = await fetch('/api/change-password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: usuarioAtual.id, currentPassword: valores.atual, newPassword: valores.nova }) });
    const data = await resp.json();
    mostrarAviso(data.message || data.error || 'Não foi possível mudar a senha.', resp.ok ? 'sucesso' : 'erro');
  } catch (_) { mostrarAviso('Falha de conexão ao mudar a senha.'); }
}

// ---------- Avisos (substituem os alert() feios) ----------
function mostrarAviso(mensagem, tipo) {
  const el = document.createElement('div');
  el.className = 'toast toast-' + (tipo || 'erro');
  el.textContent = mensagem;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('mostrar'));
  setTimeout(() => {
    el.classList.remove('mostrar');
    setTimeout(() => el.remove(), 250);
  }, 3500);
}

// ---------- Modal (substitui os prompt() feios) ----------
function abrirModal({ titulo, campos, textoBotao }) {
  return new Promise(resolve => {
    const root = document.getElementById('modal-root');

    const camposHtml = campos.map(c => `
      <label class="modal-label">${escapeHtml(c.label)}
        ${c.tipo === 'textarea'
          ? `<textarea class="modal-input" id="modal-campo-${c.id}" rows="3" placeholder="${escapeHtml(c.placeholder || '')}">${escapeHtml(c.valor || '')}</textarea>`
          : `<input class="modal-input" id="modal-campo-${c.id}" type="${c.tipoInput || 'text'}" placeholder="${escapeHtml(c.placeholder || '')}" value="${escapeHtml(c.valor || '')}">`}
      </label>`).join('');

    root.innerHTML = `
      <div class="modal-overlay" id="modal-overlay">
        <div class="modal-box">
          <h3 class="modal-title">${escapeHtml(titulo)}</h3>
          ${camposHtml}
          <div class="modal-actions">
            <button class="btn-outline btn-compacto" id="modal-cancelar" type="button">Cancelar</button>
            <button class="btn-ok btn-compacto" id="modal-confirmar" type="button">${escapeHtml(textoBotao)}</button>
          </div>
        </div>
      </div>`;

    const overlay = document.getElementById('modal-overlay');
    const fechar = valor => { root.innerHTML = ''; resolve(valor); };

    document.getElementById('modal-cancelar').onclick = () => fechar(null);
    overlay.onclick = e => { if (e.target === overlay) fechar(null); };
    document.addEventListener('keydown', function escFecha(e) {
      if (e.key === 'Escape') { document.removeEventListener('keydown', escFecha); fechar(null); }
    });

    document.getElementById('modal-confirmar').onclick = () => {
      const valores = {};
      campos.forEach(c => { valores[c.id] = document.getElementById(`modal-campo-${c.id}`).value.trim(); });
      fechar(valores);
    };

    const primeiroInput = root.querySelector('.modal-input');
    if (primeiroInput) {
      primeiroInput.focus();
      primeiroInput.addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') document.getElementById('modal-confirmar').click();
      });
    }
  });
}

// ---------- Perguntas e confirmações bonitas (substituem prompt() e confirm() do navegador) ----------
async function perguntarModal(titulo, label, valor, opcoes) {
  const o = opcoes || {};
  const r = await abrirModal({
    titulo, textoBotao: o.botao || 'Confirmar',
    campos: [{ id: 'valor', label, valor: valor || '', placeholder: o.placeholder || '', tipoInput: o.senha ? 'password' : 'text' }]
  });
  return r ? r.valor : null;
}
function confirmarModal(titulo, mensagem, opcoes) {
  const o = opcoes || {};
  return new Promise(resolve => {
    const root = document.getElementById('modal-root');
    root.innerHTML = `
      <div class="modal-overlay" id="modal-overlay">
        <div class="modal-box">
          <h3 class="modal-title">${escapeHtml(titulo)}</h3>
          ${mensagem ? `<p class="modal-texto">${escapeHtml(mensagem)}</p>` : ''}
          <div class="modal-actions">
            <button class="btn-outline btn-compacto" id="modal-cancelar" type="button">${escapeHtml(o.nao || 'Cancelar')}</button>
            <button class="btn-ok btn-compacto" id="modal-confirmar" type="button">${escapeHtml(o.sim || 'Confirmar')}</button>
          </div>
        </div>
      </div>`;
    const overlay = document.getElementById('modal-overlay');
    const fechar = v => { document.removeEventListener('keydown', esc); root.innerHTML = ''; resolve(v); };
    const esc = e => { if (e.key === 'Escape') fechar(false); };
    document.addEventListener('keydown', esc);
    document.getElementById('modal-cancelar').onclick = () => fechar(false);
    document.getElementById('modal-confirmar').onclick = () => fechar(true);
    overlay.onclick = e => { if (e.target === overlay) fechar(false); };
    document.getElementById('modal-confirmar').focus();
  });
}
// Avisa o servidor se a tela está visível e qual conversa está aberta (o servidor não manda push de quem já está lendo).
function informarTelaVisivel() {
  if (typeof socket === 'undefined' || !socket || !socket.connected) return;
  socket.emit('app:foreground', { visible: document.visibilityState === 'visible', chatId: chatAtualId || null });
}
function fecharMenuLigar() {
  document.getElementById('menu-ligar')?.classList.add('oculto');
  document.getElementById('btn-call-menu')?.setAttribute('aria-expanded', 'false');
}

// ---------- Configurações (tema, fundo, fonte, negrito, cor das msgs) ----------
const CONFIG_PADRAO = { tema: 'dark', fundo: 'nenhum', fonte: 'inter', negrito: false, cor: 'ambar', destaque: 'verde', degradê: 'nenhum', notificacoes: { mensagens: true, sons: true, chamadas: true, grupos: true } };

function carregarConfig() {
  try {
    return Object.assign({}, CONFIG_PADRAO, JSON.parse(localStorage.getItem('config') || '{}'));
  } catch (e) {
    return Object.assign({}, CONFIG_PADRAO);
  }
}
function salvarConfig(config) {
  localStorage.setItem('config', JSON.stringify(config));
}
function aplicarConfig(config) {
  const html = document.documentElement;
  const paletas = { verde:['#a3e635','#84cc16','#17210a'], azul:['#60a5fa','#3b82f6','#081a32'], amarelo:['#facc15','#eab308','#2a2105'], roxo:['#c084fc','#9333ea','#210b35'], rosa:['#fb7185','#e11d48','#300b16'], ciano:['#22d3ee','#0891b2','#062a31'], laranja:['#fb923c','#ea580c','#321506'], vermelho:['#f87171','#dc2626','#310909'], branco:['#f1f5f9','#cbd5e1','#17191d'], menta:['#6ee7b7','#10b981','#06271b'] };
  const paleta = paletas[config.destaque] || paletas.verde;
  html.style.setProperty('--accent', paleta[0]); html.style.setProperty('--accent-text', paleta[0]); html.style.setProperty('--accent-dim', paleta[1]); html.style.setProperty('--accent-contrast', paleta[2]);
  const gradientes = { nenhum:'none', aurora:'linear-gradient(135deg, rgba(34,211,238,.12), transparent 38%, rgba(192,132,252,.14) 72%, transparent)', neon:'linear-gradient(120deg, rgba(163,230,53,.15), transparent 42%, rgba(34,211,238,.12))', porDoSol:'linear-gradient(135deg, rgba(251,113,133,.16), transparent 45%, rgba(250,204,21,.13))', oceano:'linear-gradient(135deg, rgba(59,130,246,.18), transparent 50%, rgba(34,211,238,.12))', doce:'linear-gradient(135deg, rgba(192,132,252,.18), transparent 48%, rgba(251,113,133,.12))' };
  html.style.setProperty('--site-gradient', gradientes[config['degradê']] || 'none');
  html.dataset.degrade = config['degradê'] || 'nenhum';
  html.setAttribute('data-theme', config.tema);
  html.setAttribute('data-fundo', config.fundo);
  html.setAttribute('data-fonte', config.fonte);
  html.setAttribute('data-negrito', config.negrito ? '1' : '0');
  html.setAttribute('data-cor-enviada', config.cor);
}
function definirNotificacao(chave, valor) {
  const config = carregarConfig(); config.notificacoes = Object.assign({ mensagens:true, sons:true, chamadas:true, grupos:true }, config.notificacoes || {}); config.notificacoes[chave] = !!valor; salvarConfig(config); aplicarConfig(config); renderConfigModal();
}
async function salvarPrivacidadePessoal(chave, valor) {
  if (!usuarioAtual?.id) return;
  try {
    const resp = await fetch(`/api/users/${encodeURIComponent(usuarioAtual.id)}/status`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ [chave]: !!valor })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Falha');
    usuarioAtual = Object.assign(usuarioAtual, data.user || {}, { [chave]: !!valor });
    localStorage.setItem('usuario', JSON.stringify(usuarioAtual));
    mostrarAviso('Privacidade atualizada.', 'sucesso');
  } catch (_) { mostrarAviso('Não foi possível salvar essa privacidade.'); renderConfigModal(); }
}
async function solicitarNotificacoesSistema() {
  if (!('Notification' in window)) return mostrarAviso('O navegador do dispositivo não oferece notificações web.');
  const permission = await Notification.requestPermission();
  mostrarAviso(permission === 'granted' ? 'Notificações autorizadas.' : 'Notificações não autorizadas.', permission === 'granted' ? 'sucesso' : 'erro');
}
async function diagnosticarPush() {
  if (!usuarioAtual?.id) return;
  try {
    const r = await fetch(`/api/push-status?userId=${encodeURIComponent(usuarioAtual.id)}`, { cache: 'no-store' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Falha');
    if (!d.firebaseConfigured) return mostrarAviso('O servidor está sem as credenciais do Firebase.', 'erro');
    if (!d.tokenCount) return mostrarAviso('O servidor ainda não recebeu o token deste aparelho.', 'erro');
    mostrarAviso(`Push conectado: ${d.tokenCount} aparelho(s) registrado(s).`, 'sucesso');
  } catch (_) { mostrarAviso('Não foi possível consultar o diagnóstico de notificações.'); }
}
const CHATS_TRANCADOS_KEY = 'mitto_chats_trancados_v1';
function chatsTrancados() { try { return JSON.parse(localStorage.getItem(CHATS_TRANCADOS_KEY) || '[]'); } catch (_) { return []; } }
async function alternarTrancaConversa(chatId) {
  const ids = chatsTrancados();
  if (ids.includes(chatId)) { const esperado = localStorage.getItem('mitto_chat_pin_' + chatId); const digitado = await perguntarModal('Destrancar conversa', 'Digite o PIN desta conversa', '', { senha: true, botao: 'Destrancar' }); if (digitado === null) return; if (digitado !== esperado) { mostrarAviso('PIN incorreto.'); return; } localStorage.setItem(CHATS_TRANCADOS_KEY, JSON.stringify(ids.filter(id => id !== chatId))); localStorage.removeItem('mitto_chat_pin_' + chatId); carregarListaChats(); mostrarAviso('Conversa destrancada neste dispositivo.'); return; }
  const senha = await perguntarModal('Trancar conversa', 'Crie um PIN de 4 a 12 caracteres', '', { senha: true, botao: 'Trancar' });
  if (senha === null) return; if (!senha || senha.length < 4 || senha.length > 12) { mostrarAviso('PIN inválido. Use de 4 a 12 caracteres.'); return; }
  localStorage.setItem('mitto_chat_pin_' + chatId, senha); localStorage.setItem(CHATS_TRANCADOS_KEY, JSON.stringify([...ids, chatId])); if (chatAtualId === chatId) voltarHome(); carregarListaChats(); mostrarAviso('Conversa trancada neste dispositivo.');
}

function definirConfig(chave, valor) {
  const config = carregarConfig();
  config[chave] = valor;
  salvarConfig(config);
  aplicarConfig(config);
  renderConfigModal();
}

function abrirConfiguracoes() {
  document.getElementById('menu-conta').classList.add('oculto');
  renderConfigModal();
}

async function abrirBloqueados() {
  document.getElementById('menu-conta').classList.add('oculto');
  await renderBloqueadosModal();
}

async function renderBloqueadosModal() {
  const resp = await fetch('/api/blocks?userId=' + usuarioAtual.id);
  const data = await resp.json();
  const root = document.getElementById('modal-root');

  const linhas = (data.bloqueados || []).length
    ? data.bloqueados.map(u => `
        <div class="dropdown-item conta-item">
          <span class="conta-info">
            <span class="avatar-circle avatar-circle--sm">${escapeHtml(u.username.charAt(0).toUpperCase())}</span>
            <span>${escapeHtml(u.username)}</span>
          </span>
          <button class="btn-outline btn-compacto" onclick="desbloquearDoModal('${u.id}')">Desbloquear</button>
        </div>`).join('')
    : '<p class="modal-texto">Você não bloqueou ninguém.</p>';

  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box">
        <h3 class="modal-title">Usuários bloqueados</h3>
        <div class="lista-contatos">${linhas}</div>
        <div class="modal-actions">
          <button class="btn-ok btn-compacto" id="modal-fechar-bloqueados" type="button">Fechar</button>
        </div>
      </div>
    </div>`;

  document.getElementById('modal-fechar-bloqueados').onclick = () => { root.innerHTML = ''; };
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') root.innerHTML = ''; };
}

async function desbloquearDoModal(blockedId) {
  await fetch('/api/unblock', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, blockedId })
  });
  renderBloqueadosModal();
}

function renderConfigModal() {
  const c = carregarConfig();
  const root = document.getElementById('modal-root');
  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box modal-config">
        <h3 class="modal-title"><i class="mdi mdi-cog-outline"></i> Configurações</h3>
        <div class="config-grupo config-security-card"><span class="config-label"><i class="mdi mdi-lock-outline"></i> Segurança da conta</span><button class="btn-outline btn-compacto" type="button" onclick="abrirMudarSenha()"><i class="mdi mdi-lock-reset"></i> Mudar senha</button></div>

        <div class="config-grupo">
          <span class="config-label">Tema</span>
          <div class="swatches">
            <button class="swatch-tema swatch-dark ${c.tema === 'dark' ? 'ativo' : ''}" onclick="definirConfig('tema','dark')" title="Grafite premium" aria-label="Tema grafite"></button>
            <button class="swatch-tema swatch-light ${c.tema === 'light' ? 'ativo' : ''}" onclick="definirConfig('tema','light')" title="Claro" aria-label="Tema claro"></button>
            <button class="swatch-tema swatch-amoled ${c.tema === 'amoled' ? 'ativo' : ''}" onclick="definirConfig('tema','amoled')" title="Preto AMOLED" aria-label="Tema AMOLED"></button>
            <button class="swatch-tema swatch-midnight ${c.tema === 'midnight' ? 'ativo' : ''}" onclick="definirConfig('tema','midnight')" title="Meia-noite" aria-label="Tema meia-noite"></button>
            <button class="swatch-tema swatch-ocean ${c.tema === 'ocean' ? 'ativo' : ''}" onclick="definirConfig('tema','ocean')" title="Oceano" aria-label="Tema oceano"></button>
            <button class="swatch-tema swatch-violet ${c.tema === 'violet' ? 'ativo' : ''}" onclick="definirConfig('tema','violet')" title="Violeta" aria-label="Tema violeta"></button>
            <button class="swatch-tema swatch-forest ${c.tema === 'forest' ? 'ativo' : ''}" onclick="definirConfig('tema','forest')" title="Floresta" aria-label="Tema floresta"></button>
          </div>
        </div>

        <div class="config-grupo">
          <span class="config-label">Cor principal do aplicativo</span>
          <div class="swatches swatches-paleta">
            ${[['verde','Verde','#a3e635'],['azul','Azul','#60a5fa'],['amarelo','Amarelo','#facc15'],['roxo','Roxo','#c084fc'],['rosa','Rosa','#fb7185'],['ciano','Ciano','#22d3ee'],['laranja','Laranja','#fb923c'],['vermelho','Vermelho','#f87171'],['branco','Prata','#f1f5f9'],['menta','Menta','#6ee7b7']].map(([v,n,col]) => `<button class="swatch-cor ${c.destaque===v?'ativo':''}" style="background:${col}" onclick="definirConfig('destaque','${v}')" title="${n}" aria-label="Cor principal ${n}"></button>`).join('')}
          </div>
        </div>
        <div class="config-grupo">
          <span class="config-label">Degradê do aplicativo</span>
          <div class="swatches swatches-degrade">
            ${[['nenhum','Padrão','linear-gradient(135deg,#161922,#0d0f14)'],['aurora','Aurora','linear-gradient(135deg,#22d3ee,#c084fc)'],['neon','Neon','linear-gradient(135deg,#a3e635,#22d3ee)'],['porDoSol','Pôr do sol','linear-gradient(135deg,#fb7185,#facc15)'],['oceano','Oceano','linear-gradient(135deg,#3b82f6,#22d3ee)'],['doce','Doce','linear-gradient(135deg,#c084fc,#fb7185)']].map(([v,n,bg])=>`<button class="chip chip-degrade ${c['degradê']===v?'ativo':''}" style="--preview-gradient:${bg}" onclick="definirConfig('degradê','${v}')">${n}</button>`).join('')}
          </div>
        </div>
        <div class="config-grupo">
          <span class="config-label">Notificações neste dispositivo</span>
          ${[['mensagens','Mensagens'],['sons','Sons de notificação'],['chamadas','Chamadas'],['grupos','Atividade em grupos']].map(([k,n])=>`<label class="config-notif"><span>${n}</span><input type="checkbox" ${c.notificacoes?.[k]!==false?'checked':''} onchange="definirNotificacao('${k}',this.checked)"></label>`).join('')}
          <button class="btn-outline btn-compacto config-permission-btn" type="button" onclick="solicitarNotificacoesSistema()"><i class="mdi mdi-bell-check-outline"></i> Autorizar notificações do sistema</button><button class="btn-outline btn-compacto config-permission-btn" type="button" onclick="diagnosticarPush()"><i class="mdi mdi-connection"></i> Diagnosticar push</button>
        </div>

        <div class="config-grupo">
          <span class="config-label"><i class="mdi mdi-shield-lock-outline"></i> Privacidade pessoal</span>
          <label class="config-notif"><span>Confirmação de leitura</span><input type="checkbox" ${usuarioAtual.readReceipts !== false ? 'checked' : ''} onchange="salvarPrivacidadePessoal('readReceipts',this.checked)"></label>
          <label class="config-notif"><span>Indicador de digitação</span><input type="checkbox" ${usuarioAtual.typingVisibility !== false ? 'checked' : ''} onchange="salvarPrivacidadePessoal('typingVisibility',this.checked)"></label>
          <label class="config-notif"><span>Visto por último</span><input type="checkbox" ${usuarioAtual.lastSeenVisibility !== false ? 'checked' : ''} onchange="salvarPrivacidadePessoal('lastSeenVisibility',this.checked)"></label>
        </div>

        <div class="config-grupo config-chat-tools">
          <span class="config-label"><i class="mdi mdi-tune-variant"></i> Preferências de conversas</span>
          <p class="config-help">Defina padrões para mensagens temporárias, silenciamento, fixação, mídia HD e recursos avançados.</p>
          <div class="config-tool-actions"><button class="btn-outline btn-compacto" type="button" onclick="abrirRecursosChat()"><i class="mdi mdi-message-settings-outline"></i> Gerenciar preferências de chat</button><button class="btn-outline btn-compacto" type="button" onclick="abrirAparenciaChat()"><i class="mdi mdi-image-outline"></i> Wallpaper e aparência</button></div>
        </div>

        <div class="config-grupo">
          <span class="config-label">Fundo das conversas</span>
          <div class="swatches">
            <button class="swatch-fundo ${c.fundo === 'nenhum'   ? 'ativo' : ''}" onclick="definirConfig('fundo','nenhum')"   title="Nenhum"></button>
            <button class="swatch-fundo fundo-pontos   ${c.fundo === 'pontos'   ? 'ativo' : ''}" onclick="definirConfig('fundo','pontos')"   title="Pontilhado"></button>
            <button class="swatch-fundo fundo-diagonal ${c.fundo === 'diagonal' ? 'ativo' : ''}" onclick="definirConfig('fundo','diagonal')" title="Diagonal"></button>
            <button class="swatch-fundo fundo-bolhas   ${c.fundo === 'bolhas'   ? 'ativo' : ''}" onclick="definirConfig('fundo','bolhas')"   title="Bolhas"></button>
            <button class="swatch-fundo fundo-aurora   ${c.fundo === 'aurora'   ? 'ativo' : ''}" onclick="definirConfig('fundo','aurora')"   title="Aurora"></button>
            <button class="swatch-fundo fundo-grade    ${c.fundo === 'grade'    ? 'ativo' : ''}" onclick="definirConfig('fundo','grade')"    title="Grade"></button>
            <button class="swatch-fundo fundo-hexagono ${c.fundo === 'hexagono' ? 'ativo' : ''}" onclick="definirConfig('fundo','hexagono')" title="Hexágono"></button>
            <button class="swatch-fundo fundo-nuvens   ${c.fundo === 'nuvens'   ? 'ativo' : ''}" onclick="definirConfig('fundo','nuvens')"   title="Nuvens"></button>
            <button class="swatch-fundo fundo-noise    ${c.fundo === 'noise'    ? 'ativo' : ''}" onclick="definirConfig('fundo','noise')"    title="Granulado"></button>
            <button class="swatch-fundo fundo-ondas    ${c.fundo === 'ondas'    ? 'ativo' : ''}" onclick="definirConfig('fundo','ondas')"    title="Ondas"></button>
          </div>
        </div>

        <div class="config-grupo">
          <span class="config-label">Fonte</span>
          <div class="swatches">
            <button class="chip ${c.fonte === 'inter' ? 'ativo' : ''}" onclick="definirConfig('fonte','inter')">Padrão</button>
            <button class="chip ${c.fonte === 'sistema' ? 'ativo' : ''}" onclick="definirConfig('fonte','sistema')">Sistema</button>
          </div>
        </div>

        <div class="config-grupo config-linha">
          <span class="config-label">Negrito</span>
          <button class="switch ${c.negrito ? 'ativo' : ''}" onclick="definirConfig('negrito', ${!c.negrito})" aria-label="Alternar negrito"></button>
        </div>

        <div class="config-grupo">
          <span class="config-label">Cor das suas mensagens</span>
          <div class="swatches">
            <button class="swatch-cor cor-ambar ${c.cor === 'ambar' ? 'ativo' : ''}" onclick="definirConfig('cor','ambar')" title="Âmbar"></button>
            <button class="swatch-cor cor-azul ${c.cor === 'azul' ? 'ativo' : ''}" onclick="definirConfig('cor','azul')" title="Azul"></button>
            <button class="swatch-cor cor-verde ${c.cor === 'verde' ? 'ativo' : ''}" onclick="definirConfig('cor','verde')" title="Verde"></button>
          </div>
        </div>

        <div class="modal-actions">
          <button class="btn-ok btn-compacto" id="modal-fechar-config" type="button">Fechar</button>
        </div>
      </div>
    </div>`;

  document.getElementById('modal-fechar-config').onclick = () => { root.innerHTML = ''; };
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') root.innerHTML = ''; };
}

// ---------- Menus (⋮) ----------
function alternarDropdown(id) {
  document.querySelectorAll('.dropdown-menu').forEach(el => {
    if (el.id !== id) el.classList.add('oculto');
  });
  const menu = document.getElementById(id);
  if (!menu) return;
  const abrir = menu.classList.contains('oculto');
  menu.classList.toggle('oculto', !abrir);
  const trigger = menu.closest('.dropdown-wrap')?.querySelector('button');
  if (trigger) trigger.setAttribute('aria-expanded', String(abrir));
}
document.addEventListener('click', e => {
  if (!e.target.closest('.dropdown-wrap')) {
    document.querySelectorAll('.dropdown-menu').forEach(el => el.classList.add('oculto'));
  }
});

function filtrarConversas(tipo) {
  filtroConversas = tipo;
  document.getElementById('menu-busca')?.classList.add('oculto');
  carregarListaChats();
}

async function arquivarConversa(chatId, archived = true) {
  if (!usuarioAtual || !chatId) return;
  try {
    const resp = await fetch(`/api/chats/${encodeURIComponent(chatId)}/archive`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id, archived: !!archived })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Não foi possível atualizar o arquivo.');
    mostrarAviso(archived ? 'Conversa arquivada.' : 'Conversa desarquivada.', 'sucesso');
    if (chatAtualId === chatId && archived) voltarHome();
    await carregarListaChats();
  } catch (e) { mostrarAviso(e.message || 'Não foi possível arquivar a conversa.'); }
}

const CATEGORIAS_EMOJI = {"Recentes": ["❤️", "👍", "😂", "😮", "😢", "🙏", "🔥", "👏", "🎉", "💯"], "Rostos": ["😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "🥲", "☺️", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🥸", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗", "🤔", "🫣", "🤭", "🫢", "🫡", "🤫", "🫠", "🤥", "😶", "😐", "😑", "😬", "🫨", "🫥", "😴", "🥱", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "😵", "😵‍💫", "🤐", "🥴", "🤠", "🤑", "😈", "👿", "👹", "👺", "💀", "☠️", "👻", "👽", "👾", "🤖", "💩", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾"], "Gestos": ["👋", "🤚", "🖐️", "✋", "🖖", "🫱", "🫲", "🫳", "🫴", "🫷", "🫸", "👌", "🤌", "🤏", "✌️", "🤞", "🫰", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👍", "👎", "✊", "👊", "🤛", "🤜", "👏", "🙌", "🫶", "👐", "🤲", "🤝", "🙏", "✍️", "💅", "🤳", "💪", "🦾", "🦿", "🦵", "🦶", "👂", "🦻", "👃", "👀", "👁️", "👅", "👄", "🫦"], "Coracoes": ["❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❤️‍🔥", "❤️‍🩹", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "❣️", "💌", "💋"], "Objetos": ["💯", "💢", "💥", "💫", "💦", "💨", "🕳️", "💣", "💬", "👁️‍🗨️", "🗨️", "🗯️", "💭", "💤", "🎉", "🎊", "🎈", "🎁", "✨", "⭐", "🌟", "🔥", "🌈", "☀️", "🌙", "⚡", "❄️", "☃️", "🌸", "🌹", "🌻", "🍀", "🏆", "🥇", "🎮", "🎯", "🚀", "💎", "🎵", "🎶", "📌", "📎", "🔗", "💡", "📷", "🎬", "🎤", "🎧", "📱", "💻", "⌚", "🔒", "🔑"], "Animais": ["🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐻‍❄️", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🙈", "🙉", "🙊", "🐔", "🐧", "🐦", "🐤", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🪱", "🦋", "🐌", "🐞", "🐜", "🪰", "🪲", "🦟", "🦗", "🕷️", "🦂", "🐢", "🐍", "🦎", "🦖", "🦕", "🐙", "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳", "🦈", "🐊", "🐅", "🐆", "🦓", "🦍", "🦧", "🐘", "🦛", "🦏", "🐪", "🐫", "🦒", "🦘", "🦬", "🐃", "🐂", "🐄", "🐎", "🐖", "🐏", "🐑", "🦙", "🐐", "🦌", "🐕", "🐩", "🦮", "🐈", "🐓", "🦃", "🦚", "🦜", "🦢", "🦩", "🕊️", "🐇", "🦝", "🦨", "🦡", "🦦", "🦥", "🐁", "🐀", "🐿️", "🦔"], "Comida": ["🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🍆", "🥑", "🥦", "🥬", "🥒", "🌶️", "🫑", "🌽", "🥕", "🫒", "🧄", "🧅", "🥔", "🍠", "🥐", "🥯", "🍞", "🥖", "🥨", "🧀", "🥚", "🍳", "🧈", "🥞", "🧇", "🥓", "🥩", "🍗", "🍖", "🌭", "🍔", "🍟", "🍕", "🫓", "🥪", "🥙", "🧆", "🌮", "🌯", "🫔", "🥗", "🥘", "🫕", "🍝", "🍜", "🍲", "🍛", "🍣", "🍱", "🥟", "🦪", "🍤", "🍙", "🍚", "🍘", "🍥", "🥠", "🥮", "🍢", "🍡", "🍧", "🍨", "🍦", "🥧", "🧁", "🍰", "🎂", "🍮", "🍭", "🍬", "🍫", "🍿", "🍩", "🍪", "🌰", "🥜", "🍯", "🥛", "🍼", "☕", "🫖", "🍵", "🧃", "🥤", "🧋", "🍶", "🍺", "🍻", "🥂", "🍷", "🥃", "🍸", "🍹", "🧉"], "Viagem": ["🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑", "🚒", "🚐", "🛻", "🚚", "🚛", "🚜", "🛵", "🏍️", "🚲", "🛴", "🛹", "🛼", "🚏", "🛣️", "🛤️", "🚦", "🚥", "🚧", "⚓", "⛵", "🚤", "🛳️", "🚢", "✈️", "🛩️", "🛫", "🛬", "🚁", "🚟", "🚠", "🚡", "🛰️", "🚀", "🛸", "🌍", "🌎", "🌏", "🌋", "🗻", "🏕️", "🏖️", "🏝️", "🏜️", "🏞️", "🏟️", "🏛️", "🏗️", "🏘️", "🏠", "🏡", "🏢", "🏬", "🏥", "🏦", "🏨", "🏪", "🏫", "🏭", "🏰", "🗼", "🗽", "⛪", "🕌", "🛕", "⛩️"], "Esportes": ["⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🪃", "🥅", "⛳", "🪁", "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛹", "🛼", "🛷", "⛸️", "🥌", "🎿", "⛷️", "🏂", "🏋️", "🤼", "🤸", "⛹️", "🤺", "🏇", "🧘", "🏄", "🏊", "🤽", "🚣", "🧗", "🚵", "🚴", "🏆", "🥇", "🥈", "🥉", "🏅", "🎖️"], "Bandeiras": ["🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏳️‍⚧️", "🇧🇷", "🇵🇹", "🇺🇸", "🇬🇧", "🇯🇵", "🇰🇷", "🇨🇦", "🇦🇷", "🇲🇽", "🇫🇷", "🇩🇪", "🇮🇹", "🇪🇸", "🇨🇳", "🇮🇳", "🇷🇺", "🇺🇦", "🇦🇺", "🇳🇿", "🇿🇦", "🇦🇴", "🇲🇿", "🇨🇻", "🇬🇼", "🇹🇱", "🇸🇹", "🇹🇷", "🇸🇦", "🇦🇪", "🇮🇱", "🇪🇬", "🇳🇬", "🇰🇪", "🇨🇱", "🇨🇴", "🇵🇪", "🇺🇾", "🇵🇾", "🇧🇴", "🇻🇪", "🇪🇨", "🇨🇷", "🇵🇦", "🇨🇺", "🇩🇴", "🇭🇹", "🇯🇲", "🇵🇷", "🇹🇭", "🇻🇳", "🇮🇩", "🇵🇭", "🇲🇾", "🇸🇬", "🇹🇼", "🇭🇰", "🇵🇰", "🇧🇩", "🇳🇵", "🇱🇰", "🇮🇷", "🇮🇶", "🇬🇷", "🇳🇱", "🇧🇪", "🇨🇭", "🇦🇹", "🇸🇪", "🇳🇴", "🇩🇰", "🇫🇮", "🇵🇱", "🇨🇿", "🇸🇰", "🇭🇺", "🇷🇴", "🇧🇬", "🇭🇷", "🇷🇸", "🇸🇮", "🇮🇪", "🇮🇸", "🇱🇺", "🇲🇹", "🇨🇾", "🇪🇺"]};
const EMOJIS_REACAO_RAPIDA = CATEGORIAS_EMOJI.Recentes.slice(0,6);
const EMOJIS_COMPLETOS = [...new Set(Object.values(CATEGORIAS_EMOJI).flat())];
let seletorReacaoMsgId = null;
function obterSeletorReacaoGlobal() {
  let p = document.getElementById('reaction-picker-global');
  if (!p) {
    p = document.createElement('div');
    p.id = 'reaction-picker-global';
    p.className = 'reaction-picker';
    p.setAttribute('role', 'group');
    p.setAttribute('aria-label', 'Escolher reação');
    document.body.appendChild(p);
  }
  return p;
}
function fecharSeletoresReacao() {
  const p = document.getElementById('reaction-picker-global');
  if (p) { p.classList.remove('aberto', 'completo'); p.innerHTML = ''; }
  seletorReacaoMsgId = null;
}
// Posiciona o seletor em cima (ou embaixo) da mensagem, sempre dentro da janela.
function posicionarSeletorReacao(p, msgEl) {
  const r = msgEl.getBoundingClientRect();
  const margem = 8;
  p.style.position = 'fixed';
  p.style.bottom = 'auto';
  p.style.right = 'auto';
  p.style.visibility = 'hidden';
  p.style.left = '0px';
  p.style.top = '0px';
  const w = p.offsetWidth, h = p.offsetHeight;
  const vw = window.innerWidth, vh = window.innerHeight;
  let left = msgEl.classList.contains('minha') ? r.right - w : r.left;
  left = Math.max(margem, Math.min(left, vw - w - margem));
  let top = r.top - h - 8;
  if (top < margem) top = r.bottom + 8;
  if (top + h > vh - margem) top = Math.max(margem, Math.min(vh - h - margem, r.top + (r.height - h) / 2));
  p.style.left = left + 'px';
  p.style.top = top + 'px';
  p.style.visibility = 'visible';
}
document.addEventListener('click', e => {
  if (!e.target.closest('#reaction-picker-global')) fecharSeletoresReacao();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharSeletoresReacao(); });
window.addEventListener('resize', () => fecharSeletoresReacao());
document.addEventListener('scroll', e => {
  if (e.target instanceof Element && e.target.closest('#reaction-picker-global')) return;
  fecharSeletoresReacao();
}, true);
function abrirSeletorReacao(messageId, modo = 'completo', event) {
  if (event) { event.stopPropagation(); event.preventDefault(); }
  const msg = document.querySelector(`#mensagens [data-id="${messageId}"]`);
  if (!msg) return;
  const picker = obterSeletorReacaoGlobal();
  seletorReacaoMsgId = messageId;
  picker.classList.add('aberto');
  picker.classList.toggle('completo', modo === 'completo');
  const renderEmoji = emoji => `<button type="button" class="reaction-option" data-emoji="${escapeAttr(emoji)}" onclick="reagirMensagem('${messageId}',this.dataset.emoji,event)" aria-label="Reagir com ${escapeAttr(emoji)}" title="${escapeAttr(emoji)}">${emoji}</button>`;
  picker.innerHTML = modo === 'rapido'
    ? EMOJIS_REACAO_RAPIDA.map(renderEmoji).join('') + `<button type="button" class="reaction-option reaction-more" onclick="abrirSeletorReacao('${messageId}','completo',event)" aria-label="Todos os emojis" title="Mais emojis"><i class="mdi mdi-plus"></i></button>`
    : `<div class="reaction-picker-tools"><input class="reaction-search" type="search" placeholder="Buscar emoji…" aria-label="Buscar emoji" oninput="filtrarEmojisReacao(this.value)"><button class="reaction-close" onclick="fecharSeletoresReacao()" aria-label="Fechar">×</button></div><nav class="reaction-categories" aria-label="Categorias de emoji">${Object.keys(CATEGORIAS_EMOJI).map((nome,i)=>`<button type="button" class="reaction-category ${i===0?'ativa':''}" data-category="${escapeAttr(nome)}" onclick="selecionarCategoriaEmoji('${escapeAttr(nome)}')">${escapeHtml(nome)}</button>`).join('')}</nav><div class="reaction-grid">${EMOJIS_REACAO_RAPIDA.map(renderEmoji).join('')}</div><div class="reaction-picker-foot"><span>${EMOJIS_COMPLETOS.length} emojis · escolha uma reação</span></div>`;
  if (modo === 'completo') selecionarCategoriaEmoji('Recentes');
  posicionarSeletorReacao(picker, msg);
}
function selecionarCategoriaEmoji(nome) {
  const picker = document.getElementById('reaction-picker-global'); if (!picker) return;
  const lista = CATEGORIAS_EMOJI[nome] || EMOJIS_COMPLETOS;
  picker.querySelectorAll('.reaction-category').forEach(b => b.classList.toggle('ativa', b.dataset.category === nome));
  const grid = picker.querySelector('.reaction-grid'); if (grid) grid.innerHTML = lista.map(emoji => `<button type="button" class="reaction-option" data-emoji="${escapeAttr(emoji)}" onclick="reagirMensagem('${seletorReacaoMsgId}',this.dataset.emoji,event)" aria-label="Reagir com ${escapeAttr(emoji)}" title="${escapeAttr(emoji)}">${emoji}</button>`).join('');
}
function filtrarEmojisReacao(consulta) {
  const picker = document.getElementById('reaction-picker-global'); if (!picker) return;
  const q = String(consulta || '').trim().toLocaleLowerCase('pt-BR');
  picker.querySelectorAll('.reaction-category').forEach(b => b.classList.remove('ativa'));
  const grid = picker.querySelector('.reaction-grid'); if (!grid) return;
  const lista = q ? EMOJIS_COMPLETOS.filter(e => e.includes(q)) : (CATEGORIAS_EMOJI.Recentes || []);
  grid.innerHTML = lista.map(emoji => `<button type="button" class="reaction-option" data-emoji="${escapeAttr(emoji)}" onclick="reagirMensagem('${seletorReacaoMsgId}',this.dataset.emoji,event)" aria-label="Reagir com ${escapeAttr(emoji)}" title="${escapeAttr(emoji)}">${emoji}</button>`).join('') || '<p class="reaction-empty">Nenhum emoji encontrado.</p>';
}
function alternarSeletorReacao(messageId, event) { abrirSeletorReacao(messageId, 'completo', event); }
if (!window.__menuMsgFecharLigado) {
  window.__menuMsgFecharLigado = true;
  const fecharMenusMensagem = () => document.querySelectorAll('#mensagens .msg.menu-mensagem-aberto').forEach(n => n.classList.remove('menu-mensagem-aberto'));
  document.addEventListener('click', e => { if (!e.target.closest('#mensagens .msg')) fecharMenusMensagem(); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharMenusMensagem(); });
}
function ativarGestosMensagem(el, msg) {
  if (!el || msg.type === 'system') return;
  let timer = null, longPress = false, startX = 0, startY = 0, lastTap = 0;
  const abrirAcoes = () => { document.querySelectorAll('#mensagens .msg.menu-mensagem-aberto').forEach(n => n.classList.remove('menu-mensagem-aberto')); el.classList.add('menu-mensagem-aberto'); };
  el.addEventListener('contextmenu', e => { e.preventDefault(); abrirAcoes(); });

  // ---- PC (mouse): clicar e segurar abre o menu (sem botão visível) ----
  let mouseTimer = null, mouseX = 0, mouseY = 0;
  el.addEventListener('mousedown', e => {
    if (e.button !== 0) return;
    if (e.target.closest('button, a, video, audio, input, .conteudo-midia, .message-reactions, .acoes, .quote-box, .btn-acessar-link')) return;
    mouseX = e.clientX; mouseY = e.clientY;
    mouseTimer = setTimeout(() => { mouseTimer = null; abrirAcoes(); }, 450);
  });
  el.addEventListener('mousemove', e => {
    if (mouseTimer && (Math.abs(e.clientX - mouseX) > 6 || Math.abs(e.clientY - mouseY) > 6)) { clearTimeout(mouseTimer); mouseTimer = null; }
  });
  ['mouseup', 'mouseleave'].forEach(ev => el.addEventListener(ev, () => { clearTimeout(mouseTimer); mouseTimer = null; }));

  el.addEventListener('touchstart', e => {
    if (!e.touches || !e.touches[0]) return;
    startX = e.touches[0].clientX; startY = e.touches[0].clientY; longPress = false;
    timer = setTimeout(() => { longPress = true; abrirAcoes(); if (navigator.vibrate) navigator.vibrate(12); }, 430);
  }, { passive: true });
  el.addEventListener('touchmove', e => {
    if (!timer || !e.touches || !e.touches[0]) return;
    if (Math.abs(e.touches[0].clientX - startX) > 12 || Math.abs(e.touches[0].clientY - startY) > 12) { clearTimeout(timer); timer = null; }
  }, { passive: true });
  el.addEventListener('touchend', e => {
    clearTimeout(timer); timer = null;
    if (longPress) { e.preventDefault(); longPress = false; return; }
    const now = Date.now();
    if (now - lastTap < 320) { lastTap = 0; abrirSeletorReacao(msg.id, 'rapido', e); }
    else lastTap = now;
  }, { passive: false });
  el.addEventListener('dblclick', e => abrirSeletorReacao(msg.id, 'rapido', e));
  el.addEventListener('click', e => {
    if (e.target.closest('button, a, video, audio, input, .conteudo-midia, .message-reactions, .acoes, .quote-box, .btn-acessar-link')) return;
    document.querySelectorAll('#mensagens .msg.menu-mensagem-aberto').forEach(n => { if (n !== el) n.classList.remove('menu-mensagem-aberto'); });
  });
}
async function reagirMensagem(messageId, emoji, event) {
  if (event) { event.stopPropagation(); event.preventDefault(); }
  fecharSeletoresReacao();
  if (!usuarioAtual || !messageId) return;
  try {
    const resp = await fetch(`/api/messages/${encodeURIComponent(messageId)}/reaction`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id, emoji })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Não foi possível reagir.');
    const msg = mensagensCacheAtual.get(messageId);
    if (msg) {
      msg.reactions = data.reactions || [];
      const antigo = document.querySelector(`#mensagens [data-id="${messageId}"]`);
      if (antigo) antigo.replaceWith(criarElementoMensagem(msg));
    }
  } catch (e) { mostrarAviso(e.message || 'Não foi possível reagir à mensagem.'); }
}

// Se já está fixada, desafixa direto. Se não, pergunta por quanto tempo fixar.
async function fixarMensagem(messageId) {
  if (!usuarioAtual || !chatAtualId || chatAtualRemovido) return;
  const msg = mensagensCacheAtual.get(messageId);
  if (msg && msg.pinned) { enviarFixar(messageId, null); return; }
  const duracao = await escolherDuracaoFixar();
  if (duracao) enviarFixar(messageId, duracao);
}

function escolherDuracaoFixar() {
  return new Promise(resolve => {
    const root = document.getElementById('modal-root');
    root.innerHTML = `
      <div class="modal-overlay" id="modal-overlay">
        <div class="modal-box">
          <h3 class="modal-title">Fixar mensagem</h3>
          <p class="modal-texto">Por quanto tempo você quer deixar fixada?</p>
          <div class="opcoes-duracao">
            <button type="button" class="opcao-duracao" data-d="24h"><i class="mdi mdi-clock-outline"></i><span>24 horas</span></button>
            <button type="button" class="opcao-duracao" data-d="7d"><i class="mdi mdi-calendar-week"></i><span>7 dias</span></button>
            <button type="button" class="opcao-duracao" data-d="30d"><i class="mdi mdi-calendar-month-outline"></i><span>30 dias</span></button>
          </div>
          <div class="modal-actions">
            <button class="btn-outline btn-compacto" id="modal-fixar-cancelar" type="button">Cancelar</button>
          </div>
        </div>
      </div>`;
    const fechar = valor => { root.innerHTML = ''; resolve(valor); };
    root.querySelectorAll('.opcao-duracao').forEach(btn => { btn.onclick = () => fechar(btn.dataset.d); });
    document.getElementById('modal-fixar-cancelar').onclick = () => fechar(null);
    document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') fechar(null); };
  });
}

async function enviarFixar(messageId, duracao) {
  try {
    const resp = await fetch(`/api/chats/${encodeURIComponent(chatAtualId)}/pin`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id, messageId, duration: duracao })
    });
    const data = await resp.json();
    if (!resp.ok) throw new Error(data.error || 'Não foi possível fixar a mensagem.');
    aplicarEstadoFixada(messageId, !!data.pinned, data.pinnedUntil || null);
    mostrarAviso(data.pinned ? 'Mensagem fixada na conversa.' : 'Mensagem desafixada.', 'sucesso');
    carregarListaChats();
  } catch (e) { mostrarAviso(e.message || 'Não foi possível fixar a mensagem.'); }
}

// Atualiza cache + tela quando uma mensagem é fixada/desafixada (por mim ou por outra pessoa).
function aplicarEstadoFixada(messageId, pinned, pinnedUntil) {
  mensagensCacheAtual.forEach((item, id) => {
    const eraFixada = !!item.pinned;
    item.pinned = id === messageId && pinned;
    item.pinnedUntil = item.pinned ? pinnedUntil : null;
    if (eraFixada !== item.pinned || id === messageId) {
      const antigo = document.querySelector(`#mensagens [data-id="${id}"]`);
      if (antigo) antigo.replaceWith(criarElementoMensagem(item));
    }
  });
  renderBannerMensagemFixada(Array.from(mensagensCacheAtual.values()));
}

// Quando o prazo acaba, some a fixação sozinha (o servidor também já não devolve mais).
let timerExpiraFixada = null;
function expirarFixada(messageId) {
  const item = mensagensCacheAtual.get(messageId);
  if (!item || !item.pinned) return;
  aplicarEstadoFixada(messageId, false, null);
  carregarListaChats();
}

// ---------- Auth ----------
let emailPendenteVerificacao = '';
async function fazerCadastro() {
  const username = document.getElementById('reg-username').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-pass').value;
  const erroEl = document.getElementById('reg-erro'); erroEl.textContent = '';
  try {
    const resp = await fetch('/api/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, email, password }) });
    const data = await resp.json();
    if (!resp.ok) { erroEl.textContent = data.error || 'Não foi possível criar a conta.'; return; }
    emailPendenteVerificacao = data.email || email;
    document.getElementById('verify-email-label').textContent = emailPendenteVerificacao;
    document.getElementById('verify-code').value = ''; document.getElementById('verify-erro').textContent = '';
    mostrarTela('verificacao');
  } catch (e) { erroEl.textContent = 'Falha de conexão. Tente novamente.'; }
}
async function verificarCodigoEmail() {
  const code = document.getElementById('verify-code').value.trim(); const erro = document.getElementById('verify-erro'); erro.textContent = '';
  try {
    const resp = await fetch('/api/verify-email-code', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: emailPendenteVerificacao, code }) });
    const data = await resp.json(); if (!resp.ok) { erro.textContent = data.error || 'Código inválido.'; return; }
    usuarioAtual = data.user; salvarConta(usuarioAtual); entrarNoChat();
  } catch (e) { erro.textContent = 'Falha de conexão. Tente novamente.'; }
}
async function entrarComGoogle() {
  try {
    const cfgResp = await fetch('/api/auth-config'); const cfg = await cfgResp.json();
    if (!cfg.googleClientId) { mostrarAviso('O login Google ainda precisa ser configurado pelo administrador. Veja o passo a passo de credenciais.'); return; }
    if (!window.google || !google.accounts || !google.accounts.id) { mostrarAviso('O Google ainda está carregando. Tente novamente em alguns segundos.'); return; }
    const callback = async response => {
      try {
        const r = await fetch('/api/google-login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ credential: response.credential }) });
        const d = await r.json(); if (!r.ok) { mostrarAviso(d.error || 'Não foi possível entrar com Google.'); return; }
        if (d.verificationRequired) {
          emailPendenteVerificacao = d.email || '';
          document.getElementById('verify-email-label').textContent = emailPendenteVerificacao;
          document.getElementById('verify-code').value = '';
          document.getElementById('verify-erro').textContent = '';
          mostrarTela('verificacao');
          return;
        }
        usuarioAtual = d.user; salvarConta(usuarioAtual); entrarNoChat();
      } catch (e) { mostrarAviso('Falha de conexão ao entrar com Google.'); }
    };
    google.accounts.id.initialize({ client_id: cfg.googleClientId, callback, auto_select: false, cancel_on_tap_outside: false, itp_support: true });
    google.accounts.id.disableAutoSelect();
    const target = document.getElementById(document.getElementById('login-screen')?.classList.contains('oculto') ? 'google-register-render' : 'google-login-render');
    if (target && google.accounts.id.renderButton) {
      target.innerHTML = '';
      google.accounts.id.renderButton(target, { type: 'standard', theme: 'filled_black', size: 'large', text: 'continue_with', shape: 'pill', width: Math.min(380, window.innerWidth - 48), logo_alignment: 'left' });
      target.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
    google.accounts.id.prompt(notification => { if (notification.isNotDisplayed() && target) target.classList.add('google-render-visible'); });
  } catch (e) { mostrarAviso('Não foi possível iniciar o login Google.'); }
}
function prepararBotoesGoogle() {
  if (!document.getElementById('google-login-render') || !window.google?.accounts?.id) return false;
  entrarComGoogle().catch(() => {});
  return true;
}
setTimeout(() => { if (!prepararBotoesGoogle()) setTimeout(prepararBotoesGoogle, 1200); }, 700);
async function fazerLogin() {
  const emailOrUsername = document.getElementById('login-user').value.trim(); const password = document.getElementById('login-pass').value;
  const erroEl = document.getElementById('login-erro'); erroEl.textContent = '';
  try {
    const resp = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ emailOrUsername, password }) });
    const data = await resp.json(); if (!resp.ok) { erroEl.textContent = data.error || 'Não foi possível entrar.'; return; }
    if (data.verificationRequired) {
      emailPendenteVerificacao = data.email || '';
      document.getElementById('verify-email-label').textContent = emailPendenteVerificacao;
      document.getElementById('verify-code').value = '';
      document.getElementById('verify-erro').textContent = '';
      mostrarTela('verificacao');
      return;
    }
    usuarioAtual = data.user; salvarConta(usuarioAtual); entrarNoChat();
  } catch (e) { erroEl.textContent = 'Falha de conexão. Tente novamente.'; }
}

async function buscarPerfilPorNumero() {
  const numero = await perguntarModal('Buscar perfil', 'Número de contato (7 dígitos)', '', { placeholder: '0000000', botao: 'Buscar' });
  if (numero === null) return;
  const q = numero.replace(/\D/g, '').trim();
  if (!/^\d{7}$/.test(q)) { mostrarAviso('O número precisa ter exatamente 7 dígitos.'); return; }
  try {
    const resp = await fetch('/api/users/search?q=' + encodeURIComponent(q)); const data = await resp.json();
    if (!resp.ok) { mostrarAviso(data.error || 'Perfil não encontrado.'); return; }
    if (data.user.id === usuarioAtual.id) { abrirEditarPerfil(); return; }
    await abrirPerfilUsuario(data.user.id);
  } catch (e) { mostrarAviso('Não foi possível buscar esse perfil agora.'); }
}

function sair() {
  if (usuarioAtual) {
    const contas = carregarContas().filter(c => c.id !== usuarioAtual.id);
    localStorage.setItem('contas', JSON.stringify(contas));
  }
  localStorage.removeItem('usuario');
  location.reload();
}

// ---------- Entrar no chat ----------
function entrarNoChat() {
  mostrarTela('chat');
  garantirContaNaLista();
  atualizarAvatarTopo();
  atualizarHomeConta();
  document.getElementById('footer-ano').textContent = new Date().getFullYear();

  aplicarConfig(carregarConfig());
  if (tokenPushPendente) registrarTokenPush(tokenPushPendente);

  socket = io();
  if (typeof mittoEnhanceSocket === 'function') mittoEnhanceSocket(socket);
  registrarEventosChamada(socket);
  // 'connect' dispara na conexão inicial E em toda reconexão (celular que bloqueou a tela,
  // troca de wifi pra 4G, servidor reiniciando). A cada vez o servidor enxerga um socket novo,
  // sem sala nenhuma — então precisa entrar de novo, senão as mensagens param de chegar.
  socket.on('connect', () => {
    socket.emit('join', { userId: usuarioAtual.id });
    if (chatAtualId) socket.emit('join_chat', chatAtualId);
    informarTelaVisivel();
    if (window.__mittoPendingCallAction && window.__mittoPendingCallAction.callId) {
      const pending = window.__mittoPendingCallAction;
      socket.emit('call:resume', { callId: pending.callId });
    }
    if (socket.recuperar) { socket.recuperar = false; recarregarEstadoAtual(); }
  });
  socket.on('disconnect', () => { socket.recuperar = true; });
  sincronizarContatos();
  document.addEventListener('visibilitychange', () => {
    informarTelaVisivel();
    if (document.visibilityState === 'visible') recarregarEstadoAtual();
  });
  socket.on('send_message_error', payload => {
    mostrarAviso(payload && payload.message ? payload.message : 'Não foi possível enviar a mídia.');
  });

  socket.on('presence:update', payload => {
    if (!payload || !chatAtualOutro || String(payload.userId) !== String(chatAtualOutro.id)) return;
    chatAtualOutro.online = !!payload.online; chatAtualOutro.lastSeen = payload.lastSeen || chatAtualOutro.lastSeen || null;
    atualizarStatusCabecalho(chatAtualOutro, chatAtualTipo);
  });
  socket.on('typing:update', payload => {
    if (!payload || String(payload.chatId) !== String(chatAtualId) || String(payload.userId) === String(usuarioAtual.id)) return;
    if (payload.typing) contatoDigitando.add(String(payload.userId)); else contatoDigitando.delete(String(payload.userId));
    atualizarStatusCabecalho(chatAtualOutro, chatAtualTipo);
  });
  socket.on('message:receipt', payload => {
    if (!payload || String(payload.senderId) !== String(usuarioAtual.id)) return;
    const msg = mensagensCacheAtual.get(payload.messageId) || [...mensagensCacheAtual.values()].find(m => String(m.id) === String(payload.messageId));
    if (msg) { msg.deliveredTo = payload.deliveredTo || []; msg.readBy = payload.readBy || []; }
    const el = [...document.querySelectorAll('#mensagens [data-id]')].find(node => String(node.dataset.id) === String(payload.messageId))?.querySelector('.msg-receipt');
    if (el) { el.className = 'msg-receipt ' + classeRecibo(msg || payload); el.textContent = textoRecibo(msg || payload); el.title = tituloRecibo(msg || payload); }
    if (msg?.readBy?.length) {
      const player = [...document.querySelectorAll('#mensagens [data-id]')].find(node => String(node.dataset.id) === String(payload.messageId))?.querySelector('.audio-player');
      if (player) player.classList.add('audio-read');
    }
  });
  socket.on('new_message', msg => {
    if (msg.chatId === chatAtualId) {
      renderizarMensagem(msg);
      if (msg.senderId !== usuarioAtual.id) socket.emit('message:delivered', { messageId: msg.id });
      marcarComoLida(msg.chatId); // já tá com a conversa aberta, não conta como não lida
      if (msg.systemMeta && msg.systemMeta.kind === 'rename') {
        document.getElementById('chat-header-nome').textContent = msg.systemMeta.novoNome;
      }
    } else {
      carregarListaChats();
    }
  });
  socket.on('message_edited', msg => {
    if (msg.chatId === chatAtualId) atualizarMensagemNaTela(msg);
    mensagensCacheAtual.set(msg.id, msg);
  });
  socket.on('message_reactions_updated', payload => {
    if (!payload || payload.chatId !== chatAtualId) return;
    const msg = mensagensCacheAtual.get(payload.messageId) || [...mensagensCacheAtual.values()].find(m => String(m.id) === String(payload.messageId));
    if (!msg) return;
    msg.reactions = payload.reactions || [];
    const antigo = document.querySelector(`#mensagens [data-id="${payload.messageId}"]`);
    if (antigo) antigo.replaceWith(criarElementoMensagem(msg));
  });
  socket.on('message_pin_updated', payload => {
    if (!payload || payload.chatId !== chatAtualId) return;
    aplicarEstadoFixada(payload.messageId, !!payload.pinned, payload.pinnedUntil || null);
  });
  socket.on('message_deleted', ({ id }) => {
    const cache = mensagensCacheAtual.get(id);
    if (cache) {
      cache.deleted = true;
      cache.content = null;
      cache.mediaUrl = null;
    }

    const antigo = document.querySelector(`[data-id="${id}"]`);
    if (antigo && cache) {
      // reconstrói a mensagem do zero a partir do estado já atualizado (deleted: true).
      // criarElementoMensagem nem gera o botão de Acessar nesse caso, então não tem
      // como ele "sobrar" na tela clicável — em vez de confiar em remover só o pedaço
      // certo do HTML antigo (frágil: qualquer coisa nova que a gente adicionar no
      // balão da mensagem no futuro teria que lembrar de ser removida aqui também).
      antigo.replaceWith(criarElementoMensagem(cache));
    } else if (antigo) {
      // fallback bem raro: mensagem apagada antes de estar no cache local
      antigo.querySelectorAll('.conteudo, .btn-acessar-link, .acoes').forEach(n => n.remove());
      const div = document.createElement('div');
      div.className = 'conteudo apagada';
      div.textContent = 'Mensagem apagada';
      antigo.prepend(div);
    }
  });
  socket.on('removido_do_grupo', ({ chatId }) => {
    mostrarAviso('Você foi removido desse grupo.');
    if (chatAtualId === chatId) {
      chatAtualRemovido = true;
      renderMenuChatAtual();
      aplicarModoSomenteLeitura();
    }
    carregarListaChats();
  });
  socket.on('solicitacao_entrada', ({ chatId, chatName, username }) => {
    // sem popup pro admin: o pedido aparece só na lista de pedidos do grupo (com o contador)
    if (chatId === chatAtualId) atualizarBadgePedidos(chatId);
  });
  socket.on('solicitacao_recusada', ({ chatName }) => {
    mostrarAviso(`Seu pedido pra entrar em "${chatName}" foi recusado.`);
  });
  socket.on('modo_envio_alterado', ({ chatId, modoEnvio }) => {
    if (chatAtualId === chatId) {
      chatAtualModoEnvio = modoEnvio;
      aplicarModoSomenteLeitura();
    }
  });

  carregarListaChats();
  carregarStats();
  carregarNovidades();
  voltarHome();
  processarConviteNaURL();
}

// ---------- Entrar num grupo pelo link (?convite=CODIGO na URL) ----------
async function entrarNoGrupoPorCodigo(code) {
  const infoResp = await fetch(`/api/invite/${code}/info?userId=${usuarioAtual.id}`);
  const info = await infoResp.json();
  if (!infoResp.ok) { mostrarAviso(info.error || 'Não foi possível entrar nesse grupo.'); return; }

  if (info.bloqueado) { mostrarAviso('Não foi possível entrar nesse grupo.'); return; }
  if (info.jaPendente) { mostrarAviso('Você já tem um pedido de entrada esperando aprovação nesse grupo.'); return; }

  if (info.approvalRequired && !info.jaEstava) {
    const aceitou = await abrirConfirmacao({
      titulo: 'Pedir pra entrar no grupo',
      mensagem: `O grupo "${info.chatName}" exige aprovação de um admin. Quer solicitar entrada?`,
      textoBotao: 'Solicitar'
    });
    if (!aceitou) return;
  }

  const resp = await fetch(`/api/invite/${code}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id })
  });
  const data = await resp.json();

  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível entrar nesse grupo.'); return; }
  if (data.pendente) { mostrarAviso('Pedido enviado! Um admin do grupo precisa aprovar.', 'sucesso'); return; }
  mostrarAviso(data.jaEstava ? 'Você já está nesse grupo.' : `Você entrou no grupo "${data.chat.name}"!`, 'sucesso');
  carregarListaChats();
}

async function processarConviteNaURL() {
  const params = new URLSearchParams(location.search);
  const code = params.get('convite');
  if (!code) return;
  history.replaceState({}, '', location.pathname); // não tenta de novo se der F5
  entrarNoGrupoPorCodigo(code);
}

// ---------- Marcar conversa como lida (zera a bolinha de não lidas) ----------
async function marcarComoLida(chatId) {
  if (!usuarioAtual || !chatId) return;
  if (socket && socket.connected) socket.emit('message:read', { chatId });
  await fetch(`/api/chats/${chatId}/read`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id })
  });
  carregarListaChats();
}

// busca de novo o que pode ter sido perdido enquanto o aparelho estava desconectado/dormindo
async function recarregarEstadoAtual() {
  if (!usuarioAtual) return;
  try {
    await carregarListaChats();
    sincronizarContatos();
    if (chatAtualId) {
      const resp = await fetch(`/api/chats/${chatAtualId}/messages?userId=${usuarioAtual.id}`);
      if (!resp.ok) return;
      const data = await resp.json();
      (data.messages || []).forEach(m => {
        if (!document.querySelector(`[data-id="${m.id}"]`)) renderizarMensagem(m);
      });
    }
  } catch (e) { /* tenta de novo na próxima reconexão */ }
}

// ---------- Lista de conversas ----------
async function carregarListaChats() {
  const base = '/api/chats?userId=' + encodeURIComponent(usuarioAtual.id);
  const view = filtroConversas === 'arquivadas' ? '&view=archived' : '';
  const resp = await fetch(base + view);
  const data = await resp.json();
  todasAsConversas = data.chats || [];
  if (filtroConversas !== 'arquivadas') {
    try { const ar = await fetch(base + '&view=archived'); const ad = await ar.json(); conversasArquivadasTotal = (ad.chats || []).length; } catch (_) {}
  } else conversasArquivadasTotal = todasAsConversas.length;
  renderizarListaChats();
}

function formatarHoraLista(timestamp) {
  if (!timestamp) return '';
  const d = new Date(timestamp); if (Number.isNaN(d.getTime())) return '';
  const hora = d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
  const data = d.toLocaleDateString([], {day:'2-digit',month:'2-digit'});
  return `<span class="item-chat-time-hour">${hora}</span><span class="item-chat-time-date">${data}</span>`;
}

function renderizarListaChats() {
  const busca = (document.getElementById('busca-input').value || '').trim().toLowerCase();

  const trancados = chatsTrancados();
  const filtradas = todasAsConversas.filter(chat => {
    if (trancados.includes(chat.id)) return false;
    if (filtroConversas === 'grupo' && chat.type !== 'group') return false;
    if (filtroConversas !== 'arquivadas' && chat.archived) return false;
    if (busca && !String(chat.name || '').toLowerCase().includes(busca)) return false;
    return true;
  });

  const container = document.getElementById('lista-chats');
  const vazio = document.getElementById('sem-conversas');
  container.innerHTML = '';
  const arquivadasTotal = conversasArquivadasTotal;
  if (filtroConversas !== 'arquivadas' && arquivadasTotal > 0) {
    const caixa = document.createElement('button');
    caixa.type = 'button'; caixa.className = 'caixa-arquivadas';
    caixa.innerHTML = `<span class="caixa-arquivadas-icone"><i class="mdi mdi-archive-outline"></i></span><span class="caixa-arquivadas-copy"><strong>Arquivadas</strong><small>${arquivadasTotal} conversa${arquivadasTotal === 1 ? '' : 's'} guardada${arquivadasTotal === 1 ? '' : 's'}</small></span><i class="mdi mdi-chevron-right"></i>`;
    caixa.onclick = () => filtrarConversas('arquivadas');
    container.appendChild(caixa);
  }

  if (todasAsConversas.length === 0) {
    vazio.classList.toggle('oculto', filtroConversas !== 'arquivadas' && arquivadasTotal > 0);
    container.classList.toggle('oculto', !(filtroConversas !== 'arquivadas' && arquivadasTotal > 0));
    const textoVazio = vazio.querySelector('p');
    if (textoVazio) textoVazio.innerHTML = filtroConversas === 'arquivadas'
      ? 'Nenhuma conversa arquivada por enquanto.'
      : 'Você ainda não tem nenhuma conversa.<br>Use o botão acima pra chamar alguém pelo nome de usuário ou email.';
    return;
  }
  vazio.classList.toggle('oculto', filtradas.length > 0);
  container.classList.toggle('oculto', filtradas.length === 0);
  if (!filtradas.length) {
    const textoVazio = vazio.querySelector('p');
    if (textoVazio) textoVazio.textContent = filtroConversas === 'arquivadas' ? 'Nenhuma conversa arquivada por enquanto.' : 'Nenhuma conversa encontrada.';
    return;
  }

  filtradas.forEach(chat => {
    const div = document.createElement('div');
    div.className = 'item-chat' + (chat.id === chatAtualId ? ' ativo' : '');
    div.onclick = () => abrirChat(chat.id, chat.name, chat.type, chat.otherUserId, chat.otherEmail, chat.removidoDoGrupo, chat.photoUrl);

    const ultimaMensagem = chat.lastMessage ?? chat.last_message ?? chat.lastMessageText ?? chat.preview ?? '';

    const badgeHtml = chat.unreadCount > 0
      ? `<span class="badge-nao-lidas">${chat.unreadCount > 99 ? '99+' : chat.unreadCount}</span>`
      : '';

    const avatarHtml = `<span class="avatar-circle avatar-circle--sm avatar-perfil-abrir" role="button" tabindex="0" title="Ver perfil">${avatarInnerHtml(chat.name, chat.photoUrl)}</span>`;

    div.innerHTML = `
      <div class="item-chat-topo">
        <div class="item-chat-titulo">
          ${avatarHtml}
          <div class="nome">${escapeHtml(chat.name)}${chat.removidoDoGrupo ? ' <span class="tag-removido">(removido)</span>' : ''}</div>
        </div>
        <button class="item-menu-btn" onclick="abrirMenuChatItem(event, '${chat.id}')" aria-label="Opções da conversa"><i class="mdi mdi-dots-vertical" aria-hidden="true"></i></button>
      </div>
      <div class="item-chat-preview-row">
        <div class="preview">${escapeHtml(ultimaMensagem || 'Sem mensagens ainda')}</div>
        <div class="item-chat-meta"><time>${formatarHoraLista(chat.lastMessageAt || chat.last_message_at)}</time>${badgeHtml}</div>
      </div>`;
    const avatarBtn = div.querySelector('.avatar-perfil-abrir');
    if (avatarBtn && chat.type !== 'group' && chat.otherUserId) {
      avatarBtn.addEventListener('click', e => { e.stopPropagation(); abrirPerfilUsuario(chat.otherUserId); });
      avatarBtn.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); e.stopPropagation(); abrirPerfilUsuario(chat.otherUserId); } });
    }
    container.appendChild(div);
  });
}

// ---------- Menu flutuante (usado no ⋮ de cada conversa da lista) ----------
function fecharMenuFlutuante() {
  const el = document.getElementById('menu-flutuante');
  if (el) el.remove();
}

function abrirMenuFlutuante(botaoEl, itensHtml) {
  fecharMenuFlutuante();
  const rect = botaoEl.getBoundingClientRect();

  const el = document.createElement('div');
  el.id = 'menu-flutuante';
  el.className = 'dropdown-menu';
  el.innerHTML = itensHtml;
  document.body.appendChild(el);

  el.style.top = (rect.bottom + 6) + 'px';
  el.style.left = Math.max(8, rect.right - el.offsetWidth) + 'px';

  // se estourar embaixo da tela, abre pra cima do botão
  const alturaMenu = el.offsetHeight;
  if (rect.bottom + 6 + alturaMenu > window.innerHeight) {
    el.style.top = (rect.top - alturaMenu - 6) + 'px';
  }
}

document.addEventListener('click', e => {
  if (!e.target.closest('#menu-flutuante') && !e.target.closest('.item-menu-btn')) {
    fecharMenuFlutuante();
  }
});

function abrirMenuChatItem(event, chatId) {
  event.stopPropagation();
  const chat = todasAsConversas.find(c => c.id === chatId);
  if (!chat) return;

  const archiveItem = `<div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); arquivarConversa('${chat.id}', ${!chat.archived})"><i class="mdi ${chat.archived ? 'mdi-archive-arrow-up-outline' : 'mdi-archive-outline'}"></i><span>${chat.archived ? 'Desarquivar conversa' : 'Arquivar conversa'}</span></div>`;
  const itens = chat.removidoDoGrupo
    ? `<div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); apagarConversa('${chat.id}', true)"><span>Apagar conversa</span></div>`
    : chat.type === 'group'
    ? `${archiveItem}<div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); abrirConfigGrupo('${chat.id}')"><span>Configurações do grupo</span></div>
       <div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); apagarConversa('${chat.id}')"><span>Apagar conversa</span></div>
       <div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); sairDoGrupo('${chat.id}')"><span>Sair do grupo</span></div>`
    : `${archiveItem}<div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); apagarConversa('${chat.id}')"><span>Apagar conversa</span></div>
       ${chat.ehAutoConversa ? '' : `<div class="dropdown-item dropdown-clicavel" onclick="fecharMenuFlutuante(); bloquearUsuario('${chat.otherUserId}', '${chat.id}')"><span>Bloquear usuário</span></div>`}`;

  abrirMenuFlutuante(event.currentTarget, itens);
}

// ---------- Estatísticas da home ----------
async function carregarNovidades() {
  try {
    const resp = await fetch('/api/novidades');
    if (!resp.ok) throw new Error('Não foi possível carregar as novidades');
    const payload = await resp.json();
    const novidades = Array.isArray(payload.novidades) ? payload.novidades : [];
    const el = document.querySelector('.home-news-section');
    if (!el) return;
    const heading = `<div class="home-section-heading"><span class="home-section-icon"><i class="mdi mdi-sparkles"></i></span><div><h2>Novidades</h2><p>O que está acontecendo no Mitto</p></div></div>`;
    if (!novidades.length) {
      el.innerHTML = heading + '<p class="texto-vazio home-news-empty">Nenhuma novidade publicada ainda. Quando houver uma atualização, ela aparece aqui.</p>';
      return;
    }
    el.innerHTML = heading + '<div class="home-news-list">' + novidades.map(n => `
      <article class="home-news-card">
        ${n.imageUrl ? `<img src="${escapeAttr(n.imageUrl)}" class="home-news-image" alt="" loading="lazy">` : '<div class="home-news-image-placeholder"><i class="mdi mdi-bell-outline"></i></div>'}
        <div class="home-news-copy"><span class="home-news-kicker">ATUALIZAÇÃO MITTO</span>
          <h3>${escapeHtml(n.titulo || 'Novidade')}</h3>
          <p>${escapeHtml(n.texto || '')}</p>
        </div>
      </article>`).join('') + '</div>';
  } catch(e) {
    const el = document.querySelector('.home-news-section');
    if (el && !el.querySelector('.home-news-card')) {
      const empty = el.querySelector('.home-news-empty');
      if (empty) empty.textContent = 'Não foi possível carregar as novidades agora.';
    }
  }
}

async function carregarStats() {
  try {
  const resp = await fetch('/api/stats');
  if (!resp.ok) throw new Error('Falha ao carregar estatísticas');
  const data = await resp.json();

  const rankingEl = document.getElementById('ranking-usuarios');
  if (rankingEl && data.usuariosMaisAtivos && data.usuariosMaisAtivos.length) {
    rankingEl.innerHTML = data.usuariosMaisAtivos.map((u, i) => `
      <div class="ranking-row">
        <span class="ranking-pos">${i + 1}</span>
        <span class="ranking-nome">${escapeHtml(u.username)}</span>
        <span class="ranking-valor">${u.total} conversa${u.total === 1 ? '' : 's'} iniciada${u.total === 1 ? '' : 's'}</span>
      </div>`).join('');
  }

  const grupoEl = document.getElementById('grupo-destaque-wrap');
  if (grupoEl && data.grupoMaisAtivo) {
    const g = data.grupoMaisAtivo;
    grupoEl.innerHTML = `
      <div class="grupo-destaque">
        <strong>${escapeHtml(g.nome)}</strong>
        <span>${g.totalMensagens} mensagem${g.totalMensagens === 1 ? '' : 's'} · ${g.totalMembros} participante${g.totalMembros === 1 ? '' : 's'}</span>
      </div>`;
  }
  } catch (e) { /* estatísticas são complementares; a conversa continua disponível */ }
}

// ---------- Contatos salvos (ficam no SERVIDOR, iguais em qualquer aparelho) ----------
// contatosCache é só uma cópia em memória da lista do servidor, pra tela não esperar rede.
let contatosCache = [];

function carregarContatos() {
  return contatosCache;
}
function contatoSalvo(id) {
  return contatosCache.some(c => c.id === id);
}
function salvarContato(contato) {
  contatosCache = contatosCache.filter(c => c.id !== contato.id);
  contatosCache.unshift({ id: contato.id, username: contato.username, email: contato.email || null, photoUrl: contato.photoUrl || null });
}
function apagarContato(id) {
  contatosCache = contatosCache.filter(c => c.id !== id);
}

// baixa a lista do servidor. Na primeira vez em que este navegador roda a versão nova,
// sobe pro servidor os contatos que estavam só no localStorage (pra ninguém perder os antigos).
async function sincronizarContatos() {
  if (!usuarioAtual) return;
  const chaveAntiga = 'contatos_' + usuarioAtual.id;
  try {
    const antigos = JSON.parse(localStorage.getItem(chaveAntiga) || '[]');
    if (antigos.length) {
      await Promise.all(antigos.map(c => fetch('/api/contacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ownerId: usuarioAtual.id, contactId: c.id })
      })));
    }
    localStorage.removeItem(chaveAntiga);
  } catch (e) { /* sem problema, segue com a lista do servidor */ }

  try {
    const resp = await fetch('/api/contacts?ownerId=' + encodeURIComponent(usuarioAtual.id));
    if (!resp.ok) return;
    const data = await resp.json();
    contatosCache = data.contacts || [];
    renderContatoBanner();
  } catch (e) { /* offline: mantém o que já tinha */ }
}

function abrirNovaConversa() {
  renderNovaConversaModal();
}

async function renderNovaConversaModal() {
  const contatos = carregarContatos();
  const root = document.getElementById('modal-root');

  // nunca confia na foto que ficou guardada no cache local pra isso — ela pode estar
  // desatualizada (privacidade mudou, contato foi apagado, etc). Busca sempre fresca.
  const fotos = await Promise.all(contatos.map(c =>
    fetch(`/api/users/${c.id}/public?viewerId=${usuarioAtual.id}`)
      .then(r => r.ok ? r.json() : null)
      .catch(() => null)
  ));
  contatos.forEach((c, i) => { c.photoUrl = fotos[i] ? fotos[i].photoUrl : null; });

  const opcaoVoce = `
    <div class="dropdown-item conta-item">
      <span class="conta-info dropdown-clicavel" onclick="iniciarConversaComContato('${usuarioAtual.id}', '${escapeHtml(usuarioAtual.username)}', '${escapeHtml(usuarioAtual.email || '')}', ${usuarioAtual.photoUrl ? `'${escapeAttr(usuarioAtual.photoUrl)}'` : 'null'})">
        <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(usuarioAtual.username, usuarioAtual.photoUrl)}</span>
        <span>${escapeHtml(usuarioAtual.username)} <span class="tag-voce">(Você)</span></span>
      </span>
    </div>`;

  const listaContatos = `
    <div class="config-grupo">
      <span class="config-label">Seus contatos salvos</span>
      <div class="lista-contatos">
        ${opcaoVoce}
        ${contatos.map(c => `
          <div class="dropdown-item conta-item">
            <span class="conta-info dropdown-clicavel" onclick="iniciarConversaComContato('${c.id}', '${escapeHtml(c.username)}', '${escapeHtml(c.email || '')}', ${c.photoUrl ? `'${escapeAttr(c.photoUrl)}'` : 'null'})">
              <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(c.username, c.photoUrl)}</span>
              <span>${escapeHtml(c.username)}</span>
            </span>
            <span class="conta-remover" onclick="apagarContatoNoModal('${c.id}', event)" title="Apagar contato">✕</span>
          </div>`).join('')}
      </div>
    </div>`;

  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box">
        <h3 class="modal-title">Iniciar conversa</h3>
        ${listaContatos}
        <label class="modal-label">Ou digite o email ou usuário da pessoa
          <input class="modal-input" id="nova-conversa-query" type="text" placeholder="ex: maria ou maria@email.com">
        </label>
        <div class="modal-actions">
          <button class="btn-outline btn-compacto" id="modal-cancelar" type="button">Cancelar</button>
          <button class="btn-ok btn-compacto" id="modal-confirmar" type="button">Buscar</button>
        </div>
      </div>
    </div>`;

  const overlay = document.getElementById('modal-overlay');
  const fechar = () => { root.innerHTML = ''; };
  document.getElementById('modal-cancelar').onclick = fechar;
  overlay.onclick = e => { if (e.target === overlay) fechar(); };

  document.getElementById('modal-confirmar').onclick = async () => {
    const query = document.getElementById('nova-conversa-query').value.trim();
    fechar();
    if (query) await iniciarConversaPorBusca(query);
  };

  const input = document.getElementById('nova-conversa-query');
  input.focus();
  input.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('modal-confirmar').click(); });
}

function apagarContatoNoModal(id, event) {
  event.stopPropagation();
  apagarContato(id);
  fetch('/api/contacts/remove', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ownerId: usuarioAtual.id, contactId: id })
  });
  renderNovaConversaModal();
}

async function iniciarConversaPorBusca(query) {
  const busca = await fetch('/api/find-user?query=' + encodeURIComponent(query) + '&viewerId=' + encodeURIComponent(usuarioAtual.id));
  const dataBusca = await busca.json();
  if (!busca.ok) { mostrarAviso(dataBusca.error); return; }
  await criarChatPrivado(dataBusca.user.id, dataBusca.user.username, dataBusca.user.email, dataBusca.user.photoUrl);
}

function iniciarConversaComContato(id, username, email, photoUrl) {
  document.getElementById('modal-root').innerHTML = '';
  criarChatPrivado(id, username, email, photoUrl);
}

// ---------- Confirmação simples (sim/não) ----------
function abrirConfirmacao({ titulo, mensagem, textoBotao }) {
  return new Promise(resolve => {
    const root = document.getElementById('modal-root');
    root.innerHTML = `
      <div class="modal-overlay" id="modal-overlay">
        <div class="modal-box">
          <h3 class="modal-title">${escapeHtml(titulo)}</h3>
          <p class="modal-texto">${escapeHtml(mensagem)}</p>
          <div class="modal-actions">
            <button class="btn-outline btn-compacto" id="modal-cancelar" type="button">Cancelar</button>
            <button class="btn-ok btn-compacto" id="modal-confirmar" type="button">${escapeHtml(textoBotao)}</button>
          </div>
        </div>
      </div>`;
    const overlay = document.getElementById('modal-overlay');
    const fechar = valor => { root.innerHTML = ''; resolve(valor); };
    document.getElementById('modal-cancelar').onclick = () => fechar(false);
    overlay.onclick = e => { if (e.target === overlay) fechar(false); };
    document.getElementById('modal-confirmar').onclick = () => fechar(true);
  });
}

async function criarChatPrivado(targetUserId, username, email, photoUrl) {
  const resp = await fetch('/api/chats/private', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, targetUserId })
  });
  const data = await resp.json();

  if (!resp.ok) {
    if (resp.status === 404) {
      apagarContato(targetUserId);
      mostrarAviso('Essa pessoa não existe mais. Removi ela dos seus contatos salvos.');
      return;
    }
    if (data.bloqueadoPorMim) {
      const aceitou = await abrirConfirmacao({
        titulo: 'Usuário bloqueado',
        mensagem: `Você bloqueou ${username}. Se continuar a conversa, ele será desbloqueado. Deseja continuar?`,
        textoBotao: 'Desbloquear e continuar'
      });
      if (!aceitou) return;
      await fetch('/api/unblock', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: usuarioAtual.id, blockedId: targetUserId })
      });
      return criarChatPrivado(targetUserId, username, email, photoUrl);
    }
    mostrarAviso(data.error || 'Não foi possível iniciar essa conversa.');
    return;
  }

  abrirChat(data.chat.id, username, 'private', targetUserId, email, false, photoUrl);
  carregarListaChats();
  carregarStats();
}

async function abrirNovoGrupo() {
  const valores = await abrirModal({
    titulo: 'Criar grupo',
    campos: [
      { id: 'nome', label: 'Nome do grupo', placeholder: 'ex: Galera do trampo' },
      { id: 'membros', label: 'Participantes (email ou usuário, separados por vírgula)', placeholder: 'maria, joao@email.com' }
    ],
    textoBotao: 'Criar'
  });
  if (!valores || !valores.nome) return;
  const nome = valores.nome;
  const lista = (valores.membros || '').split(',').map(s => s.trim()).filter(Boolean);

  if (!lista.length) {
    mostrarAviso('Adicione pelo menos uma pessoa pra criar o grupo.');
    return;
  }

  const resp = await fetch('/api/chats/group', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, name: nome, memberQueries: lista })
  });
  const data = await resp.json();

  if (!resp.ok) {
    mostrarAviso(data.error || 'Não foi possível criar o grupo.');
    return;
  }

  if (data.naoEncontrados && data.naoEncontrados.length) {
    mostrarAviso('Não encontrado: ' + data.naoEncontrados.join(', '));
  }
  if (data.bloqueados && data.bloqueados.length) {
    data.bloqueados.forEach(nome => mostrarAviso('Não foi possível adicionar ' + nome));
  }
  abrirChat(data.chat.id, nome, 'group', null, null);
  carregarListaChats();
  carregarStats();
}

// Status do cabeçalho: usa apenas presença/último acesso quando a API fornece esses dados.
function atualizarStatusCabecalho(contato, tipo) {
  const el = document.getElementById('chat-header-status');
  if (!el) return;
  el.classList.remove('is-online', 'is-offline', 'is-typing', 'is-status');
  if (tipo === 'group') { el.textContent = 'Grupo'; return; }
  if (contato && contato.id && contatoDigitando.has(String(contato.id))) {
    el.innerHTML = '<span class="typing-label">digitando</span><span class="typing-dots" aria-label="digitando"><i></i><i></i><i></i></span>';
    el.classList.add('is-typing'); return;
  }
  if (!contato) { el.textContent = 'Status não compartilhado'; return; }
  const recado = contato.statusText || '';
  if (recado) { el.textContent = recado; el.classList.add('is-status'); return; }
  const online = contato.online === true || contato.isOnline === true || contato.is_online === true;
  const ultimo = contato.lastSeen || contato.last_seen || contato.lastSeenAt || contato.last_seen_at || contato.lastActiveAt;
  if (online) {
    el.innerHTML = '<span class="presence-spinner" aria-hidden="true"></span><span>Online</span>';
    el.classList.add('is-online'); return;
  }
  let horario = '';
  if (ultimo) {
    let valor = ultimo;
    if (typeof valor === 'number' && valor > 0 && valor < 1000000000000) valor *= 1000;
    const d = new Date(valor);
    if (!Number.isNaN(d.getTime())) horario = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(d);
  }
  el.innerHTML = '<span class="presence-spinner" aria-hidden="true"></span><span>Offline</span>' + (horario ? '<span class="presence-last-seen">' + horario + '</span>' : '');
  el.classList.add('is-offline');
}

// ---------- Abrir um chat ----------
async function abrirChat(chatId, nome, tipo, outroId, outroEmail, removidoDoGrupo, photoUrl) {
  chatAtualId = chatId;
  chatAtualTipo = tipo || 'private';
  const contatoAnterior = (chatAtualOutro && String(chatAtualOutro.id) === String(outroId)) ? chatAtualOutro : null;
  chatAtualOutro = outroId ? { ...(contatoAnterior || {}), id: outroId, username: nome, email: outroEmail || null, photoUrl: photoUrl || null } : null;
  const perfilPendente = outroId && tipo !== 'group'
    ? fetch(`/api/users/${encodeURIComponent(outroId)}/public?viewerId=${encodeURIComponent(usuarioAtual.id)}`)
        .then(r => r.ok ? r.json() : null).catch(() => null)
    : Promise.resolve(null);
  chatAtualRemovido = !!removidoDoGrupo;
  chatAtualModoEnvio = 'todos';
  chatAtualSouAdmin = false;
  chatAtualSouDono = false;
  chatAtualMembros = [];
  esconderMencaoPopup();
  if (typeof sairDoModoEncaminhar === 'function') sairDoModoEncaminhar();

  document.getElementById('chat-header-nome').textContent = nome;
  document.getElementById('chat-header-avatar').innerHTML = avatarInnerHtml(nome, photoUrl || null);
  const headerAvatar = document.getElementById('chat-header-avatar');
  if (headerAvatar) { headerAvatar.style.cursor = tipo === 'group' ? 'default' : 'pointer'; headerAvatar.onclick = () => { if (tipo !== 'group' && chatAtualOutro) abrirPerfilUsuario(chatAtualOutro.id); }; }
  atualizarStatusCabecalho(chatAtualOutro, chatAtualTipo);
  atualizarBotoesChamada();
  document.getElementById('home-view').classList.add('oculto');
  document.getElementById('chat-view').classList.remove('oculto');
  mostrarPainelMobile();
  renderContatoBanner();
  renderMenuChatAtual();
  if (typeof garantirBotaoRecursosChat === 'function') garantirBotaoRecursosChat();
  if (typeof carregarPreferenciasChatAtual === 'function') carregarPreferenciasChatAtual();
  aplicarAparenciaChat();
  aplicarModoSomenteLeitura();

  atualizarBotoesInput();
  if (socket && socket.connected) socket.emit('join_chat', chatId); // se for fantasma, o servidor ignora isso
  informarTelaVisivel();
  contatoDigitando.clear();
  if (tipo !== 'group' && outroId && socket && socket.connected) socket.emit('presence:check', { userId: outroId });
  if (chatAtualTipo === 'group' && !chatAtualRemovido && socket && socket.connected) socket.emit('group:call:get-state', { chatId });
  cancelarResposta();

  if (tipo === 'group' && !chatAtualRemovido) atualizarPermissoesGrupo(chatId).catch(() => {});

  const container = document.getElementById('mensagens');
  container.innerHTML = '';
  container.dataset.ultimoDia = '';
  mensagensCacheAtual = new Map();
  try {
    const resp = await fetch(`/api/chats/${chatId}/messages?userId=${usuarioAtual.id}`);
    if (!resp.ok) throw new Error('messages_' + resp.status);
    const data = await resp.json();
    const mensagens = Array.isArray(data.messages) ? data.messages : [];
    mensagens.forEach(m => {
      renderizarMensagem(m);
      if (m.senderId !== usuarioAtual.id && socket && socket.connected) socket.emit('message:delivered', { messageId: m.id });
    });
    renderBannerMensagemFixada(mensagens);
    if (!chatAtualRemovido) marcarComoLida(chatId);
    if (tipo === 'group' && !chatAtualRemovido) atualizarBadgePedidos(chatId);
    else esconderBadgePedidos();
  } catch (_) {
    container.innerHTML = '<div class="chat-load-error"><i class="mdi mdi-message-alert-outline"></i><span>Não foi possível carregar as mensagens agora.</span><button type="button" onclick="location.reload()">Tentar novamente</button></div>';
  }
  perfilPendente.then(perfil => {
    if (perfil && chatAtualId === chatId && chatAtualOutro) {
      chatAtualOutro = Object.assign(chatAtualOutro, perfil);
      atualizarStatusCabecalho(chatAtualOutro, chatAtualTipo);
      renderContatoBanner();
    }
  });
}

// ---------- Busca quem pode mandar mensagem no grupo atual e o papel do usuário nele ----------
async function atualizarPermissoesGrupo(chatId) {
  const resp = await fetch(`/api/chats/${chatId}/members?userId=${usuarioAtual.id}`);
  if (!resp.ok) return;
  const data = await resp.json();
  if (chatAtualId !== chatId) return; // já trocou de conversa enquanto a requisição rodava
  chatAtualModoEnvio = data.modoEnvio || 'todos';
  chatAtualSouAdmin = !!data.souAdmin;
  chatAtualSouDono = !!data.souDono;
  chatAtualMembros = data.membros || [];
  aplicarModoSomenteLeitura();
}

// ---------- Ícone (👤n) de pedidos de entrada pendentes, do lado do menu de 3 pontinhos ----------
async function atualizarBadgePedidos(chatId) {
  // só admin/dono pode ver os pedidos; pra quem não é, nem pergunta (evita o erro 403 no console)
  if (chatId === chatAtualId && !chatAtualSouAdmin) { esconderBadgePedidos(); return; }
  const resp = await fetch(`/api/chats/${chatId}/invite?userId=${usuarioAtual.id}`);
  const btn = document.getElementById('btn-pedidos-grupo');
  if (!resp.ok) { esconderBadgePedidos(); return; } // não é admin, ou grupo sem link ainda
  const data = await resp.json();
  const badge = document.getElementById('badge-pedidos-grupo');
  const total = (data.joinRequests || []).length;
  if (chatAtualId !== chatId) return; // já saiu desse chat enquanto a requisição rodava
  btn.classList.remove('oculto');
  if (total > 0) {
    badge.textContent = total > 9 ? '9+' : String(total);
    badge.classList.remove('oculto');
  } else {
    badge.classList.add('oculto');
  }
}
function esconderBadgePedidos() {
  document.getElementById('btn-pedidos-grupo').classList.add('oculto');
  document.getElementById('badge-pedidos-grupo').classList.add('oculto');
}

// ---------- Janelinha rápida de pedidos pra entrar (aberta pelo ícone de usuários, sem passar pelo menu de 3 pontinhos) ----------
async function abrirPedidosPendentes(chatId) {
  if (!chatId) return;
  const resp = await fetch(`/api/chats/${chatId}/invite?userId=${usuarioAtual.id}`);
  if (!resp.ok) { mostrarAviso('Não foi possível ver os pedidos de entrada.'); return; }
  const data = await resp.json();
  const root = document.getElementById('modal-root');

  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box">
        <h3 class="modal-title">Pedidos pra entrar</h3>
        <div class="lista-contatos">${montarListaPedidos(chatId, data.joinRequests || [])}</div>
        <div class="modal-actions">
          <button class="btn-ok btn-compacto" id="pedidos-fechar" type="button">Fechar</button>
        </div>
      </div>
    </div>`;

  document.getElementById('pedidos-fechar').onclick = () => { root.innerHTML = ''; };
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') root.innerHTML = ''; };
}

// ---------- Decide se dá pra mandar mensagem na conversa aberta agora ----------
function podeEnviarNoChatAtual() {
  if (chatAtualRemovido) return false;
  if (chatAtualTipo !== 'group') return true;
  if (chatAtualModoEnvio === 'admins') return chatAtualSouAdmin;
  if (chatAtualModoEnvio === 'dono') return chatAtualSouDono;
  return true;
}

// ---------- Modo fantasma (removido) ou grupo fechado: esconde a caixa de digitar e mostra um aviso ----------
function aplicarModoSomenteLeitura() {
  const inputArea = document.querySelector('#chat-view .input-area');
  let aviso = document.getElementById('aviso-removido');

  if (!podeEnviarNoChatAtual()) {
    if (inputArea) inputArea.style.display = 'none';
    if (!aviso) {
      aviso = document.createElement('div');
      aviso.id = 'aviso-removido';
      aviso.className = 'aviso-removido';
      inputArea.parentNode.insertBefore(aviso, inputArea);
    }
    aviso.textContent = chatAtualRemovido
      ? '       Você foi saiu ou foi removido desse grupo.'
      : chatAtualModoEnvio === 'dono'
        ? 'Esse grupo está restrito: só o dono pode mandar mensagem.'
        : 'Esse grupo está fechado: só admins podem mandar mensagem.';
  } else {
    if (inputArea) inputArea.style.display = '';
    if (aviso) aviso.remove();
  }
}

// ---------- Banner de contato (só aparece quando ainda NÃO tá salvo) ----------
function renderContatoBanner() {
  const banner = document.getElementById('contato-banner');
  const salvo = chatAtualOutro && contatoSalvo(chatAtualOutro.id);

  if (!chatAtualOutro || salvo) {
    banner.classList.add('oculto');
    banner.innerHTML = '';
    return;
  }

  banner.classList.remove('oculto');
  banner.innerHTML = `<span>👤 Usuário desconhecido</span><button class="btn-salvar-contato" onclick="salvarContatoDoBanner()">Salvar contato</button>`;
}
function salvarContatoDoBanner() {
  if (!chatAtualOutro) return;
  salvarContato(chatAtualOutro);
  fetch('/api/contacts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ownerId: usuarioAtual.id, contactId: chatAtualOutro.id })
  });
  renderContatoBanner();
  mostrarAviso('Contato salvo!', 'sucesso');
}

// ---------- Menu de opções da conversa aberta (apagar / sair / bloquear) ----------
function renderMenuChatAtual() {
  const el = document.getElementById('menu-chat-atual');
  if (!chatAtualId) { el.innerHTML = ''; return; }

  if (chatAtualRemovido) {
    el.innerHTML = `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); document.querySelector('.chat-options-trigger')?.setAttribute('aria-expanded','false'); abrirAparenciaChat()"><i class="mdi mdi-palette-outline"></i><span>Aparência do chat</span></div><div class="dropdown-item dropdown-clicavel" onclick="apagarConversa(chatAtualId, true)"><span>Apagar conversa</span></div>`;
    return;
  }

  const ehAutoConversa = chatAtualOutro && chatAtualOutro.id === usuarioAtual.id;
  const chatAtualNaLista = todasAsConversas.find(c => c.id === chatAtualId);
  const estaArquivada = !!(chatAtualNaLista && chatAtualNaLista.archived);
  const itemArquivo = `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); arquivarConversa(chatAtualId, ${!estaArquivada})"><i class="mdi ${estaArquivada ? 'mdi-archive-arrow-up-outline' : 'mdi-archive-outline'}"></i><span>${estaArquivada ? 'Desarquivar conversa' : 'Arquivar conversa'}</span></div>`;

  const estaTrancada = chatsTrancados().includes(chatAtualId);
  const itemTranca = `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); alternarTrancaConversa('${chatAtualId}')"><i class="mdi ${estaTrancada ? 'mdi-lock-open-outline' : 'mdi-lock-outline'}"></i><span>${estaTrancada ? 'Destrancar conversa' : 'Trancar conversa'}</span></div>`;
  const itemRecursos = `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); document.querySelector('.chat-options-trigger')?.setAttribute('aria-expanded','false'); abrirRecursosChat()"><i class="mdi mdi-tune-variant"></i><span>Recursos do chat</span></div>`;
  const itemMidias = `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); document.querySelector('.chat-options-trigger')?.setAttribute('aria-expanded','false'); abrirMidiasELinks()"><i class="mdi mdi-image-multiple-outline"></i><span>Mídias e links</span></div>`;

  el.innerHTML = chatAtualTipo === 'group'
    ? `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); document.querySelector('.chat-options-trigger')?.setAttribute('aria-expanded','false'); abrirAparenciaChat()"><i class="mdi mdi-palette-outline"></i><span>Aparência do chat</span></div>
       ${itemRecursos}${itemMidias}${itemTranca}${itemArquivo}<div class="dropdown-item dropdown-clicavel" onclick="abrirConfigGrupo(chatAtualId)"><span>Configurações do grupo</span></div>
       <div class="dropdown-item dropdown-clicavel" onclick="apagarConversa(chatAtualId)"><span>Apagar conversa</span></div>
       <div class="dropdown-item dropdown-clicavel" onclick="sairDoGrupo(chatAtualId)"><span>Sair do grupo</span></div>`
    : `<div class="dropdown-item dropdown-clicavel" onclick="document.getElementById('menu-chat-atual').classList.add('oculto'); document.querySelector('.chat-options-trigger')?.setAttribute('aria-expanded','false'); abrirAparenciaChat()"><i class="mdi mdi-palette-outline"></i><span>Aparência do chat</span></div>
       ${itemRecursos}${itemMidias}${itemTranca}${itemArquivo}<div class="dropdown-item dropdown-clicavel" onclick="apagarConversa(chatAtualId)"><span>Apagar conversa</span></div>
       ${ehAutoConversa ? '' : `<div class="dropdown-item dropdown-clicavel" onclick="bloquearUsuario(chatAtualOutro && chatAtualOutro.id, chatAtualId)"><span>Bloquear usuário</span></div>`}`;
}

// ---------- Mídias, links e arquivos da conversa ----------
let midiasAbaAtual = 'midia';
let midiasTokenBusca = 0;
function abrirMidiasELinks(aba) {
  if (!chatAtualId) return;
  midiasAbaAtual = aba || 'midia';
  const root = document.getElementById('modal-root');
  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box modal-box--midias">
        <h3 class="modal-title">Mídias e links</h3>
        <div class="midias-abas" role="tablist">
          <button type="button" class="midias-aba" data-aba="midia">Mídia</button>
          <button type="button" class="midias-aba" data-aba="links">Links</button>
          <button type="button" class="midias-aba" data-aba="arquivos">Arquivos</button>
        </div>
        <div class="midias-conteudo" id="midias-conteudo"></div>
        <div class="modal-actions">
          <button class="btn-ok btn-compacto" id="modal-fechar-midias" type="button">Fechar</button>
        </div>
      </div>
    </div>`;
  const fechar = () => { root.innerHTML = ''; };
  document.getElementById('modal-fechar-midias').onclick = fechar;
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') fechar(); };
  root.querySelectorAll('.midias-aba').forEach(btn => { btn.onclick = () => carregarAbaMidias(btn.dataset.aba); });
  carregarAbaMidias(midiasAbaAtual);
}

async function carregarAbaMidias(aba) {
  midiasAbaAtual = aba;
  document.querySelectorAll('.midias-aba').forEach(b => b.classList.toggle('ativa', b.dataset.aba === aba));
  const alvo = document.getElementById('midias-conteudo');
  if (!alvo) return;
  const token = ++midiasTokenBusca;
  alvo.innerHTML = '<p class="midias-vazio">Carregando...</p>';
  try {
    const resp = await fetch(`/api/chats/${encodeURIComponent(chatAtualId)}/midias?userId=${encodeURIComponent(usuarioAtual.id)}&tipo=${encodeURIComponent(aba)}`);
    const data = await resp.json();
    if (token !== midiasTokenBusca) return; // trocou de aba enquanto carregava
    if (!resp.ok) throw new Error(data.error || 'Não foi possível carregar.');
    const itens = data.itens || [];
    const dataBr = ts => new Date(ts).toLocaleDateString('pt-BR');
    if (!itens.length) {
      alvo.innerHTML = `<p class="midias-vazio">${aba === 'links' ? 'Nenhum link nessa conversa.' : aba === 'arquivos' ? 'Nenhum arquivo ou áudio nessa conversa.' : 'Nenhuma foto ou vídeo nessa conversa.'}</p>` + (aba !== 'links' ? '<p class="midias-nota">Lembrete: fotos, vídeos, áudios e arquivos somem depois de 12 horas.</p>' : '');
      return;
    }
    if (aba === 'midia') {
      alvo.innerHTML = `<div class="midias-grade">${itens.map(it => {
        if (it.expirada || !it.mediaUrl) return `<div class="midias-item midias-item--expirada" title="${escapeAttr(dataBr(it.createdAt))}"><i class="mdi mdi-timer-sand"></i><small>expirou</small></div>`;
        return it.type === 'video'
          ? `<div class="midias-item" title="${escapeAttr(it.senderUsername + ' · ' + dataBr(it.createdAt))}"><video src="${escapeAttr(it.mediaUrl)}" preload="metadata" muted playsinline data-abrir="${escapeAttr(it.mediaUrl)}"></video><i class="mdi mdi-play-circle-outline midias-play"></i></div>`
          : `<div class="midias-item" title="${escapeAttr(it.senderUsername + ' · ' + dataBr(it.createdAt))}"><img src="${escapeAttr(it.mediaUrl)}" alt="" loading="lazy" data-abrir="${escapeAttr(it.mediaUrl)}"></div>`;
      }).join('')}</div>`;
      alvo.querySelectorAll('[data-abrir]').forEach(n => { n.onclick = () => window.open(n.dataset.abrir, '_blank', 'noopener'); });
    } else if (aba === 'links') {
      alvo.innerHTML = `<div class="midias-lista">${itens.map(it => `
        <button type="button" class="midias-linha" data-url="${escapeAttr(it.url)}">
          <i class="mdi mdi-link-variant"></i>
          <span class="midias-linha-txt"><strong>${escapeHtml(it.url)}</strong><small>${escapeHtml(it.senderUsername)} · ${escapeHtml(dataBr(it.createdAt))}</small></span>
        </button>`).join('')}</div>`;
      alvo.querySelectorAll('.midias-linha').forEach(n => { n.onclick = () => { document.getElementById('modal-root').innerHTML = ''; acessarLink(n.dataset.url); }; });
    } else {
      alvo.innerHTML = `<div class="midias-lista">${itens.map(it => `
        <button type="button" class="midias-linha ${it.expirada ? 'midias-linha--expirada' : ''}" ${it.mediaUrl ? `data-abrir="${escapeAttr(it.mediaUrl)}"` : 'disabled'}>
          <i class="mdi ${it.type === 'audio' ? 'mdi-microphone-outline' : 'mdi-file-document-outline'}"></i>
          <span class="midias-linha-txt"><strong>${escapeHtml(it.type === 'audio' ? 'Áudio' : (it.nome || 'Arquivo'))}${it.expirada ? ' (expirou)' : ''}</strong><small>${escapeHtml(it.senderUsername)} · ${escapeHtml(dataBr(it.createdAt))}</small></span>
        </button>`).join('')}</div>`;
      alvo.querySelectorAll('[data-abrir]').forEach(n => { n.onclick = () => window.open(n.dataset.abrir, '_blank', 'noopener'); });
    }
  } catch (e) {
    if (token === midiasTokenBusca) alvo.innerHTML = `<p class="midias-vazio">${escapeHtml(e.message || 'Não foi possível carregar.')}</p>`;
  }
}

// ---------- Personalização visual da conversa ----------
const CHAT_APPEAR_KEY = 'chatdevs_aparencia_conversa_v1';
function lerAparenciaChat() {
  try { return Object.assign({ cor: '#ffb454', opacidade: 92, estilo: 'suave', tamanhoTexto: 14, wallpaper: '' }, JSON.parse(localStorage.getItem(CHAT_APPEAR_KEY) || '{}')); }
  catch (_) { return { cor: '#ffb454', opacidade: 92, estilo: 'suave', tamanhoTexto: 14, wallpaper: '' }; }
}
function salvarAparenciaChat(cfg) {
  localStorage.setItem(CHAT_APPEAR_KEY, JSON.stringify(cfg));
  aplicarAparenciaChat();
}
function aplicarAparenciaChat() {
  const cfg = lerAparenciaChat();
  const mensagens = document.getElementById('mensagens');
  if (!mensagens) return;
  mensagens.style.setProperty('--chat-bubble-color', cfg.cor);
  mensagens.style.setProperty('--chat-bubble-opacity', `${Math.max(20, Math.min(100, Number(cfg.opacidade) || 92))}%`);
  mensagens.dataset.bubbleStyle = cfg.estilo || 'suave';
  mensagens.style.setProperty('--chat-bubble-font-size', `${Math.max(12, Math.min(22, Number(cfg.tamanhoTexto) || 14))}px`);
  if (cfg.wallpaper) {
    mensagens.style.setProperty('--chat-wallpaper-image', `url("${cfg.wallpaper}")`);
    mensagens.classList.add('com-wallpaper');
  } else {
    mensagens.style.removeProperty('--chat-wallpaper-image');
    mensagens.classList.remove('com-wallpaper');
  }
}
function abrirAparenciaChat() {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.classList.add('oculto'));
  const cfg = lerAparenciaChat();
  const root = document.getElementById('modal-root');
  if (!root) return;
  const anterior = document.getElementById('modal-aparencia-chat'); if (anterior) anterior.remove();
  const modal = document.createElement('div');
  modal.id = 'modal-aparencia-chat'; modal.className = 'chat-appearance-backdrop';
  modal.innerHTML = `
    <section class="chat-appearance-panel" role="dialog" aria-modal="true" aria-labelledby="appearance-title">
      <header class="appearance-head"><div><span class="appearance-eyebrow">PERSONALIZAÇÃO</span><h2 id="appearance-title">A aparência do seu chat</h2><p>Deixe a conversa com a sua identidade.</p></div><button type="button" class="appearance-close" aria-label="Fechar" data-close>×</button></header>
      <div class="appearance-content">
        <label class="appearance-label" for="bubble-color">Cor das bolhas</label>
        <div class="appearance-color-row"><input id="bubble-color" type="color" value="${cfg.cor}"><div class="appearance-swatches">${['#ffb454','#8b5cf6','#38bdf8','#34d399','#fb7185','#f1f5f9'].map(c=>`<button type="button" class="appearance-swatch" data-color="${c}" style="--swatch:${c}" aria-label="Cor ${c}"></button>`).join('')}</div></div>
        <div class="appearance-range-head"><label class="appearance-label" for="bubble-opacity">Opacidade das bolhas</label><output id="bubble-opacity-value">${cfg.opacidade}%</output></div>
        <input class="appearance-range" id="bubble-opacity" type="range" min="20" max="100" step="5" value="${cfg.opacidade}">
        <div class="appearance-range-head"><label class="appearance-label" for="bubble-text-size">Tamanho do texto nas bolhas</label><output id="bubble-text-size-value">${Math.max(12, Math.min(22, Number(cfg.tamanhoTexto) || 14))} px</output></div>
        <input class="appearance-range" id="bubble-text-size" type="range" min="12" max="22" step="1" value="${Math.max(12, Math.min(22, Number(cfg.tamanhoTexto) || 14))}">
        <label class="appearance-label">Estilo das bolhas</label><div class="appearance-styles"><button type="button" data-style="suave" class="appearance-style ${cfg.estilo==='suave'?'selected':''}"><span class="style-preview style-soft"></span><b>Suave</b><small>Arredondado</small></button><button type="button" data-style="compacto" class="appearance-style ${cfg.estilo==='compacto'?'selected':''}"><span class="style-preview style-compact"></span><b>Compacto</b><small>Mais discreto</small></button><button type="button" data-style="vidro" class="appearance-style ${cfg.estilo==='vidro'?'selected':''}"><span class="style-preview style-glass"></span><b>Vidro</b><small>Translúcido</small></button></div>
        <label class="appearance-label">Papel de parede</label><div class="wallpaper-actions"><button type="button" class="appearance-upload" id="appearance-upload"><i class="mdi mdi-image-plus-outline"></i><span><b>Escolher imagem</b><small>Use uma imagem do seu dispositivo</small></span><i class="mdi mdi-chevron-right"></i></button><input type="file" id="appearance-wallpaper-file" accept="image/*" hidden><button type="button" class="appearance-remove" id="appearance-remove" ${cfg.wallpaper?'':'disabled'}><i class="mdi mdi-image-remove-outline"></i> Remover imagem e voltar ao fundo padrão</button></div>
      </div><footer class="appearance-footer"><button type="button" class="appearance-reset" id="appearance-reset">Restaurar padrão</button><button type="button" class="appearance-done" data-close>Aplicar alterações</button></footer>
    </section>`;
  root.appendChild(modal);
  const color = modal.querySelector('#bubble-color'), opacity = modal.querySelector('#bubble-opacity'), textSize = modal.querySelector('#bubble-text-size');
  const update = () => { const next = {...lerAparenciaChat(), cor: color.value, opacidade: Number(opacity.value), tamanhoTexto: Number(textSize.value)}; modal.querySelector('#bubble-opacity-value').textContent = `${opacity.value}%`; modal.querySelector('#bubble-text-size-value').textContent = `${textSize.value} px`; salvarAparenciaChat(next); };
  color.addEventListener('input', update); opacity.addEventListener('input', update); textSize.addEventListener('input', update);
  modal.querySelectorAll('[data-color]').forEach(b=>b.addEventListener('click',()=>{color.value=b.dataset.color;update();}));
  modal.querySelectorAll('[data-style]').forEach(b=>b.addEventListener('click',()=>{modal.querySelectorAll('[data-style]').forEach(x=>x.classList.toggle('selected',x===b));salvarAparenciaChat({...lerAparenciaChat(),estilo:b.dataset.style});}));
  modal.querySelector('#appearance-upload').addEventListener('click',()=>modal.querySelector('#appearance-wallpaper-file').click());
  modal.querySelector('#appearance-wallpaper-file').addEventListener('change', async e=>{
    const file=e.target.files && e.target.files[0]; if(!file)return;
    if(!/^image\//i.test(file.type || '') && !/\.(gif|jpe?g|png|webp|bmp)$/i.test(file.name || '')){mostrarAviso('Escolha uma imagem ou GIF.');return;}
    if(file.size>12*1024*1024){mostrarAviso('A imagem deve ter no máximo 12 MB.');return;}
    try {
      const fd=new FormData(); fd.append('file',file);
      const up=await fetch('/api/upload',{method:'POST',body:fd}); const data=await up.json().catch(()=>({}));
      if(!up.ok||!data.url)throw new Error(data.error||'upload');
      const next={...lerAparenciaChat(),wallpaper:data.url};
      localStorage.setItem(CHAT_APPEAR_KEY,JSON.stringify(next)); aplicarAparenciaChat(); modal.querySelector('#appearance-remove').disabled=false;
      mostrarAviso('Papel de parede aplicado neste dispositivo.','sucesso');
    }catch(_){mostrarAviso('Não foi possível enviar essa imagem. Tente um GIF ou imagem menor.');}
  });
  modal.querySelector('#appearance-remove').addEventListener('click',()=>{salvarAparenciaChat({...lerAparenciaChat(),wallpaper:''});modal.querySelector('#appearance-remove').disabled=true;});
  modal.querySelector('#appearance-reset').addEventListener('click',()=>{salvarAparenciaChat({cor:'#ffb454',opacidade:92,estilo:'suave',tamanhoTexto:14,wallpaper:''});modal.remove();abrirAparenciaChat();});
  modal.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>modal.remove()));
  modal.addEventListener('click',e=>{if(e.target===modal)modal.remove();});
}
document.addEventListener('DOMContentLoaded', aplicarAparenciaChat);

// ---------- Configurações do grupo (dono/admin, remover pessoas) ----------
async function abrirConfigGrupo(chatId) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.classList.add('oculto'));
  await renderConfigGrupoModal(chatId);
}

async function renderConfigGrupoModal(chatId) {
  const resp = await fetch(`/api/chats/${chatId}/members?userId=${usuarioAtual.id}`);
  if (!resp.ok) { mostrarAviso('Não foi possível abrir as configurações do grupo.'); return; }
  const data = await resp.json();
  const root = document.getElementById('modal-root');

  let convite = null;
  if (data.souAdmin) {
    const respConvite = await fetch(`/api/chats/${chatId}/invite?userId=${usuarioAtual.id}`);
    if (respConvite.ok) convite = await respConvite.json();
  }

  const linhas = data.membros.map(m => {
    const papel = m.isOwner ? '<span class="tag-papel tag-dono">Dono</span>'
      : m.isAdmin ? '<span class="tag-papel tag-admin">Admin</span>' : '';

    let botoes = '';
    if (data.souAdmin && !m.isOwner && !m.isAdmin) {
      botoes += `<button class="btn-outline btn-compacto" onclick="promoverNoModal('${chatId}', '${m.id}')">Tornar admin</button>`;
    }
    if (data.souAdmin && !m.isOwner && m.isAdmin) {
      botoes += `<button class="btn-outline btn-compacto" onclick="rebaixarNoModal('${chatId}', '${m.id}')">Tirar admin</button>`;
    }
    if ((data.souDono || data.souAdmin) && !m.isOwner && m.id !== usuarioAtual.id) {
      botoes += `<button class="btn-outline btn-compacto" onclick="removerDoModal('${chatId}', '${m.id}', '${escapeHtml(m.username)}')">Remover</button>`;
    }

    const souEu = m.id === usuarioAtual.id;
    const cliqueInfo = souEu
      ? ''
      : ` onclick="iniciarConversaComContato('${m.id}', '${escapeHtml(m.username)}', ${m.email ? `'${escapeHtml(m.email)}'` : 'null'}, ${m.photoUrl ? `'${escapeAttr(m.photoUrl)}'` : 'null'})" style="cursor:pointer"`;

    return `
      <div class="dropdown-item conta-item">
        <span class="conta-info"${cliqueInfo}>
          <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(m.username, m.photoUrl)}</span>
          <span>${souEu ? 'Você' : escapeHtml(m.username)}</span>
          ${papel}
        </span>
        <span class="config-grupo-botoes">${botoes}</span>
      </div>`;
  }).join('');

  const botaoAdicionar = data.souAdmin
    ? `<div class="config-grupo-acoes-topo">
         <button class="btn-outline btn-compacto" id="modal-adicionar-membros" type="button">+ Adicionar pessoas</button>
         <button class="btn-outline btn-compacto" id="modal-editar-nome" type="button">Editar nome</button>
       </div>`
    : '';

  const painelMembros = `
    <div class="config-grupo-painel" data-painel="membros">
      ${botaoAdicionar}
      <div class="lista-contatos">${linhas}</div>
    </div>`;

  // sempre tem pelo menos "Membros" e "Saíram"; "Permissões" e "Convite" só aparecem pra admin
  const painelSaidos = `
    <div class="config-grupo-painel oculto" data-painel="saidos">
      <div class="lista-contatos">${montarListaSaidos(data.saidos || [])}</div>
    </div>`;

  const totalSaidos = (data.saidos || []).length;
  let tabsHtml = `
    <button class="config-grupo-tab ativa" data-tab="membros" type="button">Membros</button>
    <button class="config-grupo-tab" data-tab="saidos" type="button">Saíram${totalSaidos ? ` (${totalSaidos})` : ''}</button>`;

  let painelPermissoes = '';
  if (data.souAdmin) {
    tabsHtml += `<button class="config-grupo-tab" data-tab="permissoes" type="button">Permissões</button>`;
    painelPermissoes = `<div class="config-grupo-painel oculto" data-painel="permissoes">${montarPainelPermissoes(data)}</div>`;
  }

  let painelConvite = '';
  if (convite) {
    const totalPedidos = convite.joinRequests.length;
    const badge = totalPedidos ? `<span class="config-grupo-badge">${totalPedidos}</span>` : '';
    tabsHtml += `<button class="config-grupo-tab" data-tab="convite" type="button">Pedidos${badge}</button>`;
    painelConvite = `<div class="config-grupo-painel oculto" data-painel="convite">${montarSecaoConvite(chatId, convite)}</div>`;
  }
  const abasHtml = `<div class="config-grupo-tabs">${tabsHtml}</div>`;

  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box modal-box--grupo">
        <h3 class="modal-title">Configurações do grupo</h3>
        ${abasHtml}
        <div class="config-grupo-corpo">
          ${painelMembros}
          ${painelSaidos}
          ${painelPermissoes}
          ${painelConvite}
        </div>
        <div class="modal-actions">
          <button class="btn-ok btn-compacto" id="modal-fechar-config-grupo" type="button">Fechar</button>
        </div>
      </div>
    </div>`;

  document.getElementById('modal-fechar-config-grupo').onclick = () => { root.innerHTML = ''; };
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') root.innerHTML = ''; };

  root.querySelectorAll('.config-grupo-tab').forEach(tab => {
    tab.onclick = () => {
      root.querySelectorAll('.config-grupo-tab').forEach(t => t.classList.remove('ativa'));
      tab.classList.add('ativa');
      root.querySelectorAll('.config-grupo-painel').forEach(p => {
        p.classList.toggle('oculto', p.dataset.painel !== tab.dataset.tab);
      });
    };
  });

  if (data.souAdmin) {
    document.getElementById('modal-adicionar-membros').onclick = () => adicionarMembrosNoModal(chatId);
    document.getElementById('modal-editar-nome').onclick = () => editarNomeGrupo(chatId, data.name);
    ligarEventosConvite(chatId);
    ligarEventosPermissoes(chatId);
  }
}

// ---------- Painel "Permissões": quem pode mandar mensagem no grupo ----------
function montarPainelPermissoes(data) {
  const modo = data.modoEnvio || 'todos';
  const opcoes = [
    { valor: 'todos', label: 'Todos podem mandar mensagem', desc: 'Qualquer membro consegue conversar no grupo.' },
    { valor: 'admins', label: 'Só admins podem mandar mensagem', desc: 'Grupo fechado: membros comuns só conseguem ler.' }
  ];
  if (data.souDono) {
    opcoes.push({
      valor: 'dono',
      label: 'Só eu posso mandar mensagem',
      desc: 'Trava total: nem os admins conseguem mandar mensagem, só você.'
    });
  }

  const linhas = opcoes.map(o => `
    <label class="permissao-opcao${o.valor === modo ? ' permissao-opcao--ativa' : ''}">
      <input type="radio" name="modo-envio" value="${o.valor}" ${o.valor === modo ? 'checked' : ''}>
      <span class="permissao-opcao-texto">
        <strong>${o.label}</strong>
        <small>${o.desc}</small>
      </span>
    </label>`).join('');

  return `
    <p class="modal-texto">Quem pode mandar mensagem nesse grupo?</p>
    <div class="permissoes-lista">${linhas}</div>`;
}

function ligarEventosPermissoes(chatId) {
  document.querySelectorAll('input[name="modo-envio"]').forEach(input => {
    input.onchange = async () => {
      const modo = input.value;
      const resp = await fetch(`/api/chats/${chatId}/modo-envio`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: usuarioAtual.id, modo })
      });
      const data = await resp.json();
      if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar isso.'); renderConfigGrupoModal(chatId); return; }
      if (chatAtualId === chatId) { chatAtualModoEnvio = modo; aplicarModoSomenteLeitura(); }
      renderConfigGrupoModal(chatId);
    };
  });
}

// ---------- Lista de quem saiu (ou foi removido) do grupo, com data/hora e foto ----------
function montarListaSaidos(saidos) {
  if (!saidos.length) return '<p class="modal-texto">Ninguém saiu desse grupo ainda.</p>';
  return saidos.map(s => {
    const quandoData = new Date(s.saiuEm);
    const quando = `${quandoData.toLocaleDateString('pt-BR')} às ${quandoData.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
    return `
      <div class="dropdown-item conta-item">
        <span class="conta-info">
          <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(s.username, s.photoUrl)}</span>
          <span>${escapeHtml(s.username)}</span>
        </span>
        <span class="saiu-quando">${quando}</span>
      </div>`;
  }).join('');
}

// ---------- Editar nome do grupo (dono/admin) ----------
async function editarNomeGrupo(chatId, nomeAtual) {
  const valores = await abrirModal({
    titulo: 'Editar nome do grupo',
    campos: [{ id: 'nome', label: 'Nome do grupo', placeholder: 'Nome do grupo', valor: nomeAtual }],
    textoBotao: 'Salvar'
  });
  if (!valores || !valores.nome) return;

  const resp = await fetch(`/api/chats/${chatId}/rename`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, name: valores.nome })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar o nome do grupo.'); return; }

  if (chatAtualId === chatId) document.getElementById('chat-header-nome').textContent = data.name;
  carregarListaChats();
  renderConfigGrupoModal(chatId);
}

// ---------- Deixa links dentro de um texto clicáveis, sem virar botão (usado na descrição do grupo) ----------
function linkificarTexto(texto) {
  const escapado = escapeHtml(texto);
  return escapado.replace(/https?:\/\/[^\s<]+/gi, url => `<a href="${url}" target="_blank" rel="noopener">${url}</a>`);
}

// ---------- Janela de info do grupo (foto/nome/descrição), aberta ao clicar no ícone ou no nome do grupo no topo ----------
async function abrirInfoGrupo() {
  if (chatAtualTipo !== 'group' || !chatAtualId) return; // em PV isso ainda não existe
  const chatId = chatAtualId;
  const resp = await fetch(`/api/chats/${chatId}/members?userId=${usuarioAtual.id}`);
  if (!resp.ok) { mostrarAviso('Não foi possível abrir as informações do grupo.'); return; }
  const data = await resp.json();
  renderInfoGrupoModal(chatId, data);
}

function renderInfoGrupoModal(chatId, data) {
  const root = document.getElementById('modal-root');

  const descricaoHtml = data.description
    ? `<p class="info-grupo-descricao">${linkificarTexto(data.description)}</p>`
    : `<p class="info-grupo-descricao info-grupo-descricao--vazia">Esse grupo ainda não tem descrição.</p>`;

  const totalMembrosHtml = `<p class="info-grupo-criacao">${data.membros.length} membro${data.membros.length === 1 ? '' : 's'}</p>`;

  const dataCriacao = data.criadoEm ? new Date(data.criadoEm).toLocaleDateString('pt-BR') : null;
  const infoCriacaoHtml = dataCriacao
    ? `<p class="info-grupo-criacao">Criado por ${escapeHtml(data.criadoPor)} em ${dataCriacao}</p>`
    : '';

  const botaoEditar = data.souAdmin
    ? `<button class="btn-outline btn-compacto" id="info-grupo-editar" type="button">Editar descrição</button>`
    : '';

  const acoesFotoHtml = data.souAdmin
    ? `<div class="info-grupo-acoes-foto">
         <button class="link-sutil" id="info-grupo-trocar-banner" type="button"><i class="mdi mdi-panorama-outline"></i> ${data.bannerUrl ? 'Trocar banner' : 'Adicionar banner'}</button>
         ${data.bannerUrl ? '<button class="link-sutil" id="info-grupo-remover-banner" type="button">Remover banner</button>' : ''}
         <button class="link-sutil" id="info-grupo-trocar-foto" type="button"><i class="mdi mdi-camera-outline"></i> Trocar foto</button>
         ${data.photoUrl ? `<button class="link-sutil" id="info-grupo-remover-foto" type="button">Remover foto</button>` : ''}
       </div>`
    : '';

  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box modal-box--grupo modal-box--info-grupo">
        <div class="info-grupo-topo info-grupo-topo--banner">
          <div class="info-grupo-banner" ${data.bannerUrl ? `style="background-image:url('${escapeAttr(data.bannerUrl)}')"` : ''}></div>
          <div class="avatar-circle avatar-circle--lg info-grupo-avatar">${avatarInnerHtml(data.name, data.photoUrl)}</div>
          <h3 class="modal-title info-grupo-nome">${escapeHtml(data.name)}</h3>
          ${acoesFotoHtml}
          <input type="file" id="info-grupo-foto-input" accept="image/*" style="display:none">
          <input type="file" id="info-grupo-banner-input" accept="image/*" style="display:none">
        </div>
        ${descricaoHtml}
        ${totalMembrosHtml}
        ${infoCriacaoHtml}
        <div class="modal-actions">
          ${botaoEditar}
          <button class="btn-ok btn-compacto" id="info-grupo-fechar" type="button">Fechar</button>
        </div>
      </div>
    </div>`;

  document.getElementById('info-grupo-fechar').onclick = () => { root.innerHTML = ''; };
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') root.innerHTML = ''; };
  if (data.souAdmin) {
    document.getElementById('info-grupo-editar').onclick = () => editarDescricaoGrupo(chatId, data.description);
    document.getElementById('info-grupo-trocar-foto').onclick = () => document.getElementById('info-grupo-foto-input').click();
    document.getElementById('info-grupo-trocar-banner').onclick = () => document.getElementById('info-grupo-banner-input').click();
    document.getElementById('info-grupo-banner-input').onchange = e => { if (e.target.files[0]) trocarBannerGrupo(chatId, e.target.files[0]); };
    const btnRemoverBanner = document.getElementById('info-grupo-remover-banner');
    if (btnRemoverBanner) btnRemoverBanner.onclick = () => trocarBannerGrupo(chatId, null);
    document.getElementById('info-grupo-foto-input').onchange = e => {
      if (e.target.files[0]) trocarFotoGrupo(chatId, e.target.files[0]);
    };
    const btnRemover = document.getElementById('info-grupo-remover-foto');
    if (btnRemover) btnRemover.onclick = () => trocarFotoGrupo(chatId, null);
  }
}

// ---------- Trocar (ou remover, se arquivo for null) a foto do grupo ----------
async function trocarFotoGrupo(chatId, arquivo) {
  let photoUrl = null;
  if (arquivo) {
    const formData = new FormData();
    formData.append('file', arquivo);
    const uploadResp = await fetch('/api/upload', { method: 'POST', body: formData });
    const uploadData = await uploadResp.json();
    if (!uploadResp.ok) { mostrarAviso('Não foi possível enviar a imagem.'); return; }
    photoUrl = uploadData.url;
  }

  const resp = await fetch(`/api/chats/${chatId}/photo`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, photoUrl })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar a foto do grupo.'); return; }

  carregarListaChats();
  if (chatAtualId === chatId) {
    document.getElementById('chat-header-avatar').innerHTML = avatarInnerHtml(
      document.getElementById('chat-header-nome').textContent, data.photoUrl
    );
  }
  abrirInfoGrupo(); // reabre já com a foto atualizada
}

async function trocarBannerGrupo(chatId, arquivo) {
  let bannerUrl = null;
  if (arquivo) {
    const formData = new FormData(); formData.append('file', arquivo);
    const uploadResp = await fetch('/api/upload', { method: 'POST', body: formData });
    const uploadData = await uploadResp.json();
    if (!uploadResp.ok) { mostrarAviso(uploadData.error || 'Não foi possível enviar o banner.'); return; }
    bannerUrl = uploadData.url;
  }
  const resp = await fetch(`/api/chats/${chatId}/banner`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: usuarioAtual.id, bannerUrl }) });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar o banner.'); return; }
  abrirInfoGrupo();
}

// ---------- Editar a descrição do grupo (dono/admin) ----------
async function editarDescricaoGrupo(chatId, descricaoAtual) {
  const valores = await abrirModal({
    titulo: 'Descrição do grupo',
    campos: [{
      id: 'descricao',
      label: 'Descrição',
      placeholder: 'Do que esse grupo trata?',
      valor: descricaoAtual,
      tipo: 'textarea'
    }],
    textoBotao: 'Salvar'
  });
  if (valores === null) return; // cancelou

  const resp = await fetch(`/api/chats/${chatId}/description`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, description: valores.descricao })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar a descrição do grupo.'); return; }

  abrirInfoGrupo(); // reabre a janela já com a descrição atualizada
}

// ---------- Lista de pedidos pra entrar, com botões de aprovar/recusar (usada na janelinha rápida e na aba Convite) ----------
function montarListaPedidos(chatId, joinRequests) {
  return joinRequests.length
    ? joinRequests.map(p => `
        <div class="dropdown-item conta-item">
          <span class="conta-info">
            <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(p.username, p.photoUrl)}</span>
            <span>${escapeHtml(p.username)}</span>
          </span>
          <span class="config-grupo-botoes">
            <button class="btn-ok btn-compacto" onclick="responderPedidoEntrada('${chatId}', '${p.userId}', true)">Aprovar</button>
            <button class="btn-outline btn-compacto" onclick="responderPedidoEntrada('${chatId}', '${p.userId}', false)">Recusar</button>
          </span>
        </div>`).join('')
    : '<p class="modal-texto">Nenhum pedido pendente.</p>';
}

// ---------- Seção "Link de convite" dentro de Configurações do grupo (só admin vê) ----------
function montarSecaoConvite(chatId, convite) {
  const link = `${location.origin}${location.pathname}?convite=${convite.code}`;
  const pedidosHtml = montarListaPedidos(chatId, convite.joinRequests);

  return `
    <h4 class="modal-subtitulo">Link de convite</h4>
    <div class="convite-link-row">
      <input class="modal-input" id="convite-link-input" type="text" value="${escapeHtml(link)}" readonly>
      <button class="btn-outline btn-compacto" id="convite-copiar">Copiar</button>
    </div>
    <label class="modal-label modal-label-checkbox">
      <input type="checkbox" id="convite-aprovacao" ${convite.approvalRequired ? 'checked' : ''}>
      Exigir aprovação de admin pra entrar pelo link
    </label>
    <button class="btn-outline btn-compacto" id="convite-redefinir" type="button">Gerar novo link</button>

    <h4 class="modal-subtitulo config-grupo-subtitulo-pedidos">Pedidos pra entrar</h4>
    ${pedidosHtml}`;
}

function ligarEventosConvite(chatId) {
  const btnCopiar = document.getElementById('convite-copiar');
  if (btnCopiar) btnCopiar.onclick = () => {
    const input = document.getElementById('convite-link-input');
    input.select();
    navigator.clipboard.writeText(input.value).then(
      () => mostrarAviso('Link copiado!', 'sucesso'),
      () => document.execCommand('copy') // navegador antigo sem clipboard API
    );
  };

  const checkAprovacao = document.getElementById('convite-aprovacao');
  if (checkAprovacao) checkAprovacao.onchange = async () => {
    const ativo = checkAprovacao.checked;
    const resp = await fetch(`/api/chats/${chatId}/invite/approval`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id, ativo })
    });
    if (!resp.ok) { checkAprovacao.checked = !ativo; mostrarAviso('Não foi possível mudar isso.'); }
  };

  const btnRedefinir = document.getElementById('convite-redefinir');
  if (btnRedefinir) btnRedefinir.onclick = async () => {
    const aceitou = await abrirConfirmacao({
      titulo: 'Gerar novo link',
      mensagem: 'O link antigo para de funcionar. Continuar?',
      textoBotao: 'Gerar novo link'
    });
    if (!aceitou) return;
    const resp = await fetch(`/api/chats/${chatId}/invite/reset`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id })
    });
    if (resp.ok) renderConfigGrupoModal(chatId);
    else mostrarAviso('Não foi possível gerar um novo link.');
  };
}

async function responderPedidoEntrada(chatId, targetUserId, aprovar) {
  const resp = await fetch(`/api/chats/${chatId}/invite/responder`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, targetUserId, aprovar })
  });
  if (!resp.ok) { mostrarAviso('Não foi possível responder esse pedido.'); return; }
  if (document.getElementById('pedidos-fechar')) abrirPedidosPendentes(chatId);
  else renderConfigGrupoModal(chatId);
  carregarListaChats();
  if (chatAtualId === chatId) atualizarBadgePedidos(chatId);
}

// ---------- Adicionar pessoas a um grupo já existente (dono/admin) ----------
async function adicionarMembrosNoModal(chatId) {
  const valores = await abrirModal({
    titulo: 'Adicionar pessoas ao grupo',
    campos: [
      { id: 'membros', label: 'Email ou usuário (separados por vírgula)', placeholder: 'maria, joao@email.com' }
    ],
    textoBotao: 'Adicionar'
  });
  if (!valores || !valores.membros) return;
  const lista = valores.membros.split(',').map(s => s.trim()).filter(Boolean);
  if (!lista.length) return;

  const resp = await fetch(`/api/chats/${chatId}/add-members`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, memberQueries: lista })
  });
  const data = await resp.json();

  if (!resp.ok) {
    mostrarAviso(data.error || 'Não foi possível adicionar essas pessoas.');
    return;
  }
  if (data.naoEncontrados && data.naoEncontrados.length) {
    mostrarAviso('Não encontrado: ' + data.naoEncontrados.join(', '));
  }
  if (data.bloqueados && data.bloqueados.length) {
    data.bloqueados.forEach(nome => mostrarAviso('Não foi possível adicionar ' + nome));
  }
  if (data.jaNoGrupo && data.jaNoGrupo.length) {
    data.jaNoGrupo.forEach(nome => mostrarAviso(nome + ' já está no grupo'));
  }
  renderConfigGrupoModal(chatId);
  carregarListaChats();
}

async function promoverNoModal(chatId, targetUserId) {
  const resp = await fetch(`/api/chats/${chatId}/promote`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, targetUserId })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível dar admin.'); return; }
  renderConfigGrupoModal(chatId);
}

async function rebaixarNoModal(chatId, targetUserId) {
  const resp = await fetch(`/api/chats/${chatId}/demote`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, targetUserId })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível tirar o admin.'); return; }
  renderConfigGrupoModal(chatId);
}

async function removerDoModal(chatId, targetUserId, username) {
  const aceitou = await abrirConfirmacao({
    titulo: 'Remover do grupo',
    mensagem: `Remover ${username} do grupo?`,
    textoBotao: 'Remover'
  });
  if (!aceitou) return;
  const resp = await fetch(`/api/chats/${chatId}/remove-member`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, targetUserId })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível remover essa pessoa.'); return; }
  renderConfigGrupoModal(chatId);
  carregarListaChats();
}

async function apagarConversa(chatId, removido) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.classList.add('oculto'));
  const mensagem = removido
    ? 'Apagar essa conversa da sua lista? Ela só some pra você.'
    : ((todasAsConversas.find(c => c.id === chatId) || {}).type === 'group')
      ? 'Apagar essa conversa? Isso apaga pra todo mundo que participa dela, não só pra você.'
      : 'Apagar essa conversa? Ela só some pra você, a outra pessoa continua com ela.';
  const aceitou = await abrirConfirmacao({ titulo: 'Apagar conversa', mensagem, textoBotao: 'Apagar' });
  if (!aceitou) return;

  await fetch(`/api/chats/${chatId}/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id })
  });

  if (chatAtualId === chatId) voltarHome();
  carregarListaChats();
  carregarStats();
}

async function sairDoGrupo(chatId) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.classList.add('oculto'));
  const aceitou = await abrirConfirmacao({
    titulo: 'Sair do grupo',
    mensagem: 'Sair desse grupo? Você para de receber as mensagens dele.',
    textoBotao: 'Sair'
  });
  if (!aceitou) return;

  await fetch(`/api/chats/${chatId}/leave`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id })
  });

  if (chatAtualId === chatId) voltarHome();
  carregarListaChats();
}

async function bloquearUsuario(blockedId, chatId) {
  document.querySelectorAll('.dropdown-menu').forEach(el => el.classList.add('oculto'));
  if (!blockedId) return;
  const aceitou = await abrirConfirmacao({
    titulo: 'Bloquear usuário',
    mensagem: 'Bloquear esse usuário? Vocês não vão mais poder trocar mensagens, e a conversa atual será apagada.',
    textoBotao: 'Bloquear'
  });
  if (!aceitou) return;

  await fetch('/api/block', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id, blockedId })
  });

  if (chatId) {
    await fetch(`/api/chats/${chatId}/delete`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: usuarioAtual.id })
    });
  }

  if (chatAtualId === chatId) voltarHome();
  carregarListaChats();
  carregarStats();
}

// ---------- Voltar pra home ----------
function voltarHome() {
  atualizarBotoesChamada(true);
  chatAtualId = null;
  chatAtualTipo = null;
  chatAtualOutro = null;
  chatAtualRemovido = false;
  esconderBadgePedidos();
  informarTelaVisivel();
  document.getElementById('chat-view').classList.add('oculto');
  document.getElementById('home-view').classList.remove('oculto');
  mostrarListaMobile();
  renderizarListaChats();
}

// Barra fixa no topo, como no WhatsApp, para saltar à mensagem fixada.
function renderBannerMensagemFixada(lista = Array.from(mensagensCacheAtual.values())) {
  const container = document.getElementById('mensagens');
  if (!container) return;
  let banner = document.getElementById('mensagem-fixada-topo');
  clearTimeout(timerExpiraFixada);
  const pinned = (lista || []).find(m => m.pinned);
  if (!pinned) { if (banner) banner.remove(); return; }
  if (pinned.pinnedUntil) {
    const falta = pinned.pinnedUntil - Date.now();
    if (falta <= 0) { setTimeout(() => expirarFixada(pinned.id), 0); }
    else if (falta < 2147483000) timerExpiraFixada = setTimeout(() => expirarFixada(pinned.id), falta + 500);
  }
  if (!banner) {
    banner = document.createElement('button');
    banner.id = 'mensagem-fixada-topo';
    banner.className = 'mensagem-fixada-topo';
    banner.type = 'button';
    banner.onclick = () => {
      const target = document.querySelector(`#mensagens .msg[data-id="${banner.dataset.messageId}"]`);
      if (target) { target.scrollIntoView({ behavior: 'smooth', block: 'center' }); target.classList.add('msg-destacada'); setTimeout(() => target.classList.remove('msg-destacada'), 1400); }
    };
    container.parentElement.insertBefore(banner, container);
  }
  banner.dataset.messageId = pinned.id;
  const resumo = pinned.deleted ? 'Mensagem apagada' : (pinned.content || (pinned.type === 'image' ? '📷 Foto' : pinned.type === 'audio' ? '🎤 Áudio' : pinned.type === 'video' ? '🎬 Vídeo' : pinned.type === 'file' ? '📎 Arquivo' : 'Mensagem fixada'));
  banner.innerHTML = `<span class="pin-banner-icon"><i class="mdi mdi-pin"></i></span><span class="pin-banner-copy"><strong>Mensagem fixada${pinned.pinnedUntil ? ' · até ' + escapeHtml(new Date(pinned.pinnedUntil).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) + ' ' + new Date(pinned.pinnedUntil).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })) : ''}</strong><small>${escapeHtml(resumo).slice(0, 130)}</small></span><i class="mdi mdi-chevron-right pin-banner-arrow"></i>`;
}

// ---------- Renderizar mensagens ----------
function chaveDia(ts) {
  const d = new Date(ts);
  return d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate();
}
function rotuloDia(ts) {
  const d = new Date(ts), hoje = new Date();
  const inicio = x => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((inicio(hoje) - inicio(d)) / 86400000);
  if (diff === 0) return 'Hoje';
  if (diff === 1) return 'Ontem';
  if (diff > 1 && diff < 7) {
    const nome = d.toLocaleDateString('pt-BR', { weekday: 'long' });
    return nome.charAt(0).toUpperCase() + nome.slice(1);
  }
  return d.toLocaleDateString('pt-BR');
}
function criarSeparadorData(ts) {
  const sep = document.createElement('div');
  sep.className = 'msg-data-sep';
  sep.innerHTML = `<span>${escapeHtml(rotuloDia(ts))}</span>`;
  return sep;
}
function classeRecibo(msg) {
  const delivered = Array.isArray(msg.deliveredTo) && msg.deliveredTo.length > 0;
  const read = Array.isArray(msg.readBy) && msg.readBy.length > 0;
  return read ? 'receipt-read' : delivered ? 'receipt-delivered' : 'receipt-sent';
}
function textoRecibo(msg) {
  const cls = classeRecibo(msg);
  return cls === 'receipt-read' || cls === 'receipt-delivered' ? '✓✓' : '✓';
}
function tituloRecibo(msg) {
  const cls = classeRecibo(msg);
  return cls === 'receipt-read' ? 'Recebida e lida' : cls === 'receipt-delivered' ? 'Recebida' : 'Enviada';
}

function renderizarMensagem(msg) {
  const container = document.getElementById('mensagens');
  if (container.querySelector(`[data-id="${msg.id}"]`)) return;
  // primeira mensagem do dia ganha o separador (Hoje, Ontem, dia da semana ou data), estilo WhatsApp
  const dia = chaveDia(msg.createdAt);
  if (container.dataset.ultimoDia !== dia) {
    container.appendChild(criarSeparadorData(msg.createdAt));
    container.dataset.ultimoDia = dia;
  }
  const el = criarElementoMensagem(msg);
  container.appendChild(el);
  container.scrollTop = container.scrollHeight;
  if (msg.type !== 'system') mensagensCacheAtual.set(msg.id, msg);
}

// ---------- Monta o elemento DOM de uma mensagem (sem colocar na tela) ----------
// Existe separado do renderizarMensagem pra poder ser reaproveitado quando uma
// mensagem precisa ser TOTALMENTE reconstruída do zero (ex: quando ela é apagada em
// tempo real) — assim garante que nada "sobra" na tela por engano, tipo o botão
// de Acessar, em vez de depender de remover pedaço por pedaço do HTML antigo.
function criarElementoMensagem(msg) {
  if (msg.type === 'system') {
    const aviso = document.createElement('div');
    aviso.className = 'msg-sistema';
    aviso.dataset.id = msg.id;
    aviso.textContent = msg.content;
    return aviso;
  }

  const div = document.createElement('div');
  // O servidor informa explicitamente o lado da mensagem por destinatário.
  // O fallback mantém compatibilidade com mensagens históricas antigas.
  const minha = typeof msg.isOwnMessage === 'boolean'
    ? msg.isOwnMessage
    : String(msg.senderId) === String(usuarioAtual.id);
  div.className = 'msg' + (minha ? ' minha' : '');
  div.dataset.id = msg.id;

  let remetenteHtml = '';
  if (chatAtualTipo === 'group' && !minha && msg.senderUsername) {
    const saiuBadge = msg.senderSaiuDoGrupo
      ? `<span class="msg-remetente-saiu" title="Não está mais no grupo">✕</span>`
      : '';
    const cargo = msg.senderIsOwner ? '<span class="msg-selo-cargo" title="Dono do grupo"><i class="mdi mdi-crown-outline"></i> Dono</span>' : msg.senderIsAdmin ? '<span class="msg-selo-cargo" title="Administrador"><i class="mdi mdi-shield-account-outline"></i> Admin</span>' : '';
    remetenteHtml = `<div class="msg-remetente">
      <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(msg.senderUsername, msg.senderPhotoUrl)}</span>
      <span class="msg-remetente-nome">${escapeHtml(msg.senderUsername)}</span>
      ${cargo}
      ${saiuBadge}
    </div>`;
  }

  let replyHtml = '';
  if (msg.replyTo) {
    if (typeof msg.replyTo === 'object') {
      const rt = msg.replyTo;
      replyHtml = `<div class="quote-box" onclick="irParaMensagem('${rt.id}')">
        <div class="quote-nome">${escapeHtml(nomeDoCitado(rt))}</div>
        <div class="quote-snippet">${escapeHtml(rt.snippet)}</div>
      </div>`;
    } else {
      // mensagens antigas, gravadas antes dessa melhoria, só guardavam o id
      replyHtml = `<div class="reply-ref" onclick="irParaMensagem('${msg.replyTo}')">↑ Respondendo a uma mensagem</div>`;
    }
  }

  let conteudoHtml;
  if (msg.deleted) {
    conteudoHtml = `<div class="conteudo apagada">Mensagem apagada</div>`;
  } else if (msg.type === 'audio') {
    conteudoHtml = msg.mediaUrl
      ? `<div class="conteudo conteudo-midia">${montarPlayerAudio(msg)}</div>`
      : `<div class="conteudo apagada">Áudio expirado (12h)</div>`;
  } else if (msg.type === 'video') {
    conteudoHtml = msg.mediaUrl
      ? `<div class="conteudo"><video controls width="220" src="${msg.mediaUrl}"></video></div>${msg.content ? `<div class="conteudo legenda-midia">${destacarMencoes(msg.content)}</div>` : ''}`
      : `<div class="conteudo apagada">Vídeo expirado (12h)</div>`;
  } else if (msg.type === 'image') {
    conteudoHtml = msg.mediaUrl
      ? `<div class="conteudo"><img class="msg-imagem" src="${msg.mediaUrl}" alt="" onclick="window.open('${msg.mediaUrl}','_blank')"></div>${msg.content ? `<div class="conteudo legenda-midia">${destacarMencoes(msg.content)}</div>` : ''}`
      : `<div class="conteudo apagada">Imagem expirada (12h)</div>`;
  } else if (msg.type === 'sticker') {
    const stickerUrl = encodeURIComponent(msg.mediaUrl || '');
    const stickerDescription = encodeURIComponent(msg.content || 'Figurinha');
    const stickerOwner = encodeURIComponent(msg.senderId || '');
    conteudoHtml = msg.mediaUrl ? `<div class="conteudo sticker-message" role="button" tabindex="0" onclick="event.preventDefault();event.stopPropagation();abrirPreviewFigurinhaDadosEncoded('${stickerUrl}','${stickerDescription}','${stickerOwner}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();abrirPreviewFigurinhaDadosEncoded('${stickerUrl}','${stickerDescription}','${stickerOwner}')}"><img class="msg-sticker" src="${escapeAttr(msg.mediaUrl)}" alt="Figurinha" loading="lazy"><span class="sticker-tap-hint">Toque para visualizar</span></div>` : `<div class="conteudo apagada">Figurinha indisponível</div>`;
  } else if (msg.type === 'file') {
    conteudoHtml = msg.mediaUrl
      ? `<div class="conteudo conteudo-midia">${montarCartaoArquivo(msg)}</div>`
      : `<div class="conteudo apagada">Arquivo expirado (12h)</div>`;
  } else if (msg.type === 'poll' && msg.poll) {
    const total = (msg.poll.options || []).reduce((n, o) => n + (o.votes || []).length, 0);
    conteudoHtml = `<div class="conteudo enquete-card"><strong>${escapeHtml(msg.poll.question || msg.content || 'Enquete')}</strong><div class="enquete-opcoes">${(msg.poll.options || []).map(o => { const votos = (o.votes || []).length; const pct = total ? Math.round(votos * 100 / total) : 0; return `<button type="button" class="enquete-opcao" onclick="votarEnquete('${msg.id}','${escapeAttr(o.id)}')"><span>${escapeHtml(o.text)}</span><small>${pct}% · ${votos}</small></button>`; }).join('')}</div><small class="enquete-total">${total} voto(s)</small></div>`;
  } else {
    conteudoHtml = `<div class="conteudo">${destacarMencoes(msg.content)}</div>`;
  }

  const linkDaMensagem = (!msg.deleted && msg.type === 'text') ? extrairPrimeiroLink(msg.content) : null;
  const linkBtnHtml = linkDaMensagem ? montarPreviaLink(linkDaMensagem) : '';

  // Em áudio, vídeo, imagem e arquivo, o player/anexo ocupa o toque inteiro
  // (dá play, abre em tela cheia, baixa o arquivo...) então o hover e o
  // swipe-pra-responder não são um jeito confiável de chegar no "Responder".
  // Por isso essas mensagens ganham um botãozinho de responder sempre visível.
  const btnResponderRapidoHtml = ''; // Ações ficam ocultas até pressionar a mensagem

  const hora = new Date(msg.createdAt).toLocaleTimeString().slice(0, 5);
  const editadoTxt = msg.editedAt ? ' (editada)' : '';

  let acoesHtml = '<div class="acoes" aria-label="Ações da mensagem">';
  if (!msg.deleted) acoesHtml += `<span onclick="alternarSeletorReacao('${msg.id}', event)">Reagir</span>`;
  acoesHtml += `<span onclick="responderMensagem('${msg.id}')">Responder</span>`;
  if (!msg.deleted) acoesHtml += `<span onclick="iniciarEncaminhar('${msg.id}')">Encaminhar</span>`;
  if (!msg.deleted && !chatAtualRemovido) acoesHtml += `<span onclick="fixarMensagem('${msg.id}')">${msg.pinned ? 'Desafixar' : 'Fixar'}</span>`;
  if (minha && !msg.deleted) {
    if (Date.now() - msg.createdAt < 60000 && msg.type === 'text') {
      acoesHtml += `<span onclick="editarMensagem('${msg.id}')">Editar</span>`;
    }
    acoesHtml += `<span onclick="apagarMensagem('${msg.id}')">Apagar</span>`;
  }
  acoesHtml += '</div>';

  const minhasReacoes = Array.isArray(msg.reactions) ? msg.reactions : [];
  const emojisApple = [...new Set(minhasReacoes.map(r => r.emoji).filter(Boolean))];
  const resumoReacoes = emojisApple.map(emoji => {
    const quantidade = minhasReacoes.filter(r => r.emoji === emoji).length;
    if (!quantidade) return '';
    const minhaReacao = minhasReacoes.some(r => r.userId === usuarioAtual.id && r.emoji === emoji);
    return `<button class="reaction-chip ${minhaReacao ? 'minha-reacao' : ''}" onclick="reagirMensagem('${msg.id}','${emoji}',event)" title="${quantidade} reação(ões)"><span class="reaction-chip-emoji">${emoji}</span><span>${quantidade}</span></button>`;
  }).join('');
  const reactionsHtml = !msg.deleted ? `<div class="message-reactions ${resumoReacoes ? 'tem-reacoes' : ''}">${resumoReacoes}<div class="reaction-picker" role="group" aria-label="Escolher reação"></div></div>` : '';
  const etiquetaFixada = msg.pinned ? '<div class="msg-fixada"><i class="mdi mdi-pin"></i><span>Mensagem fixada</span></div>' : '';
  const etiquetaEncaminhada = (msg.encaminhada && !msg.deleted) ? '<div class="msg-encaminhada">↪ Encaminhada</div>' : '';
  const reciboHtml = minha ? `<span class="msg-receipt ${classeRecibo(msg)}" title="${tituloRecibo(msg)}">${textoRecibo(msg)}</span>` : '';
  div.innerHTML = `<span class="swipe-icone-responder">↩</span><span class="msg-check">✓</span>${btnResponderRapidoHtml}${remetenteHtml}${etiquetaFixada}${etiquetaEncaminhada}${replyHtml}${conteudoHtml}${linkBtnHtml}${reactionsHtml}<div class="hora">${hora}${editadoTxt}${reciboHtml}</div>${acoesHtml}`;
  ligarPlayerAudio(div);
  ativarGestosMensagem(div, msg);
  if (msgsSelecionadas && msgsSelecionadas.has(msg.id)) div.classList.add('msg-selecionada');
  const btnLink = div.querySelector('.link-preview-card');
  if (btnLink) {
    const codigoConvite = extrairCodigoConvite(btnLink.dataset.url);
    if (codigoConvite) { btnLink.removeAttribute('href'); btnLink.setAttribute('role', 'button'); btnLink.onclick = e => { e.preventDefault(); cliqueBotaoConvite(codigoConvite, btnLink); }; }
  }
  return div;
}

function atualizarMensagemNaTela(msg) {
  const el = document.querySelector(`[data-id="${msg.id}"] .conteudo`);
  if (el) el.textContent = msg.content;
}

function irParaMensagem(id) {
  const alvo = document.querySelector(`[data-id="${id}"]`);
  if (!alvo) return;
  alvo.scrollIntoView({ behavior: 'smooth', block: 'center' });
  alvo.classList.add('msg-destaque');
  setTimeout(() => alvo.classList.remove('msg-destaque'), 1200);
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str || '';
  return d.innerHTML;
}
function escapeAttr(str) {
  return escapeHtml(str).replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ---------- Avatar reaproveitável: mostra a foto se tiver, senão a letra inicial ----------
function avatarInnerHtml(nome, photoUrl) {
  if (photoUrl) return `<img src="${escapeAttr(photoUrl)}" alt="">`;
  return `<span>${escapeHtml((nome || '?').charAt(0).toUpperCase())}</span>`;
}
function atualizarAvatarTopo() {
  document.getElementById('avatar-topo').innerHTML = avatarInnerHtml(usuarioAtual.username, usuarioAtual.photoUrl);
}
function atualizarHomeConta() {
  const card = document.getElementById('home-account-card');
  if (!card || !usuarioAtual) return;
  const status = String(usuarioAtual.statusText || '').trim();
  card.querySelector('[data-home-account-name]').textContent = usuarioAtual.username || 'Conta';
  card.querySelector('[data-home-account-status]').textContent = status || 'Adicione um status para seus contatos';
  card.querySelector('[data-home-account-avatar]').innerHTML = avatarInnerHtml(usuarioAtual.username, usuarioAtual.photoUrl);
}

// ---------- Janela de editar perfil completo ----------
async function abrirEditarPerfil() {
  const root = document.getElementById('modal-root');
  // Refresh the current profile from the server so the fixed contact number is never hidden by stale localStorage.
  try {
    const profileResp = await fetch(`/api/users/${usuarioAtual.id}/public?viewerId=${encodeURIComponent(usuarioAtual.id)}`);
    if (profileResp.ok) {
      const profile = await profileResp.json();
      usuarioAtual = { ...usuarioAtual, ...profile };
      localStorage.setItem('usuario', JSON.stringify(usuarioAtual));
    }
  } catch (_) {}
  const respPriv = await fetch(`/api/users/${usuarioAtual.id}/photo-privacy`);
  const priv = await respPriv.json().catch(() => ({ privacy: 'todos', allowList: [] }));
  const sociais = Array.isArray(usuarioAtual.socials) ? usuarioAtual.socials : [];
  const socialAtual = network => (sociais.find(s => s.network === network) || {}).handle || '';
  const ring = /^#[0-9a-fA-F]{6}$/.test(usuarioAtual.ringColor || '') ? usuarioAtual.ringColor : '#c7f36b';
  const opcoesPrivacidade = [
    { valor: 'todos', label: 'Todos podem ver' },
    { valor: 'contatos', label: 'Só meus contatos' },
    { valor: 'lista', label: 'Só uma lista seleta' },
    { valor: 'ninguem', label: 'Ninguém pode ver' }
  ];
  const privacidadeAtual = priv.privacy || 'todos';
  const socials = [
    { id: 'instagram', label: 'Instagram', placeholder: 'seu.usuario' },
    { id: 'tiktok', label: 'TikTok', placeholder: 'seu.usuario' },
    { id: 'youtube', label: 'YouTube', placeholder: '@seucanal ou ID' },
    { id: 'facebook', label: 'Facebook', placeholder: 'seu.usuario ou página' },
    { id: 'x', label: 'X (Twitter)', placeholder: 'seu.usuario' }
  ];
  const privacidadeHtml = `
    <div class="config-grupo">
      <span class="config-label">Quem pode ver sua foto de perfil</span>
      <div class="privacidade-opcoes">
        ${opcoesPrivacidade.map(o => `
          <label class="privacidade-opcao"><input type="radio" name="foto-privacidade" value="${o.valor}" ${privacidadeAtual === o.valor ? 'checked' : ''}> ${o.label}</label>`).join('')}
      </div>
      <div id="privacidade-lista-wrap" class="${privacidadeAtual === 'lista' ? '' : 'oculto'}">
        <div class="convite-link-row"><input class="modal-input" id="privacidade-lista-busca" type="text" placeholder="Adicionar por email ou usuário"><button class="btn-outline btn-compacto" id="privacidade-lista-add">Adicionar</button></div>
        <div id="privacidade-lista-itens" class="lista-contatos">${renderListaPrivacidadeItens(priv.allowList)}</div>
      </div>
    </div>`;
  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box modal-box--perfil-editor">
        <div class="perfil-editor-cabecalho">
          <button class="perfil-fechar-x" id="perfil-fechar-x" type="button" aria-label="Fechar perfil">×</button>
          <div class="avatar-circle avatar-circle--lg perfil-editor-avatar" style="border-color:${escapeAttr(ring)}">${avatarInnerHtml(usuarioAtual.username, usuarioAtual.photoUrl)}</div>
          <h3 class="modal-title info-grupo-nome">${escapeHtml(usuarioAtual.username)}</h3>
          <p class="perfil-editor-subtitulo">Seu perfil, do seu jeito</p>
          <div class="info-grupo-acoes-foto">
            <button class="link-sutil" id="perfil-trocar-foto" type="button">Trocar foto / GIF</button>
            ${usuarioAtual.photoUrl ? '<button class="link-sutil" id="perfil-remover-foto" type="button">Remover foto</button>' : ''}
          </div>
          <input type="file" id="perfil-foto-input" accept="image/gif,image/*,.gif" style="display:none">
        </div>
        <div class="perfil-editor-campos">
          <div class="perfil-banner-editor" style="${usuarioAtual.bannerUrl ? `background-image:url('${escapeAttr(usuarioAtual.bannerUrl)}')` : ''}"><span class="mdi mdi-image-outline"></span><span>Banner do perfil</span><button type="button" class="btn-outline btn-compacto" id="perfil-banner-escolher">${usuarioAtual.bannerUrl ? 'Trocar banner' : 'Adicionar banner'}</button></div><input type="file" id="perfil-banner-input" accept="image/*" hidden><input type="hidden" id="perfil-banner-url" value="${escapeAttr(usuarioAtual.bannerUrl || '')}">
          <label class="perfil-campo"><span>Bio <small>até 240 caracteres</small></span><textarea id="perfil-bio-input" maxlength="240" rows="3" placeholder="Uma frase sobre você...">${escapeHtml(usuarioAtual.bio || '')}</textarea></label>
          <div class="perfil-detalhes-grid">
            <label class="perfil-campo"><span>Idade</span><input id="perfil-idade" type="number" min="13" max="120" value="${escapeAttr(usuarioAtual.age || '')}" placeholder="Idade"></label>
            <label class="perfil-campo"><span>Sexualidade</span><select id="perfil-sexualidade"><option value="">Prefiro não informar</option>${['Heterossexual','Homossexual','Bissexual','Pansexual','Assexual','Queer','Outra'].map(v => `<option value="${v}" ${usuarioAtual.sexuality === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
            <label class="perfil-campo"><span>Cidade</span><input id="perfil-cidade" maxlength="80" value="${escapeAttr(usuarioAtual.city || '')}" placeholder="Sua cidade"></label>
            <label class="perfil-campo"><span>Estado</span><input id="perfil-estado" maxlength="80" value="${escapeAttr(usuarioAtual.state || '')}" placeholder="Seu estado"></label>
            <label class="perfil-campo perfil-campo-full"><span>Relacionamento</span><select id="perfil-relacionamento"><option value="">Prefiro não informar</option>${['Solteiro(a)','Namorando','Casado(a)','Noivo(a)','Em um relacionamento','Complicado','Prefiro não dizer'].map(v => `<option value="${v}" ${usuarioAtual.relationshipStatus === v ? 'selected' : ''}>${v}</option>`).join('')}</select></label>
          </div>
          <div class="perfil-campo perfil-contato-fixo"><span>Seu número de contato exclusivo</span><div class="perfil-numero-fixo-linha"><strong>${escapeHtml(usuarioAtual.contactNumber || 'Gerando número…')}</strong>${usuarioAtual.contactNumber ? `<button type="button" class="btn-outline btn-compacto" id="perfil-copiar-numero" aria-label="Copiar número de contato"><span class="mdi mdi-content-copy"></span> Copiar</button>` : ''}</div><small>Esse número de 7 dígitos é fixo e permite que outras pessoas encontrem seu perfil.</small></div>
          <label class="perfil-campo perfil-campo-cor"><span>Cor da borda da foto</span><input id="perfil-ring-color" type="color" value="${escapeAttr(ring)}"></label>
          <div class="perfil-socials"><span class="config-label">Suas redes sociais</span><p class="perfil-ajuda">Adicione o usuário; o link será criado automaticamente no seu perfil.</p>
            ${socials.map(net => `<label class="perfil-campo perfil-social-campo"><span>${net.label}</span><input data-social="${net.id}" maxlength="100" value="${escapeAttr(socialAtual(net.id))}" placeholder="${net.placeholder}"></label>`).join('')}
          </div>
        </div>
        ${privacidadeHtml}
        <div class="modal-actions perfil-editor-acoes"><button class="btn-outline btn-compacto" id="perfil-cancelar" type="button">Fechar</button><button class="btn-ok btn-compacto" id="perfil-salvar" type="button">Salvar perfil</button></div>
      </div>
    </div>`;
  const fechar = () => { root.innerHTML = ''; };
  document.getElementById('perfil-fechar-x').onclick = fechar;
  document.getElementById('perfil-cancelar').onclick = fechar;
  const copiarNumeroBtn = document.getElementById('perfil-copiar-numero');
  if (copiarNumeroBtn && usuarioAtual.contactNumber) copiarNumeroBtn.onclick = () => navigator.clipboard.writeText(String(usuarioAtual.contactNumber)).then(() => mostrarAviso('Número de contato copiado!')).catch(() => mostrarAviso(`Seu número: ${usuarioAtual.contactNumber}`));
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') fechar(); };
  document.getElementById('perfil-trocar-foto').onclick = () => document.getElementById('perfil-foto-input').click();
  const bannerBtn = document.getElementById('perfil-banner-escolher');
  const bannerInput = document.getElementById('perfil-banner-input');
  if (bannerBtn && bannerInput) {
    bannerBtn.onclick = () => bannerInput.click();
    bannerInput.onchange = async e => {
      const file = e.target.files && e.target.files[0]; if (!file) return;
      if (!/^image\//i.test(file.type || '') && !/\.(gif|jpe?g|png|webp|bmp)$/i.test(file.name || '')) { mostrarAviso('Escolha uma imagem ou GIF.'); return; }
      if (file.size > 8 * 1024 * 1024) { mostrarAviso('O banner deve ter no máximo 8 MB.'); return; }
      const fd = new FormData(); fd.append('file', file);
      try { const up = await fetch('/api/upload', { method: 'POST', body: fd }); const ud = await up.json(); if (!up.ok || !ud.url) { mostrarAviso(ud.error || 'Não foi possível enviar o banner.'); return; }
        document.getElementById('perfil-banner-url').value = ud.url; const box = document.querySelector('.perfil-banner-editor'); box.style.backgroundImage = `url('${ud.url.replace(/'/g, '%27')}')`; box.classList.add('tem-banner'); bannerBtn.textContent = 'Trocar banner'; mostrarAviso('Banner carregado. Salve o perfil para aplicar.', 'sucesso');
      } catch (_) { mostrarAviso('Falha ao enviar o banner.'); }
    };
  }
  document.getElementById('perfil-foto-input').onchange = e => { if (e.target.files[0]) trocarFotoPerfil(e.target.files[0]); };
  const btnRemover = document.getElementById('perfil-remover-foto');
  if (btnRemover) btnRemover.onclick = () => trocarFotoPerfil(null);
  document.getElementById('perfil-ring-color').oninput = e => {
    const avatar = document.querySelector('.perfil-editor-avatar'); if (avatar) avatar.style.borderColor = e.target.value;
  };
  document.querySelectorAll('input[name="foto-privacidade"]').forEach(radio => { radio.onchange = () => mudarPrivacidadeFoto(radio.value); });
  const inputBusca = document.getElementById('privacidade-lista-busca');
  document.getElementById('privacidade-lista-add').onclick = () => adicionarNaListaPrivacidade(inputBusca.value.trim());
  inputBusca.addEventListener('keydown', e => { if (e.key === 'Enter') adicionarNaListaPrivacidade(inputBusca.value.trim()); });
  document.getElementById('perfil-salvar').onclick = async () => {
    const socials = Array.from(document.querySelectorAll('[data-social]')).map(el => ({ network: el.dataset.social, handle: el.value.trim() })).filter(x => x.handle);
    const resp = await fetch(`/api/users/${usuarioAtual.id}/profile`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: usuarioAtual.id, bio: document.getElementById('perfil-bio-input').value, ringColor: document.getElementById('perfil-ring-color').value, age: document.getElementById('perfil-idade').value, sexuality: document.getElementById('perfil-sexualidade').value, city: document.getElementById('perfil-cidade').value, state: document.getElementById('perfil-estado').value, relationshipStatus: document.getElementById('perfil-relacionamento').value, bannerUrl: document.getElementById('perfil-banner-url').value, socials }) });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível salvar o perfil.'); return; }
    usuarioAtual = { ...usuarioAtual, ...data.user };
    localStorage.setItem('usuario', JSON.stringify(usuarioAtual));
    const contas = carregarContas().map(c => c.id === usuarioAtual.id ? { ...c, ...data.user } : c);
    localStorage.setItem('contas', JSON.stringify(contas));
    atualizarAvatarTopo();
    abrirEditarPerfil();
    mostrarAviso('Perfil atualizado!', 'sucesso');
  };
}

// ---------- Linhas da lista seleta (dentro da privacidade da foto) ----------
function renderListaPrivacidadeItens(lista) {
  if (!lista || !lista.length) return '<p class="modal-texto">Ninguém na lista ainda.</p>';
  return lista.map(p => `
    <div class="dropdown-item conta-item">
      <span class="conta-info"><span>${escapeHtml(p.username)}</span></span>
      <span class="conta-remover" onclick="removerDaListaPrivacidade('${p.id}')" title="Remover">✕</span>
    </div>`).join('');
}

// ---------- Trocar a preferência de privacidade da foto ----------
async function mudarPrivacidadeFoto(valor) {
  const resp = await fetch(`/api/users/${usuarioAtual.id}/photo-privacy`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ privacy: valor })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar a privacidade da foto.'); return; }
  const wrap = document.getElementById('privacidade-lista-wrap');
  if (wrap) wrap.classList.toggle('oculto', valor !== 'lista');
}

// ---------- Adicionar/remover alguém da lista seleta ----------
async function adicionarNaListaPrivacidade(query) {
  if (!query) return;
  const resp = await fetch(`/api/users/${usuarioAtual.id}/photo-privacy/lista`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível adicionar essa pessoa.'); return; }
  abrirEditarPerfil(); // reabre já com a lista atualizada
}

async function removerDaListaPrivacidade(id) {
  const resp = await fetch(`/api/users/${usuarioAtual.id}/photo-privacy/lista`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ remover: id })
  });
  if (!resp.ok) { mostrarAviso('Não foi possível remover essa pessoa.'); return; }
  abrirEditarPerfil();
}

// ---------- Trocar (ou remover, se arquivo for null) a própria foto de perfil ----------
async function trocarFotoPerfil(arquivo) {
  let photoUrl = null;
  if (arquivo) {
    if (!/^image\//i.test(arquivo.type || '') && !/\.(gif|jpe?g|png|webp|bmp)$/i.test(arquivo.name || '')) { mostrarAviso('Escolha uma imagem ou GIF.'); return; }
    if (arquivo.size > 12 * 1024 * 1024) { mostrarAviso('A foto deve ter no máximo 12 MB.'); return; }
    try {
      const formData = new FormData(); formData.append('file', arquivo, arquivo.name || 'perfil.gif');
      const uploadResp = await fetch('/api/upload', { method: 'POST', body: formData });
      const uploadData = await uploadResp.json().catch(() => ({}));
      if (!uploadResp.ok || !uploadData.url) { mostrarAviso(uploadData.error || 'Não foi possível enviar a imagem/GIF.'); return; }
      photoUrl = uploadData.url;
    } catch (_) { mostrarAviso('Falha de conexão ao enviar a imagem/GIF.'); return; }
  }

  const resp = await fetch(`/api/users/${usuarioAtual.id}/photo`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ photoUrl })
  });
  const data = await resp.json();
  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível mudar a foto de perfil.'); return; }

  usuarioAtual = data.user;
  localStorage.setItem('usuario', JSON.stringify(usuarioAtual));
  const contas = carregarContas().map(c => c.id === usuarioAtual.id ? { ...c, photoUrl: usuarioAtual.photoUrl } : c);
  localStorage.setItem('contas', JSON.stringify(contas));

  atualizarAvatarTopo();
  carregarListaChats(); // pra atualizar a foto em conversas privadas com outras pessoas te vendo
  abrirEditarPerfil(); // reabre já atualizado
}

function montarPreviaLink(url) {
  try {
    const u = new URL(url);
    const host = u.hostname.replace(/^www\./i, '');
    return `<a class="link-preview-card" href="${escapeAttr(u.href)}" target="_blank" rel="noopener noreferrer" data-url="${escapeAttr(u.href)}"><span class="link-preview-favicon"><img src="https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&sz=64" alt="" loading="lazy" onerror="this.style.display='none'"><i class="mdi mdi-web"></i></span><span class="link-preview-copy"><strong>${escapeHtml(host)}</strong><small>${escapeHtml(u.pathname === '/' ? 'Abrir página' : u.pathname + u.search)}</small></span><span class="link-preview-open mdi mdi-open-in-new" aria-hidden="true"></span></a>`;
  } catch (_) { return ''; }
}

// ---------- Detecção de link em mensagens de texto ----------
function extrairPrimeiroLink(texto) {
  const m = (texto || '').match(/https?:\/\/[^\s]+/i);
  return m ? m[0] : null;
}

// ---------- Clique no botão "Acessar" de uma mensagem com link ----------
function extrairCodigoConvite(url) {
  try {
    const u = new URL(url, location.origin);
    return u.origin === location.origin ? u.searchParams.get('convite') : null;
  } catch (e) {
    return null;
  }
}

function acessarLink(url) {
  window.open(url, '_blank', 'noopener');
}

// ---------- Fluxo Acessar -> Solicitar -> Cancelar, só pra links de convite de grupo do site ----------
async function cliqueBotaoConvite(code, btn) {
  btn.disabled = true;
  const infoResp = await fetch(`/api/invite/${code}/info?userId=${usuarioAtual.id}`);
  const info = await infoResp.json();
  btn.disabled = false;
  if (!infoResp.ok) { mostrarAviso(info.error || 'Não foi possível entrar nesse grupo.'); return; }

  if (info.approvalRequired && !info.jaEstava && !info.jaPendente) {
    const aceitou = await abrirConfirmacao({
      titulo: 'Pedir pra entrar no grupo',
      mensagem: `O grupo "${info.chatName}" exige aprovação de um admin. Quer solicitar entrada?`,
      textoBotao: 'Solicitar'
    });
    if (!aceitou) return;
  }

  btn.disabled = true;
  const resp = await fetch(`/api/invite/${code}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id })
  });
  const data = await resp.json();
  btn.disabled = false;

  if (!resp.ok) { mostrarAviso(data.error || 'Não foi possível entrar nesse grupo.'); return; }

  if (data.pendente) {
    // pedido enviado (ou já estava pendente) — vira "Cancelar solicitação"
    btn.textContent = '✕ Cancelar solicitação';
    btn.classList.add('btn-acessar-link--pendente');
    btn.onclick = () => cancelarSolicitacaoConvite(code, btn);
    mostrarAviso('Pedido enviado! Um admin do grupo precisa aprovar.', 'sucesso');
    return;
  }

  mostrarAviso(data.jaEstava ? 'Você já está nesse grupo.' : `Você entrou no grupo "${data.chat.name}"!`, 'sucesso');
  btn.textContent = '✓ Você está no grupo';
  btn.disabled = true;
  carregarListaChats();
  abrirChat(data.chat.id, data.chat.name, data.chat.type, null, null, false);
}

async function cancelarSolicitacaoConvite(code, btn) {
  btn.disabled = true;
  const resp = await fetch(`/api/invite/${code}/cancelar`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId: usuarioAtual.id })
  });
  btn.disabled = false;
  if (!resp.ok) { mostrarAviso('Não foi possível cancelar o pedido.'); return; }

  btn.textContent = '🔗 Acessar';
  btn.classList.remove('btn-acessar-link--pendente');
  btn.onclick = () => cliqueBotaoConvite(code, btn);
  mostrarAviso('Pedido cancelado.', 'sucesso');
}

// ---------- Prévia de mensagem (usada na citação de resposta) ----------
// nome mostrado na caixinha de citação, sempre do ponto de vista de quem está VENDO:
// "Você" se a mensagem citada é minha, senão o nick de quem escreveu.
function nomeDoCitado(rt) {
  if (rt.userId === usuarioAtual.id) return 'Você';
  if (rt.realName) return rt.realName;
  const original = mensagensCacheAtual.get(rt.id);
  if (original && original.senderUsername) return original.senderUsername;
  // respostas antigas (sem realName): se o nome gravado não é "Você", serve; senão, no PV é o outro
  if (rt.userName && rt.userName !== 'Você') return rt.userName;
  if (chatAtualOutro && chatAtualOutro.username) return chatAtualOutro.username;
  return 'Usuário';
}
function nomeDoRemetente(msg) {
  if (msg.senderId === usuarioAtual.id) return 'Você';
  return msg.senderUsername || 'Usuário removido';
}
function previaDaMensagem(msg) {
  if (msg.deleted) return 'Mensagem apagada';
  switch (msg.type) {
    case 'audio': return '🎤 Mensagem de voz';
    case 'video': return '🎥 Vídeo';
    case 'image': return '📷 Foto';
    case 'file': return '📎 ' + (msg.content || 'Arquivo');
    default: {
      const texto = msg.content || '';
      return texto.length > 60 ? texto.slice(0, 60) + '…' : texto;
    }
  }
}

// ---------- @Menções (tipo Zap) ----------
// Destaca "@fulano" (ou "@todos") dentro do texto de uma mensagem já escapado,
// usando os membros do grupo atual. Se não for grupo, não tem o que destacar.
function destacarMencoes(texto) {
  const seguro = escapeHtml(texto);
  if (chatAtualTipo !== 'group' || !chatAtualMembros.length) return seguro;

  const membros = chatAtualMembros.filter(m => m && m.username).sort((a, b) => b.username.length - a.username.length);
  const escapaRegex = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const nomes = membros.map(m => escapaRegex(escapeHtml(m.username)));
  const padrao = new RegExp('@(' + nomes.join('|') + '|todos)\\b', 'gi');

  return seguro.replace(padrao, (trecho, nome) => {
    const membro = membros.find(m => m.username.toLowerCase() === nome.toLowerCase());
    const ehTodos = nome.toLowerCase() === 'todos';
    const meMencionou = ehTodos || (usuarioAtual && nome.toLowerCase() === usuarioAtual.username.toLowerCase());
    if (membro && membro.id) {
      return `<button type="button" class="mencao mencao-perfil${meMencionou ? ' mencao-eu' : ''}" data-mention-user="${escapeAttr(membro.id)}" onclick="event.stopPropagation();abrirPerfilUsuario('${escapeAttr(membro.id)}')" aria-label="Abrir perfil de @${escapeAttr(membro.username)}">${trecho}</button>`;
    }
    return `<span class="mencao${meMencionou ? ' mencao-eu' : ''}">${trecho}</span>`;
  });
}

// Liga a digitação no campo de mensagem à sugestão de @menção (só existe em grupo)
function configurarMencoes() {
  const input = document.getElementById('input-texto');
  if (!input) return;
  input.addEventListener('input', tratarDigitacaoMencao);
  input.addEventListener('keydown', e => { if (e.key === 'Escape') esconderMencaoPopup(); });
  document.addEventListener('click', e => {
    if (e.target.id !== 'input-texto' && !e.target.closest('#mencao-popup')) esconderMencaoPopup();
  });
}

// Olha o que tá sendo digitado antes do cursor: se terminar em "@algo",
// mostra os membros do grupo que combinam com "algo"
function tratarDigitacaoMencao() {
  if (chatAtualTipo !== 'group' || !chatAtualMembros.length) { esconderMencaoPopup(); return; }

  const input = document.getElementById('input-texto');
  const cursor = input.selectionStart;
  const antesDoCursor = input.value.slice(0, cursor);
  const match = antesDoCursor.match(/(?:^|\s)@([a-zA-Z0-9_.]*)$/);
  if (!match) { esconderMencaoPopup(); return; }

  const consulta = match[1].toLowerCase();
  mencaoAtiva = { inicio: cursor - match[1].length - 1, fim: cursor };

  const candidatos = [{ id: 'todos', username: 'Todos', especial: true }]
    .concat(chatAtualMembros.filter(m => m.id !== usuarioAtual.id))
    .filter(m => m.username.toLowerCase().includes(consulta))
    .slice(0, 6);

  if (!candidatos.length) { esconderMencaoPopup(); return; }
  mostrarMencaoPopup(candidatos);
}

function mostrarMencaoPopup(candidatos) {
  const popup = document.getElementById('mencao-popup');
  if (!popup) return;
  popup.innerHTML = candidatos.map(m => `
    <div class="mencao-item" onmousedown="event.preventDefault(); escolherMencao('${escapeAttr(m.username)}')">
      ${m.especial
        ? '<span class="mencao-item-todos">@</span>'
        : `<span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(m.username, m.photoUrl)}</span>`}
      <span>${escapeHtml(m.username)}</span>
    </div>`).join('');
  popup.classList.remove('oculto');
}

function esconderMencaoPopup() {
  mencaoAtiva = null;
  const popup = document.getElementById('mencao-popup');
  if (popup) popup.classList.add('oculto');
}

// Troca o "@algo" que tava sendo digitado pelo nome escolhido na lista
function escolherMencao(username) {
  const input = document.getElementById('input-texto');
  if (!input || !mencaoAtiva) return;
  const antes = input.value.slice(0, mencaoAtiva.inicio);
  const depois = input.value.slice(mencaoAtiva.fim);
  const inserido = '@' + username + ' ';
  input.value = antes + inserido + depois;
  atualizarBotoesInput();
  const posicao = (antes + inserido).length;
  input.focus();
  input.setSelectionRange(posicao, posicao);
  esconderMencaoPopup();
}
configurarMencoes();


function enviarTexto() {
  if (chatAtualRemovido) return;
  const input = document.getElementById('input-texto');
  const texto = input.value.trim();
  if (!texto || !chatAtualId) return;

  socket.emit('send_message', {
    chatId: chatAtualId,
    userId: usuarioAtual.id,
    type: 'text',
    content: texto,
    replyTo: respondendoA,
    expiresIn: preferenciasChatAtual.ephemeral || null
  });

  input.value = '';
  atualizarBotoesInput();
  cancelarResposta();
}

// celular: com texto digitado mostra "enviar", sem texto mostra o microfone (o CSS faz a troca)
function atualizarBotoesInput() {
  const input = document.getElementById('input-texto');
  const area = input && input.closest('.input-area');
  const temTexto = !!(input && input.value.trim().length > 0);
  if (area) area.classList.toggle('digitando', temTexto);
  if (socket && socket.connected && chatAtualId) {
    if (temTexto) socket.emit('typing:start', { chatId: chatAtualId });
    else socket.emit('typing:stop', { chatId: chatAtualId });
    if (typingStopTimer) clearTimeout(typingStopTimer);
    if (temTexto) typingStopTimer = setTimeout(() => { if (socket && socket.connected && chatAtualId) socket.emit('typing:stop', { chatId: chatAtualId }); }, 1800);
  }
}
// teclados de celular nem sempre disparam só o "input": escuta os outros eventos também
(function ligarBotoesInput() {
  const input = document.getElementById('input-texto');
  if (!input) return;
  ['input', 'keyup', 'change', 'paste', 'cut', 'compositionend'].forEach(ev => input.addEventListener(ev, () => setTimeout(atualizarBotoesInput, 0)));
  atualizarBotoesInput();
})();

// ---------- Responder ----------
function responderMensagem(id) {
  const msg = mensagensCacheAtual.get(id);
  if (!msg) return;
  respondendoA = {
    id: msg.id,
    userId: msg.senderId,
    userName: nomeDoRemetente(msg),
    // nome "de verdade" de quem escreveu — o userName acima vira "Você" pra quem respondeu,
    // e esse texto fica gravado na mensagem, então o outro lado via "Você" errado.
    realName: msg.senderId === usuarioAtual.id ? usuarioAtual.username : (msg.senderUsername || 'Usuário removido'),
    snippet: previaDaMensagem(msg)
  };
  document.getElementById('reply-preview-nome').textContent = respondendoA.userName;
  document.getElementById('reply-preview-text').textContent = respondendoA.snippet;
  document.getElementById('reply-preview').style.display = 'flex';
  document.getElementById('input-texto').focus();
}
function cancelarResposta() {
  respondendoA = null;
  document.getElementById('reply-preview').style.display = 'none';
}

// ---------- Editar ----------
async function editarMensagem(id) {
  const atual = document.querySelector(`[data-id="${id}"] .conteudo`);
  const valores = await abrirModal({
    titulo: 'Editar mensagem',
    campos: [{ id: 'texto', label: 'Novo texto', tipo: 'textarea', valor: atual ? atual.textContent : '' }],
    textoBotao: 'Salvar'
  });
  if (!valores || valores.texto === '') return;
  socket.emit('edit_message', { messageId: id, userId: usuarioAtual.id, newContent: valores.texto });
}

// ---------- Apagar ----------
async function apagarMensagem(id) {
  const aceitou = await abrirConfirmacao({ titulo: 'Apagar mensagem', mensagem: 'Apagar essa mensagem?', textoBotao: 'Apagar' });
  if (!aceitou) return;
  socket.emit('delete_message', { messageId: id, userId: usuarioAtual.id });
}

// ---------- Áudio / Vídeo ----------
let iniciandoGravacao = false; // trava pra evitar 2 toques rápidos abrirem 2 gravações ao mesmo tempo
let gravacaoCancelada = false; // true quando a pessoa apertou "cancelar" em vez de "enviar"
let gravacaoInicioEm = 0;
let gravacaoTimerId = null;

async function alternarGravacao(tipo) {
  if (gravador && gravador.state === 'recording') return; // já gravando: usa os botões da barrinha
  if (iniciandoGravacao) return; // já tem um getUserMedia em andamento, ignora o toque duplicado

  iniciandoGravacao = true;

  try {
    tipoGravando = tipo;
    gravacaoCancelada = false;
    const constraints = tipo === 'video' ? { audio: true, video: true } : { audio: true };
    const stream = await navigator.mediaDevices.getUserMedia(constraints);

    chunksGravacao = [];
    gravador = new MediaRecorder(stream);
    gravador.ondataavailable = e => { if (e.data && e.data.size > 0) chunksGravacao.push(e.data); };
    gravador.onstop = async () => {
      stream.getTracks().forEach(t => t.stop());
      esconderBarraGravacao();
      if (gravacaoCancelada || chunksGravacao.length === 0) {
        chunksGravacao = [];
        return; // gravação cancelada ou nada foi gravado
      }
      const mimeType = (gravador && gravador.mimeType) || (chunksGravacao.find(c => c.type) || {}).type || (tipo === 'video' ? 'video/webm' : 'audio/webm');
      const blob = new Blob(chunksGravacao, { type: mimeType });
      chunksGravacao = [];
      if (!blob.size) {
        mostrarAviso('A gravação ficou vazia. Tente gravar novamente.');
        return;
      }
      await enviarMidia(blob, tipo);
    };

    // passar um intervalo (1s) faz o navegador ir salvando pedaços aos poucos
    // em vez de só no final — em celular isso evita perder um trecho do áudio
    // se o app for pra segundo plano ou o navegador cortar a gravação sozinho.
    gravador.start(1000);
    mostrarBarraGravacao(tipo);
  } catch (err) {
    mostrarAviso('Não consegui acessar o microfone. Verifique a permissão do navegador.');
  } finally {
    iniciandoGravacao = false;
  }
}

// ---------- Barrinha "gravando..." (tipo Zap), com cancelar/enviar ----------
function pegarInputAreaAtiva() {
  // no celular a área de chat pode estar dentro de #chat-view (index.html) ou
  // ser a única .input-area da tela (app.html) — cobre os dois casos
  const dentroDoChat = document.querySelector('#chat-view .input-area');
  return dentroDoChat || document.querySelector('.input-area');
}

function mostrarBarraGravacao(tipo) {
  const inputArea = pegarInputAreaAtiva();
  const barra = document.getElementById('barra-gravacao');
  if (!inputArea || !barra) return;

  inputArea.style.display = 'none';
  barra.style.display = 'flex';

  const icone = document.getElementById('barra-gravacao-icone');
  if (icone) icone.textContent = tipo === 'video' ? '🎥' : '🎤';

  gravacaoInicioEm = Date.now();
  atualizarTimerGravacao();
  gravacaoTimerId = setInterval(atualizarTimerGravacao, 500);
}

function atualizarTimerGravacao() {
  const el = document.getElementById('barra-gravacao-timer');
  if (!el) return;
  const totalSeg = Math.floor((Date.now() - gravacaoInicioEm) / 1000);
  const min = Math.floor(totalSeg / 60);
  const seg = totalSeg % 60;
  el.textContent = `${min}:${String(seg).padStart(2, '0')}`;
}

function esconderBarraGravacao() {
  if (gravacaoTimerId) { clearInterval(gravacaoTimerId); gravacaoTimerId = null; }
  const inputArea = pegarInputAreaAtiva();
  const barra = document.getElementById('barra-gravacao');
  if (barra) barra.style.display = 'none';
  if (inputArea) inputArea.style.display = 'flex';
}

// Botão ✕ da barrinha: descarta a gravação, não manda nada
function cancelarGravacao() {
  if (!gravador || gravador.state !== 'recording') return;
  gravacaoCancelada = true;
  gravador.stop();
}

// Botão ✓/enviar da barrinha: para de gravar e manda normalmente
function enviarGravacao() {
  if (!gravador || gravador.state !== 'recording') return;
  gravador.stop();
}

async function enviarMidia(blob, tipo) {
  if (!blob || !blob.size) {
    mostrarAviso('O áudio ficou vazio. Grave novamente antes de enviar.');
    return;
  }
  if (!chatAtualId || !usuarioAtual || !usuarioAtual.id || !socket) {
    mostrarAviso('Abra uma conversa antes de enviar o áudio.');
    return;
  }

  const mimeType = blob.type || (tipo === 'video' ? 'video/webm' : 'audio/webm');
  const extensao = mimeType.includes('mp4') ? 'mp4' : mimeType.includes('ogg') ? 'ogg' : mimeType.includes('mpeg') ? 'mp3' : 'webm';
  const formData = new FormData();
  formData.append('file', blob, `${tipo}.${extensao}`);

  try {
    const resp = await fetch('/api/upload', { method: 'POST', body: formData });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || typeof data.url !== 'string' || !data.url.trim()) {
      throw new Error(data.error || 'O servidor não confirmou o upload do áudio.');
    }

    socket.emit('send_message', {
      chatId: chatAtualId,
      userId: usuarioAtual.id,
      type: tipo,
      mediaUrl: data.url,
      replyTo: respondendoA,
      expiresIn: preferenciasChatAtual.ephemeral || null,
      highQuality: altaQualidadeAtual
    });
    cancelarResposta();
  } catch (err) {
    console.error('Falha ao enviar mídia:', err);
    mostrarAviso(err && err.message ? err.message : 'Não foi possível enviar o áudio. Verifique sua conexão e tente novamente.');
  }
}

// ---------- Anexar arquivo (foto, pdf, docx, mp3 etc.) ----------
// ---------- Pré-visualização antes de enviar (foto, vídeo, áudio ou arquivo) ----------
// Foto: dá pra cortar e escrever texto em cima, e ainda tem legenda. Nada é enviado sem apertar "Enviar".
const PREVIA_MAX_PX = 1600;
const PREVIA_CORES = ['#ffffff', '#111111', '#ff4d4d', '#ffd23f', '#3ddc84', '#4da3ff', '#c77dff'];
let previaEstado = null;

function formatarTamanhoArquivo(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

function fecharPrevia() {
  if (previaEstado && previaEstado.url) URL.revokeObjectURL(previaEstado.url);
  previaEstado = null;
  const root = document.getElementById('modal-root');
  if (root) root.innerHTML = '';
  const input = document.getElementById('input-anexo');
  if (input) input.value = ''; // permite escolher o mesmo arquivo de novo
}

function previsualizarAnexo(file) {
  if (!file) return;
  if (!chatAtualId || !usuarioAtual || !socket) { mostrarAviso('Abra uma conversa antes de enviar um arquivo.'); return; }
  const tipo = file.type.startsWith('image/') ? 'image' : file.type.startsWith('audio/') ? 'audio' : file.type.startsWith('video/') ? 'video' : 'file';
  const url = URL.createObjectURL(file);
  const editavel = tipo === 'image' && file.type !== 'image/gif' && file.type !== 'image/svg+xml';
  previaEstado = { file, tipo, url, editavel, base: null, textos: [], selecionado: -1, editou: false, modo: 'ver', corte: null, enviando: false };

  let corpo;
  if (tipo === 'image') corpo = editavel
    ? `<div class="previa-palco"><div class="previa-wrap" id="previa-wrap"><canvas id="previa-canvas"></canvas><div class="previa-corte oculto" id="previa-corte"><i data-h="nw"></i><i data-h="ne"></i><i data-h="sw"></i><i data-h="se"></i></div></div></div>`
    : `<div class="previa-palco"><img class="previa-midia" src="${url}" alt=""></div>`;
  else if (tipo === 'video') corpo = `<div class="previa-palco"><video class="previa-midia" src="${url}" controls playsinline></video></div>`;
  else if (tipo === 'audio') corpo = `<div class="previa-palco previa-palco--arquivo"><i class="mdi mdi-microphone-outline previa-icone"></i><strong>${escapeHtml(file.name)}</strong><small>${formatarTamanhoArquivo(file.size)}</small><audio src="${url}" controls></audio></div>`;
  else corpo = `<div class="previa-palco previa-palco--arquivo"><i class="mdi mdi-file-document-outline previa-icone"></i><strong>${escapeHtml(file.name)}</strong><small>${formatarTamanhoArquivo(file.size)}</small></div>`;

  const ferramentas = editavel ? `
    <div class="previa-ferramentas" id="previa-ferramentas">
      <button type="button" id="previa-btn-cortar"><i class="mdi mdi-crop"></i><span>Cortar</span></button>
      <button type="button" id="previa-btn-texto"><i class="mdi mdi-format-text"></i><span>Texto</span></button>
    </div>
    <div class="previa-barra oculto" id="previa-barra-corte">
      <button type="button" class="btn-outline btn-compacto" id="previa-corte-cancelar">Cancelar corte</button>
      <button type="button" class="btn-ok btn-compacto" id="previa-corte-aplicar">Aplicar corte</button>
    </div>
    <div class="previa-barra previa-barra--texto oculto" id="previa-barra-texto">
      <input type="text" id="previa-texto-input" maxlength="80" placeholder="Digite o texto da foto">
      <div class="previa-cores" id="previa-cores">${PREVIA_CORES.map((c, i) => `<button type="button" class="previa-cor ${i === 0 ? 'ativa' : ''}" data-cor="${c}" style="background:${c}" aria-label="Cor"></button>`).join('')}</div>
      <div class="previa-linha-texto">
        <button type="button" class="btn-outline btn-compacto" id="previa-texto-menos">A−</button>
        <button type="button" class="btn-outline btn-compacto" id="previa-texto-mais">A+</button>
        <button type="button" class="btn-outline btn-compacto" id="previa-texto-add">Novo texto</button>
        <button type="button" class="btn-outline btn-compacto" id="previa-texto-remover">Remover</button>
        <button type="button" class="btn-ok btn-compacto" id="previa-texto-ok">Pronto</button>
      </div>
    </div>` : '';

  const comLegenda = tipo === 'image' || tipo === 'video';
  const root = document.getElementById('modal-root');
  root.innerHTML = `
    <div class="previa-overlay" id="previa-overlay" role="dialog" aria-label="Pré-visualização">
      <div class="previa-topo">
        <button type="button" class="previa-fechar" id="previa-cancelar" aria-label="Cancelar"><i class="mdi mdi-close"></i></button>
        <span class="previa-titulo">Pré-visualização</span>
      </div>
      ${corpo}
      ${ferramentas}
      <div class="previa-rodape" id="previa-rodape">
        ${comLegenda ? '<input type="text" id="previa-legenda" maxlength="1000" placeholder="Adicione uma legenda...">' : '<span class="previa-rodape-espaco"></span>'}
        <button type="button" class="previa-enviar" id="previa-enviar" aria-label="Enviar"><i class="mdi mdi-send"></i></button>
      </div>
    </div>`;

  document.getElementById('previa-cancelar').onclick = fecharPrevia;
  document.getElementById('previa-enviar').onclick = confirmarEnvioPrevia;
  const legenda = document.getElementById('previa-legenda');
  if (legenda) legenda.onkeydown = e => { if (e.key === 'Enter') confirmarEnvioPrevia(); };
  document.getElementById('previa-overlay').addEventListener('keydown', e => { if (e.key === 'Escape') fecharPrevia(); });
  if (editavel) iniciarEditorImagem();
}

async function confirmarEnvioPrevia() {
  const st = previaEstado;
  if (!st || st.enviando) return;
  st.enviando = true;
  const btn = document.getElementById('previa-enviar');
  if (btn) { btn.disabled = true; btn.innerHTML = '<i class="mdi mdi-loading mdi-spin"></i>'; }
  const legendaEl = document.getElementById('previa-legenda');
  const legenda = legendaEl ? legendaEl.value.trim() : '';
  let arquivo = st.file;
  if (st.editavel && st.editou) {
    const blob = await new Promise(res => document.getElementById('previa-canvas').toBlob(res, 'image/jpeg', 0.9));
    if (blob) arquivo = new File([blob], (st.file.name.replace(/\.[^.]+$/, '') || 'foto') + '.jpg', { type: 'image/jpeg' });
  }
  const ok = await enviarAnexo(arquivo, legenda);
  if (ok) fecharPrevia();
  else if (previaEstado === st) { st.enviando = false; if (btn) { btn.disabled = false; btn.innerHTML = '<i class="mdi mdi-send"></i>'; } }
}

// ---- Editor de foto: cortar + texto ----
function iniciarEditorImagem() {
  const st = previaEstado;
  const img = new Image();
  img.onload = () => {
    if (previaEstado !== st) return;
    const escala = Math.min(1, PREVIA_MAX_PX / Math.max(img.naturalWidth, img.naturalHeight));
    const base = document.createElement('canvas');
    base.width = Math.max(1, Math.round(img.naturalWidth * escala));
    base.height = Math.max(1, Math.round(img.naturalHeight * escala));
    base.getContext('2d').drawImage(img, 0, 0, base.width, base.height);
    st.base = base;
    desenharPrevia();
    ligarFerramentasEditor();
  };
  img.onerror = () => { mostrarAviso('Não consegui abrir essa imagem.'); fecharPrevia(); };
  img.src = st.url;
}

// textos guardam posição e tamanho em FRAÇÃO da imagem, então sobrevivem ao corte
function desenharPrevia() {
  const st = previaEstado;
  if (!st || !st.base) return;
  const cv = document.getElementById('previa-canvas');
  if (!cv) return;
  if (cv.width !== st.base.width || cv.height !== st.base.height) { cv.width = st.base.width; cv.height = st.base.height; }
  const ctx = cv.getContext('2d');
  ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.drawImage(st.base, 0, 0);
  st.textos.forEach((t, i) => {
    const px = t.tam * cv.width;
    ctx.font = `800 ${px}px "DM Sans", Arial, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.lineWidth = Math.max(2, px / 7);
    ctx.strokeStyle = t.cor === '#111111' ? 'rgba(255,255,255,.85)' : 'rgba(0,0,0,.65)';
    ctx.strokeText(t.texto, t.x * cv.width, t.y * cv.height);
    ctx.fillStyle = t.cor;
    ctx.fillText(t.texto, t.x * cv.width, t.y * cv.height);
    t._w = ctx.measureText(t.texto).width; t._h = px;
    if (i === st.selecionado && st.modo === 'texto') {
      ctx.save();
      ctx.setLineDash([8, 6]); ctx.lineWidth = 2; ctx.strokeStyle = '#ffffff';
      ctx.strokeRect(t.x * cv.width - t._w / 2 - 8, t.y * cv.height - px / 2 - 6, t._w + 16, px + 12);
      ctx.restore();
    }
  });
}

function definirModoEditor(modo) {
  const st = previaEstado; if (!st) return;
  st.modo = modo;
  const mostrar = (id, sim) => { const el = document.getElementById(id); if (el) el.classList.toggle('oculto', !sim); };
  mostrar('previa-ferramentas', modo === 'ver');
  mostrar('previa-rodape', modo === 'ver');
  mostrar('previa-barra-corte', modo === 'corte');
  mostrar('previa-barra-texto', modo === 'texto');
  mostrar('previa-corte', modo === 'corte');
  if (modo === 'corte') iniciarCorte();
  if (modo !== 'texto') st.selecionado = -1;
  desenharPrevia();
}

function iniciarCorte() {
  const wrap = document.getElementById('previa-wrap');
  const w = wrap.clientWidth, h = wrap.clientHeight;
  const mx = w * 0.08, my = h * 0.08;
  previaEstado.corte = { x: mx, y: my, w: w - mx * 2, h: h - my * 2 };
  atualizarCaixaCorte();
}
function atualizarCaixaCorte() {
  const c = previaEstado.corte, el = document.getElementById('previa-corte');
  if (!c || !el) return;
  el.style.left = c.x + 'px'; el.style.top = c.y + 'px'; el.style.width = c.w + 'px'; el.style.height = c.h + 'px';
}

function ligarFerramentasEditor() {
  const st = previaEstado;
  const cv = document.getElementById('previa-canvas');
  const wrap = document.getElementById('previa-wrap');
  const caixa = document.getElementById('previa-corte');
  const inputTexto = document.getElementById('previa-texto-input');
  let corAtual = PREVIA_CORES[0];

  document.getElementById('previa-btn-cortar').onclick = () => definirModoEditor('corte');
  document.getElementById('previa-btn-texto').onclick = () => {
    definirModoEditor('texto');
    if (!st.textos.length) adicionarTexto();
    else { st.selecionado = st.textos.length - 1; sincronizarBarraTexto(); desenharPrevia(); }
  };

  // ----- corte: arrastar a caixa e os cantos -----
  let arraste = null;
  caixa.addEventListener('pointerdown', e => {
    if (st.modo !== 'corte') return;
    e.preventDefault();
    caixa.setPointerCapture(e.pointerId);
    arraste = { handle: e.target.dataset.h || 'mover', sx: e.clientX, sy: e.clientY, c: Object.assign({}, st.corte) };
  });
  caixa.addEventListener('pointermove', e => {
    if (!arraste) return;
    const W = wrap.clientWidth, H = wrap.clientHeight, MIN = 40;
    const dx = e.clientX - arraste.sx, dy = e.clientY - arraste.sy, o = arraste.c;
    let { x, y, w, h } = o;
    if (arraste.handle === 'mover') {
      x = Math.max(0, Math.min(W - w, o.x + dx));
      y = Math.max(0, Math.min(H - h, o.y + dy));
    } else {
      const h_ = arraste.handle;
      if (h_.includes('w')) { const nx = Math.max(0, Math.min(o.x + o.w - MIN, o.x + dx)); w = o.w + (o.x - nx); x = nx; }
      if (h_.includes('e')) { w = Math.max(MIN, Math.min(W - o.x, o.w + dx)); }
      if (h_.includes('n')) { const ny = Math.max(0, Math.min(o.y + o.h - MIN, o.y + dy)); h = o.h + (o.y - ny); y = ny; }
      if (h_.includes('s')) { h = Math.max(MIN, Math.min(H - o.y, o.h + dy)); }
    }
    st.corte = { x, y, w, h };
    atualizarCaixaCorte();
  });
  const soltar = () => { arraste = null; };
  caixa.addEventListener('pointerup', soltar);
  caixa.addEventListener('pointercancel', soltar);

  document.getElementById('previa-corte-cancelar').onclick = () => definirModoEditor('ver');
  document.getElementById('previa-corte-aplicar').onclick = () => {
    const c = st.corte, f = st.base.width / wrap.clientWidth;
    const sx = Math.round(c.x * f), sy = Math.round(c.y * f);
    const sw = Math.max(1, Math.min(st.base.width - sx, Math.round(c.w * f)));
    const sh = Math.max(1, Math.min(st.base.height - sy, Math.round(c.h * f)));
    const novo = document.createElement('canvas');
    novo.width = sw; novo.height = sh;
    novo.getContext('2d').drawImage(st.base, sx, sy, sw, sh, 0, 0, sw, sh);
    const antigaW = st.base.width, antigaH = st.base.height;
    st.textos.forEach(t => {
      t.x = (t.x * antigaW - sx) / sw;
      t.y = (t.y * antigaH - sy) / sh;
      t.tam = t.tam * antigaW / sw;
    });
    st.base = novo;
    st.editou = true;
    definirModoEditor('ver');
  };

  // ----- texto -----
  function sincronizarBarraTexto() {
    const t = st.textos[st.selecionado];
    inputTexto.value = t ? t.texto : '';
    document.querySelectorAll('#previa-cores .previa-cor').forEach(b => b.classList.toggle('ativa', t ? b.dataset.cor === t.cor : b.dataset.cor === corAtual));
  }
  function adicionarTexto() {
    st.textos.push({ texto: 'Texto', x: 0.5, y: 0.5, cor: corAtual, tam: 0.08 });
    st.selecionado = st.textos.length - 1;
    st.editou = true;
    sincronizarBarraTexto(); desenharPrevia();
    inputTexto.focus(); inputTexto.select();
  }
  document.getElementById('previa-texto-add').onclick = adicionarTexto;
  inputTexto.oninput = () => {
    const t = st.textos[st.selecionado]; if (!t) return;
    t.texto = inputTexto.value || ' '; st.editou = true; desenharPrevia();
  };
  document.querySelectorAll('#previa-cores .previa-cor').forEach(b => {
    b.onclick = () => {
      corAtual = b.dataset.cor;
      const t = st.textos[st.selecionado]; if (t) { t.cor = corAtual; st.editou = true; }
      sincronizarBarraTexto(); desenharPrevia();
    };
  });
  const mudarTam = fator => { const t = st.textos[st.selecionado]; if (!t) return; t.tam = Math.max(0.03, Math.min(0.25, t.tam * fator)); st.editou = true; desenharPrevia(); };
  document.getElementById('previa-texto-mais').onclick = () => mudarTam(1.15);
  document.getElementById('previa-texto-menos').onclick = () => mudarTam(1 / 1.15);
  document.getElementById('previa-texto-remover').onclick = () => {
    if (st.selecionado < 0) return;
    st.textos.splice(st.selecionado, 1);
    st.selecionado = st.textos.length - 1;
    sincronizarBarraTexto(); desenharPrevia();
  };
  document.getElementById('previa-texto-ok').onclick = () => {
    st.textos = st.textos.filter(t => t.texto.trim());
    definirModoEditor('ver');
  };

  // arrastar o texto direto na foto
  let movendo = null;
  cv.addEventListener('pointerdown', e => {
    if (st.modo !== 'texto') return;
    const r = cv.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width * cv.width, py = (e.clientY - r.top) / r.height * cv.height;
    let achou = -1;
    for (let i = st.textos.length - 1; i >= 0; i--) {
      const t = st.textos[i];
      if (Math.abs(px - t.x * cv.width) <= (t._w || 0) / 2 + 14 && Math.abs(py - t.y * cv.height) <= (t._h || 0) / 2 + 14) { achou = i; break; }
    }
    if (achou < 0) return;
    e.preventDefault();
    cv.setPointerCapture(e.pointerId);
    st.selecionado = achou; sincronizarBarraTexto();
    movendo = { dx: st.textos[achou].x - px / cv.width, dy: st.textos[achou].y - py / cv.height };
    desenharPrevia();
  });
  cv.addEventListener('pointermove', e => {
    if (!movendo) return;
    const r = cv.getBoundingClientRect(), t = st.textos[st.selecionado];
    t.x = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width + movendo.dx));
    t.y = Math.max(0, Math.min(1, (e.clientY - r.top) / r.height + movendo.dy));
    st.editou = true;
    desenharPrevia();
  });
  const fimMover = () => { movendo = null; };
  cv.addEventListener('pointerup', fimMover);
  cv.addEventListener('pointercancel', fimMover);
}

async function enviarAnexo(file, legenda) {
  if (!file || !chatAtualId || !usuarioAtual || !socket) return false;

  const formData = new FormData();
  formData.append('file', file);

  try {
    const resp = await fetch('/api/upload', { method: 'POST', body: formData });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || typeof data.url !== 'string' || !data.url.trim()) {
      throw new Error(data.error || 'O servidor não confirmou o upload do arquivo.');
    }

    const tipo = file.type.startsWith('image/') ? 'image'
      : file.type.startsWith('audio/') ? 'audio'
      : file.type.startsWith('video/') ? 'video'
      : 'file';

    socket.emit('send_message', {
      chatId: chatAtualId,
      userId: usuarioAtual.id,
      type: tipo,
      content: tipo === 'file' ? file.name : ((tipo === 'image' || tipo === 'video') && legenda ? legenda : null),
      mediaUrl: data.url,
      replyTo: respondendoA,
      expiresIn: preferenciasChatAtual.ephemeral || null,
      highQuality: altaQualidadeAtual
    });

    cancelarResposta();
    const input = document.getElementById('input-anexo');
    if (input) input.value = '';
    return true;
  } catch (err) {
    console.error('Falha ao enviar anexo:', err);
    mostrarAviso(err && err.message ? err.message : 'Não deu pra enviar esse arquivo.');
    return false;
  }
}

// ---------- Deslizar mensagem pra responder (tipo o Zap) ----------
// Em vez de precisar tocar na mensagem pra abrir o menu de ações, dá pra
// arrastar ela um pouco pra direita e soltar que já chama responderMensagem().
(function configurarSwipeParaResponder() {
  const LIMIAR_PX = 46;   // quanto precisa arrastar pra disparar o "Responder"
  const MAX_PX = 70;      // até onde a mensagem se move na tela
  let msgEl = null;
  let inicioX = 0, inicioY = 0;
  let deltaAtual = 0;
  let decidiuHorizontal = false;
  let deslizando = false;

  function pegarContainer() {
    return document.getElementById('mensagens');
  }

  function onTouchStart(e) {
    const container = pegarContainer();
    if (!container || !container.contains(e.target)) return;
    const alvo = e.target.closest('.msg');
    if (!alvo) return;
    msgEl = alvo;
    const t = e.touches[0];
    inicioX = t.clientX;
    inicioY = t.clientY;
    deltaAtual = 0;
    decidiuHorizontal = false;
    deslizando = false;
  }

  function onTouchMove(e) {
    if (!msgEl) return;
    const t = e.touches[0];
    const dx = t.clientX - inicioX;
    const dy = t.clientY - inicioY;

    if (!decidiuHorizontal) {
      if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
        decidiuHorizontal = Math.abs(dx) > Math.abs(dy);
        if (!decidiuHorizontal) { msgEl = null; return; } // deixa rolar a lista normalmente
        deslizando = true;
        msgEl.classList.add('arrastando');
      } else {
        return;
      }
    }

    if (!deslizando) return;
    // só deixa arrastar pra direita (como no Zap)
    const dxClamp = Math.max(0, Math.min(MAX_PX, dx));
    deltaAtual = dxClamp;
    msgEl.style.transform = `translateX(${dxClamp}px)`;
    const icone = msgEl.querySelector('.swipe-icone-responder');
    if (icone) icone.style.opacity = Math.min(1, dxClamp / LIMIAR_PX);
    if (dxClamp > 4) e.preventDefault(); // evita a página rolar junto enquanto arrasta
  }

  function resetarMsg(el) {
    if (!el) return;
    el.classList.remove('arrastando');
    el.style.transform = '';
    const icone = el.querySelector('.swipe-icone-responder');
    if (icone) icone.style.opacity = 0;
  }

  function onTouchEnd() {
    if (!msgEl) return;
    const el = msgEl;
    const disparou = deslizando && deltaAtual >= LIMIAR_PX;
    resetarMsg(el);
    if (disparou) {
      const id = el.dataset.id;
      if (id) {
        if (navigator.vibrate) navigator.vibrate(12);
        responderMensagem(id);
      }
    }
    msgEl = null;
    deslizando = false;
    decidiuHorizontal = false;
  }

  document.addEventListener('touchstart', onTouchStart, { passive: true });
  document.addEventListener('touchmove', onTouchMove, { passive: false });
  document.addEventListener('touchend', onTouchEnd, { passive: true });
  document.addEventListener('touchcancel', onTouchEnd, { passive: true });
})();
// =========================================================
//  PLAYER DE ÁUDIO
// =========================================================
// <<ICONES_ARQUIVO>>
// ---------- Cartão de arquivo: ícone por tipo + nome ----------
// Cada grupo: [cor, rótulo mostrado no ícone (vazio = usa a própria extensão), extensões]
const ICONES_ARQUIVO = {};
(function () {
  const grupos = [
    ['#e5484d', 'PDF',  ['pdf']],
    ['#3b82f6', 'DOC',  ['doc', 'docx', 'odt', 'rtf']],
    ['#22a06b', 'XLS',  ['xls', 'xlsx', 'ods']],
    ['#22a06b', 'CSV',  ['csv']],
    ['#f97316', 'PPT',  ['ppt', 'pptx', 'odp']],
    ['#8b8f9c', 'TXT',  ['txt', 'log', 'md']],
    ['#d9a400', 'ZIP',  ['zip', 'rar', '7z', 'tar', 'gz']],
    ['#8b5cf6', '',     ['js', 'ts', 'py', 'html', 'css', 'json', 'java', 'c', 'cpp', 'cs', 'php', 'sql', 'xml', 'sh']],
    ['#ec4899', '',     ['mp3', 'wav', 'ogg', 'm4a', 'flac', 'aac']],
    ['#14b8a6', '',     ['mp4', 'webm', 'mov', 'mkv', 'avi']],
    ['#06b6d4', '',     ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg']],
    ['#64748b', 'APK',  ['apk']],
    ['#64748b', 'EXE',  ['exe', 'msi']]
  ];
  grupos.forEach(([cor, rotulo, exts]) => exts.forEach(e => {
    ICONES_ARQUIVO[e] = { cor, rotulo: rotulo || e.toUpperCase() };
  }));
})();
// Tipos que o navegador sabe mostrar sozinho: abrem em nova aba. O resto baixa.
const ARQUIVOS_ABREM_NO_NAVEGADOR = ['pdf', 'txt', 'log', 'md', 'json', 'csv'];
// <</ICONES_ARQUIVO>>

function extensaoDoArquivo(nome) {
  const m = /\.([A-Za-z0-9]+)$/.exec(String(nome || '').trim());
  return m ? m[1].toLowerCase() : '';
}

function tipoDoArquivo(nome) {
  const ext = extensaoDoArquivo(nome);
  const base = ICONES_ARQUIVO[ext] || { cor: '#64748b', rotulo: ext ? ext.toUpperCase().slice(0, 4) : 'ARQ' };
  return { ext, cor: base.cor, rotulo: base.rotulo, abre: ARQUIVOS_ABREM_NO_NAVEGADOR.includes(ext) };
}

// Deixa o nome quebrar depois de _ e - e antes do ponto, assim a extensão (.pdf) nunca é cortada ao meio
function nomeQuebravel(nome) {
  return escapeHtml(nome).replace(/([_-])/g, '$1<wbr>').replace(/\./g, '<wbr>.');
}

function montarCartaoArquivo(msg) {
  const nome = msg.content || 'arquivo';
  const t = tipoDoArquivo(nome);
  const tamanhoFonte = t.rotulo.length > 3 ? 9 : 11;
  const icone = '<svg class="arq-icone" viewBox="0 0 40 48" aria-hidden="true">'
    + '<path d="M6 2h20l12 12v30a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z" fill="' + t.cor + '"/>'
    + '<path d="M26 2l12 12H28a2 2 0 0 1-2-2z" fill="rgba(255,255,255,.38)"/>'
    + '<text x="20" y="37" text-anchor="middle" font-size="' + tamanhoFonte + '" font-weight="800" '
    + 'font-family="Arial, Helvetica, sans-serif" fill="#fff">' + escapeHtml(t.rotulo) + '</text></svg>';
  const atributos = t.abre
    ? 'target="_blank" rel="noopener"'
    : 'download="' + escapeAttr(nome) + '" target="_blank" rel="noopener"';
  return '<a class="arq-cartao" href="' + escapeAttr(msg.mediaUrl) + '" ' + atributos + ' title="' + escapeAttr(nome) + '">'
    + icone
    + '<span class="arq-info"><span class="arq-nome">' + nomeQuebravel(nome) + '</span>'
    + '<span class="arq-sub">' + escapeHtml(t.rotulo) + ' · ' + (t.abre ? 'Abrir' : 'Baixar') + '</span></span></a>';
}

const AUDIO_BARRAS = 34;

function ondasDoAudio(seed) {
  let n = 7;
  for (let i = 0; i < (seed || '').length; i++) n = (n * 31 + seed.charCodeAt(i)) % 2147483647;
  let html = '';
  for (let i = 0; i < AUDIO_BARRAS; i++) {
    n = (n * 1103515245 + 12345) % 2147483647;
    const altura = 20 + (n % 80);
    html += `<span class="audio-barra" style="height:${altura}%"></span>`;
  }
  return html;
}

function montarPlayerAudio(msg) {
  // .replace(...) tira as quebras de linha e espaços do template, que viravam linhas em branco
  return `
    <div class="audio-player ${Array.isArray(msg.readBy) && msg.readBy.length ? 'audio-read' : ''}">
      <button class="audio-btn" type="button" aria-label="Tocar áudio">
        <svg class="audio-icone audio-icone-play" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
        <svg class="audio-icone audio-icone-pause oculto" viewBox="0 0 24 24" fill="currentColor"><path d="M7 5h4v14H7zm6 0h4v14h-4z"/></svg>
      </button>
      <div class="audio-meio">
        <div class="audio-onda">${ondasDoAudio(msg.id)}</div>
        <div class="audio-rodape">
          <span class="audio-tempo" data-current="0:00" data-duration="0:00">0:00 / 0:00</span>
          <button class="audio-velocidade" type="button" title="Velocidade">1×</button>
        </div>
      </div>
      <audio preload="metadata" src="${escapeAttr(msg.mediaUrl)}"></audio>
    </div>`.replace(/>\s+</g, '><').trim();
}

function formatarTempoAudio(seg) {
  if (!isFinite(seg) || seg < 0) return '0:00';
  const m = Math.floor(seg / 60);
  const s = Math.floor(seg % 60);
  return `${m}:${String(s).padStart(2, '0')}`;
}

function pausarOutrosAudios(atual) {
  document.querySelectorAll('.audio-player audio').forEach(a => {
    if (a !== atual && !a.paused) a.pause();
  });
}

function ligarPlayerAudio(divMsg) {
  const player = divMsg.querySelector('.audio-player');
  if (!player) return;
  const audio = player.querySelector('audio');
  const btn = player.querySelector('.audio-btn');
  const onda = player.querySelector('.audio-onda');
  const barras = Array.from(player.querySelectorAll('.audio-barra'));
  const tempoEl = player.querySelector('.audio-tempo');
  const btnVel = player.querySelector('.audio-velocidade');
  const iconePlay = player.querySelector('.audio-icone-play');
  const iconePause = player.querySelector('.audio-icone-pause');
  const velocidades = [1, 1.5, 2];
  let velocidadeAtual = 0;
  let consertandoDuracao = false;
  function atualizarTempoAtual(current) {
    const atual = formatarTempoAudio(current);
    const duracao = formatarTempoAudio(audio.duration);
    tempoEl.dataset.current = atual; tempoEl.dataset.duration = duracao;
    tempoEl.textContent = `${atual} / ${duracao}`;
  }

  function pintar(fracao) {
    const ate = Math.round(fracao * barras.length);
    barras.forEach((b, i) => b.classList.toggle('tocada', i < ate));
  }

  audio.addEventListener('loadedmetadata', () => {
    if (audio.duration === Infinity && !consertandoDuracao) {
      consertandoDuracao = true; audio.currentTime = 1e5; return;
    }
    atualizarTempoAtual(0);
  });
  audio.addEventListener('durationchange', () => {
    if (consertandoDuracao && isFinite(audio.duration)) {
      consertandoDuracao = false; audio.currentTime = 0;
      atualizarTempoAtual(0);
    }
  });
  ['loadeddata', 'canplay'].forEach(ev => audio.addEventListener(ev, () => { if (isFinite(audio.duration)) atualizarTempoAtual(audio.currentTime || 0); }));
  btn.onclick = () => { if (audio.paused) { pausarOutrosAudios(audio); audio.play(); } else audio.pause(); };
  audio.addEventListener('play', () => { player.classList.add('tocando'); iconePlay.classList.add('oculto'); iconePause.classList.remove('oculto'); if (socket?.connected && msg.chatId) socket.emit('message:read', { chatId: msg.chatId }); });
  ['pause','ended'].forEach(ev => audio.addEventListener(ev, () => {
    player.classList.remove('tocando'); iconePlay.classList.remove('oculto'); iconePause.classList.add('oculto');
    if (ev === 'ended') { pintar(1); atualizarTempoAtual(audio.duration); }
  }));
  audio.addEventListener('timeupdate', () => {
    if (consertandoDuracao) return;
    if (isFinite(audio.duration) && audio.duration > 0) pintar(audio.currentTime / audio.duration);
    atualizarTempoAtual(audio.currentTime);
  });
  onda.onclick = e => {
    if (!isFinite(audio.duration) || !audio.duration) return;
    const rect = onda.getBoundingClientRect();
    audio.currentTime = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width)) * audio.duration;
  };
  btnVel.onclick = () => {
    velocidadeAtual = (velocidadeAtual + 1) % velocidades.length;
    audio.playbackRate = velocidades[velocidadeAtual];
    btnVel.textContent = velocidades[velocidadeAtual] + '×';
  };
}

// =========================================================
//  ENCAMINHAR (máx 5)
// =========================================================
const MAX_ENCAMINHAR = 5;
let modoEncaminhar = false;
let msgsSelecionadas = new Set();

function iniciarEncaminhar(id) {
  modoEncaminhar = true;
  msgsSelecionadas = new Set([id]);
  const container = document.getElementById('mensagens');
  if (container) container.classList.add('selecionando');
  document.querySelectorAll('#mensagens .msg').forEach(el => {
    el.classList.toggle('msg-selecionada', msgsSelecionadas.has(el.dataset.id));
  });
  mostrarBarraEncaminhar();
}

function alternarSelecaoMsg(id, el) {
  if (msgsSelecionadas.has(id)) { msgsSelecionadas.delete(id); el.classList.remove('msg-selecionada'); }
  else {
    if (msgsSelecionadas.size >= MAX_ENCAMINHAR) { mostrarAviso(`Máximo de ${MAX_ENCAMINHAR} mensagens por vez.`); return; }
    msgsSelecionadas.add(id); el.classList.add('msg-selecionada');
  }
  if (!msgsSelecionadas.size) { sairDoModoEncaminhar(); return; }
  mostrarBarraEncaminhar();
}

document.addEventListener('click', e => {
  if (!modoEncaminhar) return;
  const el = e.target.closest('#mensagens .msg');
  if (!el || !el.dataset.id) return;
  e.preventDefault(); e.stopPropagation();
  alternarSelecaoMsg(el.dataset.id, el);
}, true);

function mostrarBarraEncaminhar() {
  let barra = document.getElementById('barra-encaminhar');
  if (!barra) {
    barra = document.createElement('div');
    barra.id = 'barra-encaminhar';
    barra.className = 'barra-encaminhar';
    const chatView = document.getElementById('chat-view');
    if (chatView) chatView.appendChild(barra);
  }
  barra.innerHTML = `
    <span class="barra-encaminhar-info">${msgsSelecionadas.size} de ${MAX_ENCAMINHAR} selecionada${msgsSelecionadas.size === 1 ? '' : 's'}</span>
    <button class="btn-link" type="button" onclick="sairDoModoEncaminhar()">Cancelar</button>
    <button class="btn-ok btn-compacto" type="button" onclick="abrirDestinoEncaminhar()">Encaminhar →</button>`;
}

function sairDoModoEncaminhar() {
  modoEncaminhar = false; msgsSelecionadas = new Set();
  const container = document.getElementById('mensagens');
  if (container) container.classList.remove('selecionando');
  document.querySelectorAll('.msg-selecionada').forEach(el => el.classList.remove('msg-selecionada'));
  const barra = document.getElementById('barra-encaminhar');
  if (barra) barra.remove();
}

function abrirDestinoEncaminhar() {
  const destinos = todasAsConversas.filter(c => !c.removidoDoGrupo);
  const root = document.getElementById('modal-root');
  const linhas = destinos.length
    ? destinos.map(c => `
        <div class="dropdown-item conta-item dropdown-clicavel" onclick="encaminharPara('${c.id}')">
          <span class="conta-info">
            <span class="avatar-circle avatar-circle--sm">${avatarInnerHtml(c.name, c.photoUrl)}</span>
            <span>${escapeHtml(c.name)}</span>
          </span>
          ${c.type === 'group' ? '<span class="tag-papel tag-admin">Grupo</span>' : ''}
        </div>`).join('')
    : '<p class="modal-texto">Você não tem conversas para encaminhar.</p>';
  root.innerHTML = `
    <div class="modal-overlay" id="modal-overlay">
      <div class="modal-box">
        <h3 class="modal-title">Encaminhar para</h3>
        <p class="modal-texto">${msgsSelecionadas.size} mensagem${msgsSelecionadas.size === 1 ? '' : 's'} selecionada${msgsSelecionadas.size === 1 ? '' : 's'}.</p>
        <div class="lista-contatos">${linhas}</div>
        <div class="modal-actions">
          <button class="btn-outline btn-compacto" id="encaminhar-cancelar" type="button">Cancelar</button>
        </div>
      </div>
    </div>`;
  document.getElementById('encaminhar-cancelar').onclick = () => { root.innerHTML = ''; };
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') root.innerHTML = ''; };
}

function encaminharPara(chatId) {
  const msgs = Array.from(msgsSelecionadas).map(id => mensagensCacheAtual.get(id)).filter(m => m && !m.deleted);
  document.getElementById('modal-root').innerHTML = '';
  if (!msgs.length) { sairDoModoEncaminhar(); return; }
  msgs.forEach(m => socket.emit('send_message', { chatId, userId: usuarioAtual.id, type: m.type, content: m.content, mediaUrl: m.mediaUrl, encaminhada: true }));
  const total = msgs.length;
  sairDoModoEncaminhar();
  mostrarAviso(`${total} mensagem${total === 1 ? '' : 's'} encaminhada${total === 1 ? '' : 's'}.`, 'sucesso');
  carregarListaChats();
}

// =========================================================
//  PERFIL DA PESSOA (PV)
// =========================================================
function abrirInfoConversa() {
  if (chatAtualTipo === 'group') { abrirInfoGrupo(); return; }
  if (chatAtualOutro) abrirPerfilUsuario(chatAtualOutro.id);
}

async function abrirPerfilUsuario(userId) {
  const resp = await fetch(`/api/users/${userId}/public?viewerId=${usuarioAtual.id}`);
  if (!resp.ok) { mostrarAviso('Não foi possível abrir esse perfil.'); return; }
  const u = await resp.json();
  const root = document.getElementById('modal-root');
  const ring = /^#[0-9a-fA-F]{6}$/.test(u.ringColor || '') ? u.ringColor : '#c7f36b';
  const fotoHtml = u.photoUrl
    ? `<img class="perfil-foto-grande" style="border-color:${escapeAttr(ring)}" src="${escapeAttr(u.photoUrl)}" alt="Foto de ${escapeAttr(u.username)}" onclick="window.open('${escapeAttr(u.photoUrl)}','_blank')" title="Ver foto em tamanho grande">`
    : `<div class="avatar-circle avatar-circle--lg perfil-editor-avatar" style="border-color:${escapeAttr(ring)}">${avatarInnerHtml(u.username, null)}</div>`;
  const bannerHtml = u.bannerUrl ? `<div class="perfil-publico-banner" style="background-image:url('${escapeAttr(u.bannerUrl)}')"></div>` : '';
  const bioHtml = u.bio ? `<div class="perfil-bio-card"><span class="perfil-bio-aspas perfil-bio-aspas--abre" aria-hidden="true">“</span><p class="perfil-bio">${escapeHtml(u.bio)}</p><span class="perfil-bio-aspas perfil-bio-aspas--fecha" aria-hidden="true">”</span></div>` : `<div class="perfil-bio-card perfil-bio-card--vazia"><span class="perfil-bio-aspas perfil-bio-aspas--abre" aria-hidden="true">“</span><p class="perfil-bio perfil-bio--vazia">Sem bio.</p><span class="perfil-bio-aspas perfil-bio-aspas--fecha" aria-hidden="true">”</span></div>`;
  const redes = Array.isArray(u.socials) ? u.socials : [];
  const bases = { instagram: 'https://www.instagram.com/', tiktok: 'https://www.tiktok.com/@', youtube: 'https://www.youtube.com/@', facebook: 'https://www.facebook.com/', x: 'https://x.com/' };
  const nomes = { instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube', facebook: 'Facebook', x: 'X' };
  const linksHtml = redes.map(r => {
    if (!bases[r.network] || !r.handle) return '';
    const handle = r.handle.replace(/^@+/, '');
    const url = bases[r.network] + encodeURIComponent(handle);
    return `<a class="perfil-rede-link" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer"><span class="perfil-rede-icone mdi mdi-${r.network === 'x' ? 'alpha-x-circle' : r.network === 'youtube' ? 'youtube' : r.network}"></span><span class="perfil-rede-nome">${nomes[r.network]}</span><span class="perfil-rede-handle">@${escapeHtml(handle)}</span><span class="mdi mdi-open-in-new perfil-rede-externo"></span></a>`;
  }).join('');
  const virtualContactHtml = u.contactNumber ? `<div class="perfil-contato-link perfil-contato-virtual"><span class="mdi mdi-identifier"></span><span>Contato: <strong>${escapeHtml(u.contactNumber)}</strong></span><button type="button" class="perfil-numero-copiar" onclick="navigator.clipboard.writeText('${escapeAttr(u.contactNumber)}').then(()=>mostrarAviso('Número copiado!')).catch(()=>mostrarAviso('Número: ${escapeAttr(u.contactNumber)}'))" aria-label="Copiar número"><span class="mdi mdi-content-copy"></span></button></div>` : '';
  const profileMeta = [
    u.age ? { icon: 'calendar-account', text: `${escapeHtml(String(u.age))} anos` } : null,
    u.sexuality ? { icon: 'account-heart-outline', text: escapeHtml(u.sexuality) } : null,
    [u.city, u.state].filter(Boolean).length ? { icon: 'map-marker-outline', text: [u.city, u.state].filter(Boolean).map(escapeHtml).join(', ') } : null,
    u.relationshipStatus ? { icon: 'heart-outline', text: escapeHtml(u.relationshipStatus) } : null
  ].filter(Boolean);
  const profileMetaHtml = profileMeta.length ? `<div class="perfil-meta-grid">${profileMeta.map(item => `<div class="perfil-meta-item"><span class="mdi mdi-${item.icon}"></span><span>${item.text}</span></div>`).join('')}</div>` : '';
  const phoneHtml = u.phone ? `<a class="perfil-contato-link" href="https://wa.me/${u.phone.replace(/\D/g, '')}" target="_blank" rel="noopener noreferrer"><span class="mdi mdi-whatsapp"></span><span>${escapeHtml(u.phone)}</span><span class="mdi mdi-open-in-new"></span></a>` : '';
  root.innerHTML = `
    <div class="modal-overlay perfil-overlay" id="modal-overlay">
      <div class="modal-box modal-box--perfil perfil-publico-card">
        ${bannerHtml}
        <button class="perfil-fechar-x" id="perfil-usuario-fechar-x" type="button" aria-label="Fechar perfil">×</button>
        <div class="perfil-publico-hero">${fotoHtml}<h3 class="modal-title info-grupo-nome">${escapeHtml(u.username)}</h3>${bioHtml}</div>
        <div class="perfil-publico-detalhes">${profileMetaHtml}${virtualContactHtml}${phoneHtml}${linksHtml ? `<div class="perfil-redes-lista">${linksHtml}</div>` : '<p class="perfil-bio perfil-bio--vazia">Nenhuma rede social adicionada.</p>'}</div>
        <div class="modal-actions"><button class="btn-ok btn-compacto" id="perfil-usuario-fechar" type="button">Fechar perfil</button></div>
      </div>
    </div>`;
  const fechar = () => { root.innerHTML = ''; };
  document.getElementById('perfil-usuario-fechar').onclick = fechar;
  document.getElementById('perfil-usuario-fechar-x').onclick = fechar;
  document.getElementById('modal-overlay').onclick = e => { if (e.target.id === 'modal-overlay') fechar(); };
}


// =========================================================
//  CHAMADAS INDIVIDUAIS DE ÁUDIO E VÍDEO (WebRTC + Socket.IO)
// =========================================================
let chamadaAtual = null;
let chamadaDuracaoTimer = null;
let chamadaInicioAt = 0;
let iceServersCache = null;
let estadoChamadaGrupo = null;
let chamadaGrupoAtual = null;
let chamadaGrupoTimer = null;

function atualizarBotoesChamada(ocultar) {
  const audio = document.getElementById('btn-call-audio');
  const video = document.getElementById('btn-call-video');
  const mostrar = !ocultar && !!usuarioAtual && chatAtualTipo === 'private' && !!chatAtualOutro && chatAtualOutro.id !== usuarioAtual.id && !chatAtualRemovido;
  [audio, video].forEach(btn => { if (btn) btn.classList.toggle('oculto', !mostrar); });
  const groupAudio = document.getElementById('btn-group-call-audio');
  const groupVideo = document.getElementById('btn-group-call-video');
  const groupPresence = document.getElementById('group-call-presence');
  const showGroup = !ocultar && !!usuarioAtual && chatAtualTipo === 'group' && !chatAtualRemovido;
  const activeForChat = !!(estadoChamadaGrupo && estadoChamadaGrupo.chatId === chatAtualId);
  [groupAudio, groupVideo].forEach(btn => { if (btn) btn.classList.toggle('oculto', !showGroup || activeForChat); });
  const menuLigar = document.getElementById('call-menu-wrap');
  if (menuLigar) { const algumaOpcao = mostrar || (showGroup && !activeForChat); menuLigar.classList.toggle('oculto', !algumaOpcao); if (!algumaOpcao) fecharMenuLigar(); }
  if (groupPresence) groupPresence.classList.toggle('oculto', !showGroup || !activeForChat);
  if (activeForChat) atualizarPresencaChamadaGrupo();
}

async function carregarIceServers() {
  if (iceServersCache) return iceServersCache;
  const fallback = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
  try {
    const response = await fetch(`/api/calls/ice-config?userId=${encodeURIComponent(usuarioAtual.id)}`, { cache: 'no-store' });
    if (!response.ok) return fallback;
    const data = await response.json();
    iceServersCache = Array.isArray(data.iceServers) && data.iceServers.length ? data.iceServers : fallback;
  } catch (_) { iceServersCache = fallback; }
  return iceServersCache;
}

function obterCallOverlay() { return document.getElementById('call-overlay'); }
function mostrarCallOverlay() { const el = obterCallOverlay(); if (el) { el.hidden = false; document.body.classList.add('call-open'); const pill = document.getElementById('call-mini-pill'); if (pill) pill.hidden = true; } }
function esconderCallOverlay() { const el = obterCallOverlay(); if (el) { el.hidden = true; document.body.classList.remove('call-open'); } }
function minimizarChamada() {
  if (!chamadaAtual) return;
  esconderCallOverlay();
  const pill = document.getElementById('call-mini-pill');
  if (pill) { pill.hidden = false; const label = document.getElementById('call-mini-label'); if (label) label.textContent = chamadaAtual.peerName || 'Chamada em andamento'; }
}
function reabrirChamadaMinimizada() { if (!chamadaAtual) return; mostrarCallOverlay(); mostrarVistaChamada(chamadaAtual.accepted ? 'call-active-view' : chamadaAtual.role === 'callee' ? 'call-incoming-view' : 'call-connecting-view'); }
function mostrarVistaChamada(vista) {
  ['call-incoming-view','call-active-view','call-connecting-view'].forEach(id => { const el = document.getElementById(id); if (el) el.hidden = id !== vista; });
}
function setCallText(id, value) { const el = document.getElementById(id); if (el) el.textContent = value; }
function callAvatarHtml(name, photoUrl) {
  if (photoUrl) return `<img src="${escapeAttr(photoUrl)}" alt="" referrerpolicy="no-referrer">`;
  return `<span>${escapeHtml((name || '?').trim().charAt(0).toUpperCase() || '?')}</span>`;
}
function atualizarAvataresChamada(name, photoUrl) {
  ['call-incoming-avatar','call-active-avatar'].forEach(id => { const el = document.getElementById(id); if (el) { el.innerHTML = callAvatarHtml(name, photoUrl); } });
}

async function iniciarChamada(mode) {
  if (!usuarioAtual || !socket || !socket.connected) return mostrarAviso('Conecte-se novamente antes de iniciar uma chamada.');
  if (chatAtualTipo !== 'private' || !chatAtualOutro || !chatAtualOutro.id || chatAtualOutro.id === usuarioAtual.id) return mostrarAviso('As chamadas estão disponíveis em conversas individuais.');
  if (chamadaAtual) return mostrarAviso('Você já tem uma chamada em andamento.');
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.RTCPeerConnection) return mostrarAviso('Seu navegador não oferece suporte às chamadas WebRTC. Abra o Mitto em HTTPS num navegador atualizado.');
  try {
    const constraints = { audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: mode === 'video' ? { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } : false };
    const stream = await navigator.mediaDevices.getUserMedia(constraints);
    const callId = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : `call-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    chamadaAtual = { callId, chatId: chatAtualId, mode, role: 'caller', peerId: chatAtualOutro.id, peerName: chatAtualOutro.username || document.getElementById('chat-header-nome')?.textContent || 'Contato', peerPhotoUrl: chatAtualOutro.photoUrl || null, localStream: stream, remoteStream: null, pc: null, pendingIce: [], accepted: false, muted: false, cameraOff: false, speakerOff: false, cameraFacing: 'user' };
    atualizarAvataresChamada(chamadaAtual.peerName, chamadaAtual.peerPhotoUrl);
    setCallText('call-connecting-title', mode === 'video' ? 'Chamada de vídeo' : 'Chamada de áudio');
    setCallText('call-connecting-subtitle', `Chamando ${chamadaAtual.peerName}…`);
    mostrarCallOverlay(); mostrarVistaChamada('call-connecting-view'); atualizarPreviewLocal();
    socket.emit('call:invite', { chatId: chatAtualId, callId, mode });
  } catch (error) {
    const msg = error && (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') ? 'Permita o acesso ao microfone e à câmera para fazer chamadas.' : error && error.name === 'NotFoundError' ? 'Não foi encontrada uma câmera ou um microfone disponível.' : 'Não foi possível acessar a câmera ou o microfone.';
    mostrarAviso(msg); limparChamadaLocal(false);
  }
}

function registrarEventosChamada(sock) {
  sock.on('group:call:error', payload => { mostrarAviso(payload?.message || 'Não foi possível entrar na chamada do grupo.'); if (chamadaGrupoAtual && !chamadaGrupoAtual.callId) limparChamadaGrupoLocal(false); });
  sock.on('group:call:state', payload => {
    if (!payload || payload.chatId !== chatAtualId) return;
    const state = payload.call || null;
    estadoChamadaGrupo = state;
    atualizarBotoesChamada();
    if (state) atualizarPresencaChamadaGrupo();
    if (!state && chamadaGrupoAtual && chamadaGrupoAtual.callId) limparChamadaGrupoLocal(false);
    if (state && chamadaGrupoAtual && !chamadaGrupoAtual.callId && chamadaGrupoAtual.chatId === state.chatId) socket.emit('group:call:join', { chatId: state.chatId });
  });
  sock.on('group:call:joined', async payload => {
    if (!chamadaGrupoAtual) return;
    chamadaGrupoAtual.callId = payload.callId; chamadaGrupoAtual.chatId = payload.chatId;
    chamadaGrupoAtual.mode = payload.mode; chamadaGrupoAtual.startedAt = payload.startedAt;
    chamadaGrupoAtual.joined = true;
    const title = document.getElementById('group-call-title'); if (title) title.textContent = document.getElementById('chat-header-nome')?.textContent || 'Chamada do grupo';
    const mode = document.getElementById('group-call-mode-label'); if (mode) mode.textContent = payload.mode === 'video' ? 'CHAMADA DE VÍDEO' : 'CHAMADA DE ÁUDIO';
    document.getElementById('group-call-overlay').hidden = false; document.body.classList.add('call-open');
    renderizarTilesChamadaGrupo(); iniciarTimerChamadaGrupo();
    (payload.peers || []).forEach(peer => garantirPeerGrupo(peer.userId, peer.username, peer.photoUrl));
    atualizarBotoesChamada(); atualizarPresencaChamadaGrupo();
  });
  sock.on('group:call:peer-joined', payload => { if (chamadaGrupoAtual && chamadaGrupoAtual.callId === payload.callId) criarOfertaPeerGrupo(payload.userId, payload.username, payload.photoUrl).catch(err => console.warn('[Mitto group call] offer:', err)); });
  sock.on('group:call:peer-left', payload => { if (!chamadaGrupoAtual || chamadaGrupoAtual.callId !== payload.callId) return; removerPeerGrupo(payload.userId); renderizarTilesChamadaGrupo(); });
  sock.on('group:call:left', payload => { if (chamadaGrupoAtual && chamadaGrupoAtual.callId === payload.callId) limparChamadaGrupoLocal(false); });
  sock.on('group:call:signal', payload => processarSinalGrupo(payload).catch(err => console.warn('[Mitto group call] signal:', err)));
  sock.on('call:error', payload => { mostrarAviso(payload && payload.message || 'Não foi possível iniciar a chamada.'); if (chamadaAtual && !chamadaAtual.accepted) limparChamadaLocal(false); });
  sock.on('call:busy', payload => { mostrarAviso(payload && payload.message || 'A linha está ocupada.'); limparChamadaLocal(false); });
  sock.on('call:unavailable', payload => { mostrarAviso(payload && payload.message || 'Usuário indisponível.'); limparChamadaLocal(false); });
  sock.on('call:outgoing', payload => {
    if (!chamadaAtual || chamadaAtual.callId !== payload.callId) return;
    setCallText('call-connecting-subtitle', `Chamando ${chamadaAtual.peerName}…`);
  });
  sock.on('call:incoming', async payload => {
    if (chamadaAtual) { sock.emit('call:reject', { callId: payload.callId }); return; }
    // O servidor já valida a conversa privada e aplica a privacidade da foto antes de enviar o convite.
    const photoUrl = payload.callerPhotoUrl || null;
    chamadaAtual = { callId: payload.callId, chatId: payload.chatId, mode: payload.mode, role: 'callee', peerId: payload.callerId, peerName: payload.callerName || 'Contato', peerPhotoUrl: photoUrl, localStream: null, remoteStream: null, pc: null, pendingIce: [], accepted: false, muted: false, cameraOff: false, speakerOff: false, cameraFacing: 'user' };
    atualizarAvataresChamada(chamadaAtual.peerName, photoUrl);
    setCallText('call-incoming-name', chamadaAtual.peerName);
    setCallText('call-incoming-description', payload.mode === 'video' ? 'Está fazendo uma chamada de vídeo' : 'Está fazendo uma chamada de áudio');
    mostrarCallOverlay(); mostrarVistaChamada('call-incoming-view');
    try { if (navigator.vibrate) navigator.vibrate([180, 80, 180]); } catch (_) {}
  });
  sock.on('call:accepted', async payload => {
    if (!chamadaAtual || chamadaAtual.callId !== payload.callId || chamadaAtual.role !== 'caller') return;
    chamadaAtual.accepted = true;
    mostrarVistaChamada('call-active-view'); setCallText('call-active-name', chamadaAtual.peerName); setCallText('call-status', 'Conectando…'); iniciarCronometroChamada();
    try {
      const pc = await garantirPeerConnection();
      const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
      sock.emit('call:signal', { callId: chamadaAtual.callId, kind: 'offer', data: pc.localDescription.toJSON ? pc.localDescription.toJSON() : { type: pc.localDescription.type, sdp: pc.localDescription.sdp } });
    } catch (e) { mostrarAviso('Não foi possível estabelecer a chamada.'); encerrarChamada(); }
  });
  sock.on('call:accepted-local', payload => {
    if (!chamadaAtual || chamadaAtual.callId !== payload.callId || chamadaAtual.role !== 'callee') return;
    chamadaAtual.accepted = true; mostrarVistaChamada('call-active-view'); setCallText('call-active-name', chamadaAtual.peerName); setCallText('call-status', 'Conectando…'); iniciarCronometroChamada();
    atualizarPreviewLocal();
  });
  sock.on('call:rejected', payload => { if (!chamadaAtual || chamadaAtual.callId !== payload.callId) return; limparChamadaLocal(false); mostrarAviso('A chamada foi recusada.'); });
  sock.on('call:cancelled', payload => { if (!chamadaAtual || chamadaAtual.callId !== payload.callId) return; limparChamadaLocal(false); mostrarAviso('A chamada foi cancelada.'); });
  sock.on('call:ended', payload => { if (!chamadaAtual || chamadaAtual.callId !== payload.callId) return; limparChamadaLocal(false); mostrarAviso(payload.reason === 'disconnect' ? 'A chamada terminou porque a conexão foi perdida.' : 'Chamada encerrada.'); });
  sock.on('disconnect', () => { if (chamadaAtual) limparChamadaLocal(false); });
  sock.on('call:signal', async payload => {
    // A oferta pode chegar milissegundos antes do evento accepted-local por causa da latência entre sockets.
    if (!chamadaAtual || chamadaAtual.callId !== payload.callId) return;
    try {
      const pc = await garantirPeerConnection();
      if (payload.kind === 'offer' && chamadaAtual.role === 'callee') {
        await pc.setRemoteDescription(new RTCSessionDescription(payload.data));
        await processarIcePendente();
        const answer = await pc.createAnswer(); await pc.setLocalDescription(answer);
        sock.emit('call:signal', { callId: chamadaAtual.callId, kind: 'answer', data: pc.localDescription.toJSON ? pc.localDescription.toJSON() : { type: pc.localDescription.type, sdp: pc.localDescription.sdp } });
      } else if (payload.kind === 'answer' && chamadaAtual.role === 'caller') {
        await pc.setRemoteDescription(new RTCSessionDescription(payload.data));
        await processarIcePendente();
      } else if (payload.kind === 'ice' && payload.data) {
        if (pc.remoteDescription && pc.remoteDescription.type) await pc.addIceCandidate(new RTCIceCandidate(payload.data));
        else chamadaAtual.pendingIce.push(payload.data);
      }
    } catch (e) { console.warn('[Mitto call] sinalização falhou:', e); }
  });
}

async function iniciarChamadaGrupo(mode) {
  if (!usuarioAtual || !socket || !socket.connected) return mostrarAviso('Conecte-se novamente antes de iniciar uma chamada.');
  if (chatAtualTipo !== 'group' || !chatAtualId || chatAtualRemovido) return mostrarAviso('Abra um grupo do qual você faz parte.');
  if (chamadaAtual || chamadaGrupoAtual) return mostrarAviso('Você já está em uma chamada.');
  if (!navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) return mostrarAviso('Seu navegador não oferece suporte a chamadas WebRTC. Use HTTPS e um navegador atualizado.');
  try {
    await carregarIceServers();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: mode === 'video' ? { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } : false });
    chamadaGrupoAtual = { callId: null, chatId: chatAtualId, mode, localStream: stream, peers: new Map(), muted: false, cameraOff: false, joined: false, startedAt: Date.now() };
    if (estadoChamadaGrupo && estadoChamadaGrupo.chatId === chatAtualId) socket.emit('group:call:join', { chatId: chatAtualId });
    else socket.emit('group:call:start', { chatId: chatAtualId, mode });
    document.getElementById('group-call-overlay').hidden = false; document.body.classList.add('call-open');
    const status = document.getElementById('group-call-status'); if (status) status.textContent = 'Preparando conexão…';
    renderizarTilesChamadaGrupo();
  } catch (error) {
    const msg = error?.name === 'NotAllowedError' ? 'Permita o acesso ao microfone e à câmera para entrar na chamada.' : error?.name === 'NotFoundError' ? 'Não foi encontrada uma câmera ou um microfone disponível.' : 'Não foi possível acessar o microfone/câmera.';
    mostrarAviso(msg); limparChamadaGrupoLocal(false);
  }
}
function alternarEntradaChamadaGrupo() {
  if (chamadaGrupoAtual && chamadaGrupoAtual.callId && chamadaGrupoAtual.chatId === chatAtualId) return sairChamadaGrupo();
  if (!estadoChamadaGrupo || estadoChamadaGrupo.chatId !== chatAtualId) return mostrarAviso('Nenhuma chamada ativa neste grupo.');
  iniciarChamadaGrupo(estadoChamadaGrupo.mode);
}
function atualizarPresencaChamadaGrupo() {
  const state = estadoChamadaGrupo && estadoChamadaGrupo.chatId === chatAtualId ? estadoChamadaGrupo : null;
  if (!state) return;
  const count = document.getElementById('group-call-count'); const duration = document.getElementById('group-call-duration'); const join = document.getElementById('btn-group-call-join');
  if (count) count.textContent = String((state.participants || []).length);
  if (duration) duration.textContent = formatarDuracaoGrupo(Date.now() - Number(state.startedAt || Date.now()));
  const joined = !!(chamadaGrupoAtual && chamadaGrupoAtual.callId === state.callId && chamadaGrupoAtual.joined);
  if (join) { join.textContent = joined ? 'Sair' : 'Entrar'; join.classList.toggle('joined', joined); }
}
function formatarDuracaoGrupo(ms) { const s = Math.max(0, Math.floor(ms / 1000)); return `${String(Math.floor(s / 60)).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`; }
function iniciarTimerChamadaGrupo() {
  clearInterval(chamadaGrupoTimer);
  chamadaGrupoTimer = setInterval(() => {
    if (!estadoChamadaGrupo) return;
    atualizarPresencaChamadaGrupo();
    const status = document.getElementById('group-call-status');
    if (status && chamadaGrupoAtual) status.textContent = `${formatarDuracaoGrupo(Date.now() - Number(chamadaGrupoAtual.startedAt || Date.now()))} · ${(estadoChamadaGrupo.participants || []).length} participante(s)`;
  }, 1000);
}
function criarTileGrupo(userId, name, photoUrl, local) {
  const tile = document.createElement('div'); tile.className = 'group-call-tile' + (local ? ' local-tile' : ''); tile.dataset.userId = String(userId);
  const avatar = document.createElement('div'); avatar.className = 'tile-avatar';
  if (photoUrl) { const img = document.createElement('img'); img.src = photoUrl; img.alt = ''; img.referrerPolicy = 'no-referrer'; avatar.appendChild(img); } else avatar.textContent = String(name || '?').trim().charAt(0).toUpperCase() || '?';
  tile.appendChild(avatar); const label = document.createElement('div'); label.className = 'tile-name'; label.textContent = local ? `${name || 'Você'} (você)` : (name || 'Membro'); tile.appendChild(label);
  if (chamadaGrupoAtual?.mode === 'video') { const video = document.createElement('video'); video.autoplay = true; video.playsInline = true; video.muted = !!local; video.className = local ? 'group-local-video' : 'group-remote-video'; if (local && chamadaGrupoAtual.localStream) video.srcObject = chamadaGrupoAtual.localStream; tile.insertBefore(video, avatar); avatar.style.display = 'none'; video.play().catch(() => {}); }
  else if (!local) { const audio = document.createElement('audio'); audio.autoplay = true; audio.playsInline = true; audio.dataset.audioFor = userId; tile.appendChild(audio); }
  return tile;
}
function renderizarTilesChamadaGrupo() {
  const grid = document.getElementById('group-call-media-grid'); if (!grid || !chamadaGrupoAtual) return;
  grid.innerHTML = ''; grid.appendChild(criarTileGrupo(usuarioAtual?.id, usuarioAtual?.username || 'Você', usuarioAtual?.photoUrl || null, true));
  chamadaGrupoAtual.peers.forEach((peer, userId) => {
    const tile = criarTileGrupo(userId, peer.username, peer.photoUrl, false);
    if (peer.stream) { const video = tile.querySelector('video'); const audio = tile.querySelector('audio'); if (video) { video.srcObject = peer.stream; video.play().catch(() => {}); } if (audio) { audio.srcObject = peer.stream; audio.play().catch(() => {}); } if (chamadaGrupoAtual.mode === 'video' && peer.stream.getVideoTracks().length) { const avatar = tile.querySelector('.tile-avatar'); if (avatar) avatar.style.display = 'none'; } }
    grid.appendChild(tile);
  });
  const mute = document.getElementById('group-call-mute'); if (mute) { mute.classList.toggle('off', !!chamadaGrupoAtual.muted); mute.querySelector('span').textContent = chamadaGrupoAtual.muted ? 'Microfone mudo' : 'Microfone'; mute.querySelector('.mdi').className = 'mdi ' + (chamadaGrupoAtual.muted ? 'mdi-microphone-off' : 'mdi-microphone'); }
  const camera = document.getElementById('group-call-camera'); if (camera) { camera.style.display = chamadaGrupoAtual.mode === 'video' ? '' : 'none'; camera.classList.toggle('off', !!chamadaGrupoAtual.cameraOff); camera.querySelector('span').textContent = chamadaGrupoAtual.cameraOff ? 'Câmera desligada' : 'Câmera'; camera.querySelector('.mdi').className = 'mdi ' + (chamadaGrupoAtual.cameraOff ? 'mdi-video-off' : 'mdi-video'); }
}
function garantirPeerGrupo(userId, username, photoUrl) {
  if (!chamadaGrupoAtual) throw new Error('Chamada de grupo não iniciada');
  let peer = chamadaGrupoAtual.peers.get(userId); if (peer) { if (username) peer.username = username; if (photoUrl) peer.photoUrl = photoUrl; return peer; }
  peer = { userId, username: username || 'Membro', photoUrl: photoUrl || null, pc: null, stream: new MediaStream(), pendingIce: [] };
  const pc = new RTCPeerConnection({ iceServers: iceServersCache || [{ urls: ['stun:stun.l.google.com:19302'] }], iceCandidatePoolSize: 4 }); peer.pc = pc; chamadaGrupoAtual.peers.set(userId, peer);
  chamadaGrupoAtual.localStream.getTracks().forEach(track => pc.addTrack(track, chamadaGrupoAtual.localStream));
  pc.onicecandidate = e => { if (e.candidate && chamadaGrupoAtual?.callId && socket?.connected) socket.emit('group:call:signal', { callId: chamadaGrupoAtual.callId, toUserId: userId, kind: 'ice', data: e.candidate.toJSON ? e.candidate.toJSON() : e.candidate }); };
  pc.ontrack = e => { if (!chamadaGrupoAtual || !chamadaGrupoAtual.peers.has(userId)) return; const live = chamadaGrupoAtual.peers.get(userId); if (e.streams?.[0]) live.stream = e.streams[0]; else if (!live.stream.getTracks().some(t => t.id === e.track.id)) live.stream.addTrack(e.track); renderizarTilesChamadaGrupo(); };
  pc.onconnectionstatechange = () => { if (pc.connectionState === 'failed') { const status = document.getElementById('group-call-status'); if (status) status.textContent = 'Falha de conexão — verifique TURN'; } };
  return peer;
}
async function criarOfertaPeerGrupo(userId, username, photoUrl) {
  if (!chamadaGrupoAtual?.callId) return; const peer = garantirPeerGrupo(userId, username, photoUrl); const offer = await peer.pc.createOffer(); await peer.pc.setLocalDescription(offer);
  socket.emit('group:call:signal', { callId: chamadaGrupoAtual.callId, toUserId: userId, kind: 'offer', data: peer.pc.localDescription.toJSON ? peer.pc.localDescription.toJSON() : { type: peer.pc.localDescription.type, sdp: peer.pc.localDescription.sdp } }); renderizarTilesChamadaGrupo();
}
async function processarSinalGrupo(payload) {
  if (!chamadaGrupoAtual || chamadaGrupoAtual.callId !== payload.callId) return;
  const info = (estadoChamadaGrupo?.participants || []).find(p => p.userId === payload.fromUserId) || {}; const peer = garantirPeerGrupo(payload.fromUserId, info.username, info.photoUrl); const pc = peer.pc;
  if (payload.kind === 'offer') { await pc.setRemoteDescription(new RTCSessionDescription(payload.data)); for (const ice of peer.pendingIce.splice(0)) { try { await pc.addIceCandidate(new RTCIceCandidate(ice)); } catch (_) {} } const answer = await pc.createAnswer(); await pc.setLocalDescription(answer); socket.emit('group:call:signal', { callId: chamadaGrupoAtual.callId, toUserId: payload.fromUserId, kind: 'answer', data: pc.localDescription.toJSON ? pc.localDescription.toJSON() : { type: pc.localDescription.type, sdp: pc.localDescription.sdp } }); }
  else if (payload.kind === 'answer') { await pc.setRemoteDescription(new RTCSessionDescription(payload.data)); for (const ice of peer.pendingIce.splice(0)) { try { await pc.addIceCandidate(new RTCIceCandidate(ice)); } catch (_) {} } }
  else if (payload.kind === 'ice' && payload.data) { if (pc.remoteDescription?.type) await pc.addIceCandidate(new RTCIceCandidate(payload.data)); else peer.pendingIce.push(payload.data); }
}
function removerPeerGrupo(userId) { if (!chamadaGrupoAtual) return; const peer = chamadaGrupoAtual.peers.get(userId); if (!peer) return; try { peer.pc?.close(); } catch (_) {} peer.stream?.getTracks().forEach(t => { try { t.stop(); } catch (_) {} }); chamadaGrupoAtual.peers.delete(userId); }
function alternarSilencioGrupo() { if (!chamadaGrupoAtual) return; chamadaGrupoAtual.muted = !chamadaGrupoAtual.muted; chamadaGrupoAtual.localStream.getAudioTracks().forEach(t => t.enabled = !chamadaGrupoAtual.muted); renderizarTilesChamadaGrupo(); }
function alternarCameraGrupo() { if (!chamadaGrupoAtual || chamadaGrupoAtual.mode !== 'video') return; chamadaGrupoAtual.cameraOff = !chamadaGrupoAtual.cameraOff; chamadaGrupoAtual.localStream.getVideoTracks().forEach(t => t.enabled = !chamadaGrupoAtual.cameraOff); renderizarTilesChamadaGrupo(); }
function sairChamadaGrupo() { if (chamadaGrupoAtual?.callId && socket?.connected) socket.emit('group:call:leave', { callId: chamadaGrupoAtual.callId }); limparChamadaGrupoLocal(false); }
function limparChamadaGrupoLocal(notificar) {
  clearInterval(chamadaGrupoTimer); chamadaGrupoTimer = null; const call = chamadaGrupoAtual; chamadaGrupoAtual = null;
  if (call) { call.peers.forEach(peer => { try { peer.pc?.close(); } catch (_) {} peer.stream?.getTracks().forEach(t => { try { t.stop(); } catch (_) {} }); }); call.localStream?.getTracks().forEach(t => { try { t.stop(); } catch (_) {} }); }
  const overlay = document.getElementById('group-call-overlay'); if (overlay) overlay.hidden = true; const grid = document.getElementById('group-call-media-grid'); if (grid) grid.innerHTML = ''; document.body.classList.remove('call-open'); atualizarBotoesChamada();
}

async function aceitarChamada() {
  if (!chamadaAtual || chamadaAtual.role !== 'callee' || !socket || !socket.connected) return;
  try {
    const constraints = { audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: chamadaAtual.mode === 'video' ? { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } } : false };
    chamadaAtual.localStream = await navigator.mediaDevices.getUserMedia(constraints);
    await garantirPeerConnection();
    socket.emit('call:accept', { callId: chamadaAtual.callId });
  } catch (error) {
    mostrarAviso(error && error.name === 'NotAllowedError' ? 'Permita o acesso ao microfone e à câmera para atender.' : 'Não foi possível atender sem acesso ao microfone/câmera.');
    socket.emit('call:reject', { callId: chamadaAtual.callId }); limparChamadaLocal(false);
  }
}

function recusarChamada() {
  if (chamadaAtual && socket && socket.connected) socket.emit('call:reject', { callId: chamadaAtual.callId });
  limparChamadaLocal(false);
}
function encerrarChamada() {
  if (chamadaAtual && socket && socket.connected) socket.emit(chamadaAtual.role === 'caller' && !chamadaAtual.accepted ? 'call:cancel' : 'call:end', { callId: chamadaAtual.callId });
  limparChamadaLocal(false);
}
function encerrarChamadaLocal(motivo) { if (motivo === 'minimizada') return minimizarChamada(); encerrarChamada(); }

async function garantirPeerConnection() {
  if (!chamadaAtual) throw new Error('Sem chamada ativa');
  if (chamadaAtual.pc) return chamadaAtual.pc;
  const iceServers = await carregarIceServers();
  const pc = new RTCPeerConnection({ iceServers, iceCandidatePoolSize: 4 });
  chamadaAtual.pc = pc;
  if (chamadaAtual.localStream) chamadaAtual.localStream.getTracks().forEach(track => pc.addTrack(track, chamadaAtual.localStream));
  pc.onicecandidate = event => { if (event.candidate && chamadaAtual && socket && socket.connected) socket.emit('call:signal', { callId: chamadaAtual.callId, kind: 'ice', data: event.candidate.toJSON ? event.candidate.toJSON() : event.candidate }); };
  pc.ontrack = event => {
    if (!chamadaAtual) return;
    if (!chamadaAtual.remoteStream) chamadaAtual.remoteStream = new MediaStream();
    if (!chamadaAtual.remoteStream.getTracks().some(t => t.id === event.track.id)) chamadaAtual.remoteStream.addTrack(event.track);
    const remoteVideo = document.getElementById('call-remote-video');
    const remoteAudio = document.getElementById('call-remote-audio');
    if (chamadaAtual.mode === 'video') {
      if (remoteVideo) { remoteVideo.srcObject = chamadaAtual.remoteStream; remoteVideo.muted = !!chamadaAtual.speakerOff; remoteVideo.play().catch(() => {}); }
      if (remoteAudio) remoteAudio.srcObject = null;
    } else {
      if (remoteVideo) remoteVideo.srcObject = null;
      if (remoteAudio) { remoteAudio.srcObject = chamadaAtual.remoteStream; remoteAudio.muted = !!chamadaAtual.speakerOff; remoteAudio.play().catch(() => {}); }
    }
    const stage = document.getElementById('call-stage'); if (stage) stage.classList.toggle('has-remote-video', chamadaAtual.mode === 'video');
    setCallText('call-status', 'Conectado');
  };
  pc.onconnectionstatechange = () => {
    if (!chamadaAtual || chamadaAtual.pc !== pc) return;
    if (pc.connectionState === 'connected') setCallText('call-status', 'Conectado');
    else if (pc.connectionState === 'connecting') setCallText('call-status', 'Conectando…');
    else if (pc.connectionState === 'failed') { setCallText('call-status', 'Falha na conexão'); mostrarAviso('A conexão direta falhou. Configure um servidor TURN para redes restritivas.'); }
    else if (pc.connectionState === 'disconnected') setCallText('call-status', 'Reconectando…');
  };
  atualizarPreviewLocal();
  return pc;
}

async function processarIcePendente() {
  if (!chamadaAtual || !chamadaAtual.pc || !chamadaAtual.pc.remoteDescription) return;
  const pendentes = chamadaAtual.pendingIce.splice(0);
  for (const candidate of pendentes) { try { await chamadaAtual.pc.addIceCandidate(new RTCIceCandidate(candidate)); } catch (_) {} }
}
function atualizarPreviewLocal() {
  if (!chamadaAtual || !chamadaAtual.localStream) return;
  const local = document.getElementById('call-local-video');
  if (local) { local.srcObject = chamadaAtual.localStream; local.style.display = chamadaAtual.mode === 'video' ? 'block' : 'none'; local.play().catch(() => {}); }
  const audioVisual = document.getElementById('call-audio-visual'); if (audioVisual) audioVisual.style.display = 'flex';
  const camBtn = document.getElementById('call-camera-btn'); if (camBtn) camBtn.style.display = chamadaAtual.mode === 'video' ? '' : 'none';
  const flipBtn = document.getElementById('call-flip-btn'); if (flipBtn) flipBtn.style.display = chamadaAtual.mode === 'video' ? '' : 'none';
}
function alternarSilencioChamada() {
  if (!chamadaAtual || !chamadaAtual.localStream) return;
  chamadaAtual.muted = !chamadaAtual.muted;
  chamadaAtual.localStream.getAudioTracks().forEach(track => { track.enabled = !chamadaAtual.muted; });
  const btn = document.getElementById('call-mute-btn'); if (btn) { btn.classList.toggle('is-off', chamadaAtual.muted); const icon = btn.querySelector('.mdi'); if (icon) icon.className = `mdi ${chamadaAtual.muted ? 'mdi-microphone-off' : 'mdi-microphone'}`; const span = btn.querySelector('span'); if (span) span.textContent = chamadaAtual.muted ? 'Microfone mudo' : 'Microfone'; }
}
function alternarCameraChamada() {
  if (!chamadaAtual || chamadaAtual.mode !== 'video' || !chamadaAtual.localStream) return;
  chamadaAtual.cameraOff = !chamadaAtual.cameraOff;
  chamadaAtual.localStream.getVideoTracks().forEach(track => { track.enabled = !chamadaAtual.cameraOff; });
  const btn = document.getElementById('call-camera-btn'); if (btn) { btn.classList.toggle('is-off', chamadaAtual.cameraOff); const icon = btn.querySelector('.mdi'); if (icon) icon.className = `mdi ${chamadaAtual.cameraOff ? 'mdi-video-off' : 'mdi-video'}`; const span = btn.querySelector('span'); if (span) span.textContent = chamadaAtual.cameraOff ? 'Câmera desligada' : 'Câmera'; }
}
async function alternarCameraFrontalTraseira() {
  if (!chamadaAtual || chamadaAtual.mode !== 'video' || !chamadaAtual.localStream || !navigator.mediaDevices?.getUserMedia) return;
  const facing = chamadaAtual.cameraFacing === 'user' ? 'environment' : 'user';
  try {
    const novoStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
    const novaTrack = novoStream.getVideoTracks()[0];
    if (!novaTrack) throw new Error('Câmera indisponível');
    novaTrack.enabled = !chamadaAtual.cameraOff;
    const antigaTrack = chamadaAtual.localStream.getVideoTracks()[0];
    if (chamadaAtual.pc) {
      const sender = chamadaAtual.pc.getSenders().find(item => item.track && item.track.kind === 'video');
      if (sender) await sender.replaceTrack(novaTrack);
      else chamadaAtual.pc.addTrack(novaTrack, chamadaAtual.localStream);
    }
    if (antigaTrack) { chamadaAtual.localStream.removeTrack(antigaTrack); antigaTrack.stop(); }
    chamadaAtual.localStream.addTrack(novaTrack); chamadaAtual.cameraFacing = facing;
    atualizarPreviewLocal();
  } catch (_) { mostrarAviso('Não foi possível alternar para a outra câmera.'); }
}

function alternarAudioChamada() {
  if (!chamadaAtual) return;
  chamadaAtual.speakerOff = !chamadaAtual.speakerOff;
  const audio = document.getElementById('call-remote-audio'); if (audio) audio.muted = chamadaAtual.mode === 'audio' ? chamadaAtual.speakerOff : true;
  const video = document.getElementById('call-remote-video'); if (video) video.muted = chamadaAtual.mode === 'video' ? chamadaAtual.speakerOff : true;
  const btn = document.getElementById('call-speaker-btn'); if (btn) { btn.classList.toggle('is-off', chamadaAtual.speakerOff); const icon = btn.querySelector('.mdi'); if (icon) icon.className = `mdi ${chamadaAtual.speakerOff ? 'mdi-volume-off' : 'mdi-volume-high'}`; }
}
function iniciarCronometroChamada() {
  clearInterval(chamadaDuracaoTimer); chamadaInicioAt = Date.now();
  const atualizar = () => { if (!chamadaAtual) return; const total = Math.floor((Date.now() - chamadaInicioAt) / 1000); const mm = String(Math.floor(total / 60)).padStart(2, '0'); const ss = String(total % 60).padStart(2, '0'); setCallText('call-status', `${mm}:${ss}`); setCallText('call-mini-time', `${mm}:${ss}`); };
  atualizar(); chamadaDuracaoTimer = setInterval(atualizar, 1000);
}
function limparChamadaLocal(notificar) {
  clearInterval(chamadaDuracaoTimer); chamadaDuracaoTimer = null;
  const atual = chamadaAtual; chamadaAtual = null;
  if (atual && atual.pc) { try { atual.pc.onicecandidate = null; atual.pc.ontrack = null; atual.pc.close(); } catch (_) {} }
  if (atual && atual.localStream) atual.localStream.getTracks().forEach(track => { try { track.stop(); } catch (_) {} });
  ['call-local-video','call-remote-video','call-remote-audio'].forEach(id => { const el = document.getElementById(id); if (el) { try { el.pause(); } catch (_) {} el.srcObject = null; el.muted = id === 'call-local-video'; } });
  const stage = document.getElementById('call-stage'); if (stage) stage.classList.remove('has-remote-video');
  esconderCallOverlay();
  const pill = document.getElementById('call-mini-pill'); if (pill) pill.hidden = true;
  const mute = document.getElementById('call-mute-btn'); if (mute) { mute.classList.remove('is-off'); mute.innerHTML = '<i class="mdi mdi-microphone"></i><span>Microfone</span>'; }
  const cam = document.getElementById('call-camera-btn'); if (cam) { cam.classList.remove('is-off'); cam.innerHTML = '<i class="mdi mdi-video"></i><span>Câmera</span>'; }
  const flip = document.getElementById('call-flip-btn'); if (flip) { flip.classList.remove('is-off'); flip.innerHTML = '<i class="mdi mdi-camera-flip-outline"></i><span>Virar</span>'; }
  const speaker = document.getElementById('call-speaker-btn'); if (speaker) { speaker.classList.remove('is-off'); speaker.innerHTML = '<i class="mdi mdi-volume-high"></i><span>Áudio</span>'; }
}
