require('dotenv').config();

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
// FCM é opcional no desenvolvimento e obrigatório apenas no servidor publicado.
// A credencial nunca é enviada ao APK: use FIREBASE_SERVICE_ACCOUNT_JSON ou
// GOOGLE_APPLICATION_CREDENTIALS no ambiente do backend.
let firebaseAdmin = null;
try { firebaseAdmin = require('firebase-admin'); } catch (_) { /* npm install ainda não executado */ }
let fcmApp = null;
let fcmLastError = null;
let fcmProjectId = null;

function normalizarChavePrivadaFirebase(value) {
  return String(value || '')
    .trim()
    .replace(/^(['"])([\s\S]*)\1$/, '$2')
    .replace(/\\n/g, '\n')
    .replace(/\\r/g, '\r')
    .replace(/\r\n/g, '\n')
    .trim();
}

function lerCredencialFirebase() {
  const raw = String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim();
  let serviceAccount = null;
  if (raw) {
    const json = raw.replace(/^(['"])([\s\S]*)\1$/, '$2');
    try {
      serviceAccount = JSON.parse(json);
    } catch (e) {
      try {
        serviceAccount = JSON.parse(json.replace(/\\"/g, '"'));
      } catch (_) {
        throw new Error('FIREBASE_SERVICE_ACCOUNT_JSON não é um JSON válido. Use uma única linha e mantenha \\n dentro de private_key.');
      }
    }
  } else if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    try {
      const file = fs.readFileSync(process.env.GOOGLE_APPLICATION_CREDENTIALS, 'utf8');
      serviceAccount = JSON.parse(file);
    } catch (e) {
      throw new Error(`não foi possível ler GOOGLE_APPLICATION_CREDENTIALS: ${e.message}`);
    }
  } else if (process.env.FIREBASE_SERVICE_ACCOUNT_BASE64) {
    try {
      serviceAccount = JSON.parse(Buffer.from(process.env.FIREBASE_SERVICE_ACCOUNT_BASE64, 'base64').toString('utf8'));
    } catch (_) {
      throw new Error('FIREBASE_SERVICE_ACCOUNT_BASE64 não pôde ser decodificado como JSON.');
    }
  } else if (process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_CLIENT_EMAIL) {
    serviceAccount = {
      project_id: process.env.FIREBASE_PROJECT_ID || process.env.GCLOUD_PROJECT,
      client_email: process.env.FIREBASE_CLIENT_EMAIL,
      private_key: process.env.FIREBASE_PRIVATE_KEY
    };
  }
  if (!serviceAccount) return null;
  serviceAccount.private_key = normalizarChavePrivadaFirebase(serviceAccount.private_key);
  if (!/^-----BEGIN PRIVATE KEY-----\n[\s\S]+\n-----END PRIVATE KEY-----$/.test(serviceAccount.private_key)) {
    throw new Error('private_key do Firebase não contém PEM válido; converta \\n literal para quebra de linha.');
  }
  return serviceAccount;
}

function fcmMessaging() {
  if (!firebaseAdmin) return null;
  if (!fcmApp) {
    try {
      const serviceAccount = lerCredencialFirebase();
      fcmProjectId = serviceAccount?.project_id || process.env.GCLOUD_PROJECT || null;
      const credential = serviceAccount
        ? firebaseAdmin.credential.cert(serviceAccount)
        : firebaseAdmin.credential.applicationDefault();
      fcmApp = firebaseAdmin.apps.length ? firebaseAdmin.app() : firebaseAdmin.initializeApp({ credential });
      fcmLastError = null;
    } catch (e) {
      fcmLastError = e.message;
      console.warn('[FCM] push desativado:', e.message);
      return null;
    }
  }
  return firebaseAdmin.messaging(fcmApp);
}

function logarStatusInicialFcm() {
  const temJson = Boolean(String(process.env.FIREBASE_SERVICE_ACCOUNT_JSON || '').trim());
  const temBase64 = Boolean(String(process.env.FIREBASE_SERVICE_ACCOUNT_BASE64 || '').trim());
  const temSeparadas = Boolean(process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PRIVATE_KEY);
  const temArquivo = Boolean(process.env.GOOGLE_APPLICATION_CREDENTIALS);
  console.log(`[FCM] variáveis: JSON=${temJson ? 'carregado' : 'ausente'} BASE64=${temBase64 ? 'carregado' : 'ausente'} SEPARADAS=${temSeparadas ? 'carregadas' : 'ausentes'} ARQUIVO=${temArquivo ? 'definido' : 'ausente'}`);
  if (!firebaseAdmin) {
    console.error('[FCM] firebase-admin não está instalado; execute npm install antes de iniciar.');
    return;
  }
  try {
    const messaging = fcmMessaging();
    if (messaging) {
      const app = firebaseAdmin.app();
      console.log(`[FCM] Firebase Admin pronto: projeto=${app.options.projectId || fcmProjectId || 'não informado'}.`);
    } else {
      console.error(`[FCM] credencial não carregada: ${fcmLastError || 'nenhuma credencial compatível encontrada.'}`);
    }
  } catch (e) {
    fcmLastError = e.message;
    console.error('[FCM] erro inesperado ao inicializar Firebase:', e.message);
  }
}

async function enviarPushParaUsuario(db, userId, notification, data = {}) {
  const messaging = fcmMessaging();
  if (!messaging) return;
  const u = db.users.find(x => String(x.id) === String(userId));
  const tokens = Array.isArray(u?.pushTokens) ? [...new Set(u.pushTokens)].filter(Boolean) : [];
  if (!tokens.length) return;
  const notificationTitle = String(data.senderName || data.callerName || notification?.title || (data.type === 'call' ? 'Ligação recebida' : 'Nova mensagem'));
  const notificationBody = String(data.messagePreview || data.callText || notification?.body || (data.type === 'call' ? 'Alguém está ligando' : 'Nova mensagem recebida'));
  const payload = {
    tokens,
    // Data-only é intencional: quando existe notification, o Android exibe a
    // notificação automaticamente em segundo plano e não executa nosso
    // FirebaseMessagingService — portanto desaparecem Responder/Atender/Desligar.
    data: Object.fromEntries(Object.entries({ ...data, notificationTitle, notificationBody, title: notificationTitle, body: notificationBody }).map(([k,v]) => [k, String(v ?? '')])),
    // Não incluir android.notification: isso transforma o payload em notificação automática
    // e impede o FirebaseMessagingService de cancelar a chamada no encerramento.
    android: { priority: 'high' }
  };
  try {
    const result = await messaging.sendEachForMulticast(payload);
    const inválidos = [];
    result.responses.forEach((r, i) => {
      const code = r.error?.code || '';
      if (code.includes('registration-token-not-registered') || code.includes('invalid-registration-token')) inválidos.push(tokens[i]);
    });
    if (inválidos.length && Array.isArray(u.pushTokens)) {
      u.pushTokens = u.pushTokens.filter(t => !inválidos.includes(t));
      saveDB(db);
    }
  } catch (e) { console.error('[FCM] falha ao enviar push:', e.message); }
}
function enviarPushFimDeChamada(db, userId, callId, reason = 'ended') {
  if (!userId || !callId) return;
  enviarPushParaUsuario(db, userId, {}, { type: 'call_ended', callId: String(callId), reason });
}
const { init, loadDB, saveDB } = require('./db');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const MAX_CONTAS_POR_IP = 3;
const LIMITE_EDICAO_MS = 60 * 1000; // 1 minuto
const VIDA_MIDIA_MS = 12 * 60 * 60 * 1000; // 12 horas
const TEMPOS_MENSAGEM_MS = { '1h': 60 * 60 * 1000, '8h': 8 * 60 * 60 * 1000, '24h': 24 * 60 * 60 * 1000, '7d': 7 * 24 * 60 * 60 * 1000 };

function limparMensagensExpiradas(db) {
  const agora = Date.now();
  const expiradas = (db.messages || []).filter(m => m.expiresAt && m.expiresAt <= agora);
  if (!expiradas.length) return false;
  expiradas.forEach(m => { if (m.mediaUrl) apagarArquivo(m.mediaUrl); });
  db.messages = db.messages.filter(m => !(m.expiresAt && m.expiresAt <= agora));
  return true;
}

app.use(express.json());

// ---------- Tokens FCM do aplicativo Android ----------
app.post('/api/push-token', (req, res) => {
  const { userId, token } = req.body || {};
  if (!userId || typeof token !== 'string' || token.length < 20 || token.length > 4096) return res.status(400).json({ error: 'Token inválido.' });
  const db = loadDB();
  const user = db.users.find(u => String(u.id) === String(userId));
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado.' });
  user.pushTokens = Array.isArray(user.pushTokens) ? user.pushTokens.filter(Boolean) : [];
  if (!user.pushTokens.includes(token)) user.pushTokens.push(token);
  user.pushTokens = user.pushTokens.slice(-5);
  saveDB(db);
  res.json({ ok: true });
});
app.delete('/api/push-token', (req, res) => {
  const { userId, token } = req.body || {};
  const db = loadDB();
  const user = db.users.find(u => String(u.id) === String(userId));
  if (user && Array.isArray(user.pushTokens)) { user.pushTokens = user.pushTokens.filter(t => t !== token); saveDB(db); }
  res.json({ ok: true });
});
app.get('/api/push-status', (req, res) => {
  const userId = String(req.query.userId || '');
  const db = loadDB();
  const user = db.users.find(u => String(u.id) === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado.' });
  res.json({ ok: true, firebaseConfigured: !!fcmMessaging(), fcmError: fcmLastError || null, tokenCount: Array.isArray(user.pushTokens) ? user.pushTokens.length : 0 });
});

// ---------- Painel admin (arquivo estático protegido) ----------
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});
app.use(express.static(path.join(__dirname, 'public')));
// ---------- Upload de mídia (áudio/vídeo/imagem) ----------
// Os arquivos ficam no MongoDB (GridFS), NÃO no disco. No Railway o disco é apagado a cada
// deploy/reinício — por isso as fotos davam 404. No banco elas sobrevivem a tudo.
const mongoose = require('mongoose');
let bucket = null;
function getBucket() {
  if (!bucket) bucket = new mongoose.mongo.GridFSBucket(mongoose.connection.db, { bucketName: 'midia' });
  return bucket;
}
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 } // 25MB
});

app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file || !req.file.buffer || !req.file.size) {
    return res.status(400).json({ error: 'O arquivo não foi recebido corretamente.' });
  }
  const extension = (path.extname(req.file.originalname || '') || '').toLowerCase();
  const filename = uuidv4() + extension;
  // Alguns seletores Android informam GIF como tipo genérico; a extensão
  // permite preservar image/gif e manter a animação ao servir o avatar.
  const mimeType = extension === '.gif' ? 'image/gif' : (req.file.mimetype || 'application/octet-stream');
  const stream = getBucket().openUploadStream(filename, { metadata: { mimeType } });
  stream.on('error', e => {
    console.error('[upload] erro ao salvar:', e.message);
    res.status(500).json({ error: 'Não foi possível salvar o arquivo.' });
  });
  stream.on('finish', () => {
    res.status(201).json({
      url: '/uploads/' + filename,
      filename,
      size: req.file.size,
      mimeType
    });
  });
  stream.end(req.file.buffer);
});

// serve o arquivo (com suporte a Range, que o Safari/iPhone exige pra tocar áudio e vídeo)
app.get('/uploads/:filename', async (req, res) => {
  try {
    const arquivos = await getBucket().find({ filename: req.params.filename }).limit(1).toArray();
    if (!arquivos.length) return res.status(404).end();
    const f = arquivos[0];
    const total = f.length;
    const tipo = (f.metadata && f.metadata.mimeType) || 'application/octet-stream';
    res.set({ 'Content-Type': tipo, 'Accept-Ranges': 'bytes', 'Cache-Control': 'public, max-age=86400' });

    const range = req.headers.range && /bytes=(\d*)-(\d*)/.exec(req.headers.range);
    if (range && total > 0) {
      let ini = range[1] === '' ? total - parseInt(range[2], 10) : parseInt(range[1], 10);
      let fim = range[1] === '' || range[2] === '' ? total - 1 : parseInt(range[2], 10);
      if (isNaN(ini) || isNaN(fim) || ini < 0) ini = 0;
      if (fim >= total) fim = total - 1;
      if (ini > fim) return res.status(416).set('Content-Range', `bytes */${total}`).end();
      res.status(206).set({ 'Content-Range': `bytes ${ini}-${fim}/${total}`, 'Content-Length': fim - ini + 1 });
      return getBucket().openDownloadStream(f._id, { start: ini, end: fim + 1 }).pipe(res);
    }
    res.set('Content-Length', total);
    getBucket().openDownloadStream(f._id).on('error', () => res.end()).pipe(res);
  } catch (e) {
    console.error('[uploads] erro:', e.message);
    res.status(500).end();
  }
});

// apaga um arquivo de mídia a partir da URL ('/uploads/xxx.jpg')
function apagarArquivo(mediaUrl) {
  if (!mediaUrl || typeof mediaUrl !== 'string' || !mediaUrl.startsWith('/uploads/')) return;
  const nome = mediaUrl.slice('/uploads/'.length);
  getBucket().find({ filename: nome }).toArray()
    .then(fs_ => Promise.all(fs_.map(f => getBucket().delete(f._id))))
    .catch(() => {});
}

// ---------- Helpers ----------
function getClientIp(req) {
  const fwd = req.headers['x-forwarded-for'];
  if (fwd) return fwd.split(',')[0].trim();
  return req.socket.remoteAddress;
}

function publicUser(u) {
  return {
    id: u.id, username: u.username, email: u.email, contactNumber: u.contactNumber || null, photoUrl: u.photoUrl || null,
    bio: u.bio || '', phone: u.phone || '', ringColor: u.ringColor || '#c7f36b',
    age: u.age || '', sexuality: u.sexuality || '', city: u.city || '', state: u.state || '', relationshipStatus: u.relationshipStatus || '', bannerUrl: u.bannerUrl || '',
    socials: Array.isArray(u.socials) ? u.socials : []
  };
}

const SOCIALS_PERMITIDAS = new Set(['instagram', 'tiktok', 'youtube', 'facebook', 'x']);
function normalizarSocials(socials) {
  if (!Array.isArray(socials)) return [];
  return socials.slice(0, 5).map(item => {
    const network = String(item && item.network || '').toLowerCase();
    const handle = String(item && item.handle || '').trim().replace(/^@+/, '').slice(0, 100);
    if (!SOCIALS_PERMITIDAS.has(network) || !handle) return null;
    return { network, handle };
  }).filter(Boolean);
}

function findUserByEmailOrUsername(db, query) {
  const q = query.trim().toLowerCase();
  return db.users.find(
    u => u.email.toLowerCase() === q || u.username.toLowerCase() === q
  );
}

// cria (sem salvar) uma mensagem de aviso do sistema, tipo "Fulano entrou no grupo"
// `content` é o texto padrão (usado como fallback, ex: no /api/stats ou se faltar metadado).
// `meta` é opcional: { kind: 'add_member' | 'promote' | 'remove_member', actorId, targetId }
// Guardando o meta em vez de só o texto, dá pra remontar a frase certa pra cada pessoa
// que olha a mensagem (ex: "você" no lugar do próprio nome), sem precisar de outra tabela.
function criarMensagemSistema(chatId, content, meta) {
  return {
    id: uuidv4(),
    chatId,
    senderId: null,
    type: 'system',
    content,
    systemMeta: meta || null,
    mediaUrl: null,
    mediaCreatedAt: null,
    replyTo: null,
    createdAt: Date.now(),
    editedAt: null,
    deleted: false
  };
}

// pega uma mensagem de sistema e devolve uma cópia com o `content` reescrito
// do ponto de vista de quem tá olhando (viewerId). Se não tiver systemMeta
// (mensagens antigas, criadas antes dessa mudança), devolve como já estava.
function personalizarMensagem(msg, viewerId, db) {
  if (msg.type !== 'system' || !msg.systemMeta) return msg;
  const { kind, actorId, targetId } = msg.systemMeta;
  const ator = db.users.find(u => u.id === actorId);
  const alvo = db.users.find(u => u.id === targetId);
  const atorNome = ator ? ator.username : 'Alguém';
  const alvoNome = alvo ? alvo.username : 'Alguém';

  let content = msg.content;
  if (kind === 'add_member') {
    if (viewerId === actorId) content = `Você adicionou ${alvoNome} ao grupo`;
    else if (viewerId === targetId) content = `${atorNome} adicionou você ao grupo`;
    else content = `${alvoNome} foi adicionado ao grupo`;
  } else if (kind === 'promote') {
    content = viewerId === targetId
      ? 'Você agora é um admin do grupo'
      : `${alvoNome} agora é admin do grupo`;
  } else if (kind === 'remove_member') {
    content = viewerId === targetId
      ? 'Você foi removido do grupo'
      : `${alvoNome} foi removido do grupo`;
  } else if (kind === 'join_link') {
    content = viewerId === targetId
      ? 'Você entrou no grupo pelo link de convite'
      : `${alvoNome} entrou no grupo pelo link de convite`;
  } else if (kind === 'rename') {
    content = viewerId === actorId
      ? `Você mudou o nome do grupo para "${msg.systemMeta.novoNome}"`
      : `${atorNome} mudou o nome do grupo para "${msg.systemMeta.novoNome}"`;
  } else if (kind === 'description') {
    content = viewerId === actorId
      ? 'Você mudou a descrição do grupo'
      : `${atorNome} mudou a descrição do grupo`;
  } else if (kind === 'photo') {
    const acao = msg.systemMeta.removida ? 'removeu' : 'mudou';
    content = viewerId === actorId ? `Você ${acao} a foto do grupo` : `${atorNome} ${acao} a foto do grupo`;
  } else if (kind === 'modo_envio') {
    const modo = msg.systemMeta.modo;
    const textos = {
      todos: viewerId === actorId
        ? 'Você abriu o grupo: agora todo mundo pode mandar mensagem'
        : `${atorNome} abriu o grupo: agora todo mundo pode mandar mensagem`,
      admins: viewerId === actorId
        ? 'Você fechou o grupo: agora só admins podem mandar mensagem'
        : `${atorNome} fechou o grupo: agora só admins podem mandar mensagem`,
      dono: viewerId === actorId
        ? 'Você restringiu o grupo: agora só você pode mandar mensagem'
        : `${atorNome} restringiu o grupo: agora só o dono pode mandar mensagem`
    };
    content = textos[modo] || msg.content;
  }
  return Object.assign({}, msg, { content });
}

// manda uma mensagem já personalizada pra cada membro do grupo, individualmente,
// em vez de uma frase igual pra sala toda (usa a room 'user:<id>', que já existe
// desde o evento 'join' do socket — não depende de quem já abriu o chat ou não).
function emitirMensagemSistemaPersonalizada(db, membros, msg) {
  membros.forEach(memberId => {
    const personalizada = personalizarMensagem(msg, memberId, db);
    io.to('user:' + memberId).emit('new_message', personalizada);
  });
}

// dono ATUAL do grupo. createdBy continua sendo só "quem criou" (aparece na descrição).
// Quando o dono sai, ownerId vira null; se ele voltar depois, volta como membro comum.
function donoDe(chat) {
  return chat.ownerId !== undefined ? chat.ownerId : chat.createdBy;
}
function souDono(chat, userId) {
  return !!userId && donoDe(chat) === userId;
}
function souAdminDoGrupo(chat, userId) {
  return souDono(chat, userId) || (chat.admins || []).includes(userId);
}

// modo de envio do grupo: 'todos' (padrão) | 'admins' (só dono/admins) | 'dono' (só o dono, nem admins)
function podeEnviarMensagem(chat, userId) {
  if (chat.type !== 'group') return true;
  const modo = chat.modoEnvio || 'todos';
  if (modo === 'dono') return souDono(chat, userId);
  if (modo === 'admins') return souAdminDoGrupo(chat, userId);
  return true;
}

// registra o momento em que alguém entrou num grupo (usado pra esconder mensagens antigas de quem entrou depois)
// e garante que, se a pessoa tinha saído/sido removida antes, ela some da lista de "Saíram"
function marcarEntradaNoGrupo(chat, userId, timestamp) {
  if (!chat.memberJoinedAt) chat.memberJoinedAt = {};
  chat.memberJoinedAt[userId] = timestamp || Date.now();
  if (chat.removedMembers) chat.removedMembers = chat.removedMembers.filter(r => r.userId !== userId);
}

// ---------- Privacidade da foto de perfil ----------
// contato "de verdade" é uma escolha explícita: alguém apertou "Salvar contato" pra essa pessoa.
// É direcional — eu ter te salvo não faz com que eu tenha te dado permissão de ver a MINHA foto,
// o que importa pra privacidade é se o DONO da foto salvou quem está olhando.
function ehContatoSalvo(db, ownerId, contactId) {
  if (ownerId === contactId) return true;
  return db.contacts.some(c => c.ownerId === ownerId && c.contactId === contactId);
}

// decide se `viewerId` pode enxergar a foto de `ownerUser`, de acordo com a
// preferência de privacidade que o dono da foto escolheu
function fotoVisivelPara(db, ownerUser, viewerId) {
  if (!ownerUser) return false;
  if (!viewerId || viewerId === ownerUser.id) return true; // você sempre vê a sua própria foto
  const privacidade = ownerUser.photoPrivacy || 'todos';
  if (privacidade === 'todos') return true;
  if (privacidade === 'ninguem') return false;
  if (privacidade === 'contatos') return ehContatoSalvo(db, ownerUser.id, viewerId);
  if (privacidade === 'lista') return (ownerUser.photoAllowList || []).includes(viewerId);
  return true;
}

// devolve a URL da foto de `ownerUser`, já filtrada pro ponto de vista de `viewerId`
// (null se a privacidade escolhida não deixar esse viewer enxergar)
function fotoParaViewer(db, ownerUser, viewerId) {
  if (!ownerUser) return null;
  return fotoVisivelPara(db, ownerUser, viewerId) ? (ownerUser.photoUrl || null) : null;
}

// ---------- Autenticação: email verificado + Google ----------
function novoNumeroContato(db) {
  let n;
  do { n = String(Math.floor(1000000 + Math.random() * 9000000)); }
  while (db.users.some(u => u.contactNumber === n) || Object.values(db.pendingVerifications || {}).some(u => u.contactNumber === n));
  return n;
}
function codigoHash(email, code) { return crypto.createHash('sha256').update(`${email.toLowerCase()}:${code}:${process.env.AUTH_CODE_SECRET || 'configure-um-segredo-no-railway'}`).digest('hex'); }
async function enviarEmailVerificacao(email, code, token, req) {
  if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM) throw new Error('Email não configurado. Configure RESEND_API_KEY e EMAIL_FROM no Railway.');
  const base = (process.env.APP_URL || `${req.protocol}://${req.get('host')}`).replace(/\/$/, '');
  const link = `${base}/api/verify-email?token=${encodeURIComponent(token)}`;
  const html = `<!doctype html><html><head><style>@keyframes cdPulse{0%,100%{transform:scale(1);box-shadow:0 0 0 rgba(199,243,107,0)}50%{transform:scale(1.025);box-shadow:0 0 24px rgba(199,243,107,.16)}}.cd-pulse{animation:cdPulse 2.8s ease-in-out infinite}</style></head><body style="margin:0;background:#0b0d12;color:#f5f6f8;font-family:Arial,sans-serif;padding:28px 12px"><div style="max-width:560px;margin:auto;background:linear-gradient(145deg,#171b24,#101218);border:1px solid #2b303b;border-radius:24px;overflow:hidden"><div style="height:5px;background:linear-gradient(90deg,#c7f36b,#72e4bd,#a6a1ff)"></div><div style="padding:34px 30px"><div style="font-size:13px;letter-spacing:3px;color:#c7f36b;font-weight:bold">✳ CHATDEVS</div><h1 style="font-size:30px;line-height:1.15;margin:24px 0 12px">Só falta confirmar<br>seu email<span style="color:#c7f36b">.</span></h1><p style="color:#b7bdc9;line-height:1.7">Use o código abaixo para ativar sua conta. Ele expira em 15 minutos.</p><div class="cd-pulse" style="letter-spacing:12px;font-size:34px;font-weight:800;background:#0b0d12;border:1px solid #343b47;border-radius:16px;padding:22px 10px;text-align:center;margin:24px 0;color:#c7f36b">${code}</div><p style="text-align:center;color:#aeb5c3;font-size:13px">Ou confirme com um toque:</p><div style="text-align:center;margin:20px 0 28px"><a href="${link}" style="display:inline-block;background:#c7f36b;color:#11150b;text-decoration:none;font-weight:800;padding:16px 24px;border-radius:12px">Verificar meu email →</a></div><div style="border-top:1px solid #2b303b;padding-top:18px;color:#818a9b;font-size:12px;line-height:1.6">Se você não criou uma conta no ChatDevs, ignore esta mensagem. Não compartilhe este código com ninguém.</div></div></div></body></html>`;
  const response = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: process.env.EMAIL_FROM, to: [email], subject: 'Seu código de verificação — ChatDevs', html, text: `Seu código ChatDevs é ${code}. Expira em 15 minutos. Verifique também por este link: ${link}` }) });
  if (!response.ok) { const detail = await response.text(); console.error('[email] Resend:', detail); throw new Error('Não foi possível enviar o email. Confira o domínio e as credenciais de email.'); }
}
function finalizarCadastroPendente(db, pending) {
  // Contas existentes são atualizadas no lugar; nenhuma conta é duplicada.
  let user = pending.existingUserId ? db.users.find(u => u.id === pending.existingUserId) : null;
  if (user) {
    user.emailVerified = true;
    user.emailCodeVerified = true;
    if (pending.authProvider === 'google') user.googleEmailCodeVerified = true;
    user.contactNumber = user.contactNumber || pending.contactNumber || novoNumeroContato(db);
    user.photoUrl = user.photoUrl || pending.photoUrl || null;
    user.authProvider = user.authProvider || pending.authProvider || 'email';
  } else {
    user = {
      id: uuidv4(), username: pending.username, email: pending.email,
      passwordHash: pending.passwordHash || null,
      contactNumber: pending.contactNumber || novoNumeroContato(db),
      createdIp: pending.createdIp || '', createdAt: Date.now(),
      emailVerified: true, emailCodeVerified: true,
      authProvider: pending.authProvider || 'email',
      photoUrl: pending.photoUrl || null,
      ...(pending.authProvider === 'google' ? { googleEmailCodeVerified: true } : {})
    };
    db.users.push(user);
  }
  delete db.pendingVerifications[pending.email.toLowerCase()];
  saveDB(db);
  return user;
}
app.get('/api/auth-config', (req, res) => res.json({ googleClientId: process.env.GOOGLE_CLIENT_ID || '' }));
app.post('/api/register', async (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (username.length < 3 || username.length > 24 || !/^[\p{L}\p{N}_.-]+$/u.test(username)) return res.status(400).json({ error: 'Use um nome de usuário de 3 a 24 caracteres (letras, números, ponto, hífen ou _).' });
    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Informe um email válido.' });
    if (password.length < 8) return res.status(400).json({ error: 'A senha precisa ter pelo menos 8 caracteres.' });
    const db = loadDB();
    if (db.users.some(u => u.email.toLowerCase() === email || u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Email ou usuário já cadastrado.' });
    const ip = getClientIp(req); const contasNesseIp = db.ipCounts[ip] || 0;
    if (contasNesseIp >= MAX_CONTAS_POR_IP) return res.status(403).json({ error: 'Limite de 3 contas por IP atingido.' });
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0'); const token = crypto.randomBytes(32).toString('hex');
    const pending = { username, email, passwordHash: await bcrypt.hash(password, 12), createdIp: ip, contactNumber: novoNumeroContato(db), codeHash: codigoHash(email, code), tokenHash: crypto.createHash('sha256').update(token).digest('hex'), expiresAt: Date.now() + 15 * 60 * 1000, authProvider: 'email' };
    db.pendingVerifications[email] = pending; saveDB(db);
    try { await enviarEmailVerificacao(email, code, token, req); } catch (e) { delete db.pendingVerifications[email]; saveDB(db); return res.status(503).json({ error: e.message }); }
    res.json({ verificationRequired: true, email });
  } catch (e) { console.error('[register]', e); res.status(500).json({ error: 'Não foi possível iniciar o cadastro agora.' }); }
});
app.post('/api/verify-email-code', (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase(); const code = String(req.body.code || '').trim(); const db = loadDB(); const pending = db.pendingVerifications[email];
  if (!pending || pending.expiresAt < Date.now()) { if (pending) { delete db.pendingVerifications[email]; saveDB(db); } return res.status(400).json({ error: 'Código expirado. Faça o cadastro novamente.' }); }
  if (!/^\d{6}$/.test(code) || codigoHash(email, code) !== pending.codeHash) return res.status(400).json({ error: 'Código incorreto. Confira os seis dígitos e tente novamente.' });
  if (!pending.existingUserId) { const ip = pending.createdIp; db.ipCounts[ip] = (db.ipCounts[ip] || 0) + 1; } const user = finalizarCadastroPendente(db, pending); res.json({ user: publicUser(user) });
});
app.get('/api/verify-email', (req, res) => {
  const token = String(req.query.token || ''); const tokenHash = crypto.createHash('sha256').update(token).digest('hex'); const db = loadDB();
  const entry = Object.entries(db.pendingVerifications || {}).find(([, p]) => p.tokenHash === tokenHash);
  if (!entry || entry[1].expiresAt < Date.now()) return res.status(400).send('<meta name="viewport" content="width=device-width"><body style="font-family:Arial;background:#101218;color:white;padding:40px;text-align:center"><h1>Link expirado</h1><p>Volte ao ChatDevs e faça o cadastro novamente.</p></body>');
  const [email, pending] = entry; if (!pending.existingUserId) db.ipCounts[pending.createdIp] = (db.ipCounts[pending.createdIp] || 0) + 1; finalizarCadastroPendente(db, pending);
  res.send(`<!doctype html><meta name="viewport" content="width=device-width"><title>Email verificado</title><body style="font-family:Arial;background:#101218;color:#f5f6f8;display:grid;place-items:center;min-height:90vh;text-align:center"><div style="padding:32px;border:1px solid #343b47;border-radius:24px;max-width:420px"><div style="font-size:48px;color:#c7f36b">✓</div><h1>Email verificado!</h1><p style="color:#b7bdc9">Sua conta ChatDevs está ativa. Volte ao aplicativo e entre com seu email e senha.</p><a style="display:inline-block;background:#c7f36b;color:#111;text-decoration:none;padding:14px 22px;border-radius:12px;font-weight:bold" href="/">Voltar ao ChatDevs</a></div></body>`);
});
app.post('/api/google-login', async (req, res) => {
  try {
    if (!process.env.GOOGLE_CLIENT_ID) return res.status(503).json({ error: 'Login Google ainda não foi configurado pelo administrador.' });
    const credential = String(req.body.credential || '');
    if (!credential) return res.status(400).json({ error: 'Credencial Google ausente.' });
    const verify = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
    const payload = await verify.json();
    if (!verify.ok || payload.aud !== process.env.GOOGLE_CLIENT_ID || payload.email_verified !== 'true' || !payload.email) return res.status(401).json({ error: 'Não foi possível validar sua conta Google.' });

    const db = loadDB();
    if (!db.pendingVerifications) db.pendingVerifications = {};
    const email = String(payload.email).toLowerCase();
    let user = db.users.find(u => u.email.toLowerCase() === email);
    if (user && user.bloqueadoAdmin) return res.status(403).json({ error: 'Sua conta foi suspensa. Entre em contato com o suporte.' });

    // Todas as contas, inclusive as antigas, precisam concluir a verificação por código uma vez.
    if (user && user.emailCodeVerified === true) {
      user.contactNumber = user.contactNumber || novoNumeroContato(db);
      user.emailVerified = true;
      user.photoUrl = user.photoUrl || payload.picture || null;
      saveDB(db);
      return res.json({ user: publicUser(user) });
    }

    const ip = getClientIp(req);
    const usernameFromGoogle = String(payload.name || email.split('@')[0]).normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 20) || 'usuario';
    let username = user ? user.username : usernameFromGoogle;
    if (!user) {
      const base = username; let i = 1;
      while (db.users.some(u => u.username.toLowerCase() === username.toLowerCase()) || Object.values(db.pendingVerifications).some(p => (p.username || '').toLowerCase() === username.toLowerCase() && p.email !== email)) username = `${base.slice(0, 18)}${i++}`;
    }
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const token = crypto.randomBytes(32).toString('hex');
    const pending = {
      username, email, passwordHash: user ? user.passwordHash || null : null,
      createdIp: user ? (user.createdIp || ip) : ip,
      contactNumber: user?.contactNumber || novoNumeroContato(db),
      photoUrl: user?.photoUrl || payload.picture || null,
      existingUserId: user?.id || null,
      codeHash: codigoHash(email, code),
      tokenHash: crypto.createHash('sha256').update(token).digest('hex'),
      expiresAt: Date.now() + 15 * 60 * 1000, authProvider: 'google'
    };
    db.pendingVerifications[email] = pending;
    saveDB(db);
    try {
      await enviarEmailVerificacao(email, code, token, req);
    } catch (e) {
      delete db.pendingVerifications[email]; saveDB(db);
      console.error('[google-login-email]', e.message);
      return res.status(503).json({ error: 'O Google foi validado, mas não conseguimos enviar o código. Confira o Resend e tente novamente.' });
    }
    res.json({ verificationRequired: true, email });
  } catch (e) {
    console.error('[google-login]', e);
    res.status(500).json({ error: 'Falha ao entrar com Google. Tente novamente.' });
  }
});
app.post('/api/login', async (req, res) => {
  const { emailOrUsername, password } = req.body; const db = loadDB(); const user = findUserByEmailOrUsername(db, String(emailOrUsername || ''));
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  if (!user.passwordHash) return res.status(401).json({ error: 'Esta conta usa Google. Entre pelo botão Continuar com Google.' });
  const ok = await bcrypt.compare(String(password || ''), user.passwordHash);
  if (!ok) return res.status(401).json({ error: 'Senha incorreta' });
  if (user.bloqueadoAdmin) return res.status(403).json({ error: 'Sua conta foi suspensa. Entre em contato com o suporte.' });
  if (user.emailCodeVerified !== true) {
    try {
      if (!db.pendingVerifications) db.pendingVerifications = {};
      const email = String(user.email).toLowerCase();
      const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
      const token = crypto.randomBytes(32).toString('hex');
      const pending = {
        username: user.username, email, passwordHash: user.passwordHash || null,
        createdIp: user.createdIp || getClientIp(req), contactNumber: user.contactNumber || novoNumeroContato(db),
        photoUrl: user.photoUrl || null, existingUserId: user.id,
        codeHash: codigoHash(email, code),
        tokenHash: crypto.createHash('sha256').update(token).digest('hex'),
        expiresAt: Date.now() + 15 * 60 * 1000, authProvider: user.authProvider || 'email'
      };
      db.pendingVerifications[email] = pending;
      saveDB(db);
      await enviarEmailVerificacao(email, code, token, req);
      return res.json({ verificationRequired: true, email });
    } catch (e) {
      console.error('[login-email-verification]', e.message);
      return res.status(503).json({ error: 'Precisamos verificar seu email antes de entrar, mas não foi possível enviar o código. Confira o Resend e tente novamente.' });
    }
  }
  if (!user.emailVerified) return res.status(403).json({ error: 'Seu email ainda não foi verificado.' });
  res.json({ user: publicUser(user) });
});

app.post('/api/change-password', async (req, res) => {
  const userId = String(req.body.userId || '');
  const currentPassword = String(req.body.currentPassword || '');
  const newPassword = String(req.body.newPassword || '');
  if (!userId || !currentPassword || newPassword.length < 8) return res.status(400).json({ error: 'Informe a senha atual e uma nova senha com pelo menos 8 caracteres.' });
  const db = loadDB();
  const user = db.users.find(item => String(item.id) === userId);
  if (!user || !user.passwordHash) return res.status(400).json({ error: 'Esta conta não possui senha local. Use o login Google.' });
  if (!(await bcrypt.compare(currentPassword, user.passwordHash))) return res.status(401).json({ error: 'A senha atual está incorreta.' });
  user.passwordHash = await bcrypt.hash(newPassword, 12);
  saveDB(db);
  res.json({ message: 'Senha alterada com sucesso.' });
});

// Busca pública por número de contato de 7 dígitos.
app.get('/api/users/search', (req, res) => {
  const q = String(req.query.q || '').replace(/\D/g, '').trim(); if (!/^\d{7}$/.test(q)) return res.status(400).json({ error: 'Digite o número de contato com 7 dígitos.' });
  // Older database records may contain a numeric value or formatted string. Compare normalized strings.
  const user = loadDB().users.find(u => String(u.contactNumber == null ? '' : u.contactNumber).replace(/\D/g, '').padStart(7, '0') === q); if (!user) return res.status(404).json({ error: 'Nenhum perfil encontrado com esse número.' });
  res.json({ user: { id: user.id, username: user.username, contactNumber: user.contactNumber, photoUrl: user.photoUrl || null, bio: user.bio || '' } });
});

// ---------- Trocar ou remover a própria foto de perfil ----------
app.post('/api/users/:userId/photo', (req, res) => {
  const { userId } = req.params;
  const { photoUrl } = req.body;
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

  user.photoUrl = photoUrl || null;
  saveDB(db);
  res.json({ ok: true, user: publicUser(user) });
});

// ---------- Atualizar campos do perfil próprio ----------
app.post('/api/users/:userId/profile', (req, res) => {
  const { userId } = req.params;
  if (req.body.userId !== userId) return res.status(403).json({ error: 'Você só pode editar seu próprio perfil.' });
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  const bio = String(req.body.bio || '').trim().slice(0, 240);
  const phoneProvided = Object.prototype.hasOwnProperty.call(req.body, 'phone');
  const phone = String(req.body.phone || '').trim().slice(0, 30);
  const ringColor = /^#[0-9a-fA-F]{6}$/.test(String(req.body.ringColor || '')) ? req.body.ringColor : '#c7f36b';
  const ageRaw = String(req.body.age == null ? '' : req.body.age).trim();
  const age = ageRaw && /^\d{1,3}$/.test(ageRaw) && Number(ageRaw) >= 13 && Number(ageRaw) <= 120 ? Number(ageRaw) : '';
  const sexuality = String(req.body.sexuality || '').trim().slice(0, 40);
  const city = String(req.body.city || '').trim().slice(0, 80);
  const state = String(req.body.state || '').trim().slice(0, 80);
  const relationshipStatus = String(req.body.relationshipStatus || '').trim().slice(0, 40);
  const bannerUrl = String(req.body.bannerUrl || '').trim().slice(0, 500);
  user.bio = bio;
  if (phoneProvided) user.phone = phone;
  user.age = age; user.sexuality = sexuality; user.city = city; user.state = state;
  user.relationshipStatus = relationshipStatus; user.bannerUrl = bannerUrl;
  user.ringColor = ringColor;
  user.socials = normalizarSocials(req.body.socials);
  saveDB(db);
  res.json({ ok: true, user: publicUser(user) });
});

// ---------- Buscar usuário (pra iniciar conversa) ----------
app.get('/api/find-user', (req, res) => {
  const { query, viewerId } = req.query;
  if (!query) return res.status(400).json({ error: 'Informe email ou usuário' });
  const db = loadDB();
  const user = findUserByEmailOrUsername(db, query);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  const pub = publicUser(user);
  pub.photoUrl = fotoParaViewer(db, user, viewerId);
  res.json({ user: pub });
});

// ---------- Salvar um contato de verdade (clique em "Salvar contato") ----------
app.post('/api/contacts', (req, res) => {
  const { ownerId, contactId } = req.body;
  if (!ownerId || !contactId) return res.status(400).json({ error: 'Dados incompletos' });
  const db = loadDB();
  const jaSalvo = db.contacts.some(c => c.ownerId === ownerId && c.contactId === contactId);
  if (!jaSalvo) {
    db.contacts.push({ ownerId, contactId, createdAt: Date.now() });
    saveDB(db);
  }
  res.json({ ok: true });
});

// ---------- Lista de contatos salvos (fica no servidor, igual em qualquer aparelho) ----------
app.get('/api/contacts', (req, res) => {
  const { ownerId } = req.query;
  if (!ownerId) return res.status(400).json({ error: 'Dados incompletos' });
  const db = loadDB();
  const contatos = db.contacts
    .filter(c => c.ownerId === ownerId)
    .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0))
    .map(c => db.users.find(u => u.id === c.contactId))
    .filter(Boolean)
    .map(u => ({ id: u.id, username: u.username, email: u.email || null, photoUrl: fotoParaViewer(db, u, ownerId) }));
  res.json({ contacts: contatos });
});

// ---------- Apagar contato de vez (não é só cosmético — some da regra de privacidade também) ----------
app.post('/api/contacts/remove', (req, res) => {
  const { ownerId, contactId } = req.body;
  if (!ownerId || !contactId) return res.status(400).json({ error: 'Dados incompletos' });
  const db = loadDB();
  db.contacts = db.contacts.filter(c => !(c.ownerId === ownerId && c.contactId === contactId));
  saveDB(db);
  res.json({ ok: true });
});

// ---------- Perfil público resumido, com a foto já filtrada pra quem está pedindo ----------
// Usado pra atualizar a lista de "Nova conversa" com a foto sempre em dia (nunca confiar
// em foto guardada em cache local pra isso, ou a privacidade fica furada).
app.get('/api/users/:userId/public', (req, res) => {
  const { userId } = req.params;
  const { viewerId } = req.query;
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  res.json({
    id: user.id,
    username: user.username,
    contactNumber: user.contactNumber || null,
    photoUrl: fotoParaViewer(db, user, viewerId),
    bio: user.bio || '',
    statusText: user.statusText || '',
    phone: user.phone || '',
    ringColor: user.ringColor || '#c7f36b',
    age: user.age || '', sexuality: user.sexuality || '', city: user.city || '', state: user.state || '',
    relationshipStatus: user.relationshipStatus || '', bannerUrl: user.bannerUrl || '',
    socials: normalizarSocials(user.socials)
  });
});

// ---------- Ver a preferência de privacidade da foto (e a lista seleta, com nomes) ----------
app.get('/api/users/:userId/photo-privacy', (req, res) => {
  const { userId } = req.params;
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

  const allowList = (user.photoAllowList || []).map(id => {
    const u = db.users.find(x => x.id === id);
    return { id, username: u ? u.username : 'Usuário removido' };
  });
  res.json({ privacy: user.photoPrivacy || 'todos', allowList });
});

// ---------- Trocar a preferência de privacidade da foto ----------
app.post('/api/users/:userId/photo-privacy', (req, res) => {
  const { userId } = req.params;
  const { privacy } = req.body;
  const validas = ['todos', 'contatos', 'lista', 'ninguem'];
  if (!validas.includes(privacy)) return res.status(400).json({ error: 'Opção de privacidade inválida' });

  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

  user.photoPrivacy = privacy;
  saveDB(db);
  res.json({ ok: true, privacy: user.photoPrivacy });
});

// ---------- Adicionar/remover alguém da lista seleta (só usado quando privacy === 'lista') ----------
app.post('/api/users/:userId/photo-privacy/lista', (req, res) => {
  const { userId } = req.params;
  const { query, remover } = req.body; // "query" = email/usuário pra adicionar; "remover" = id pra tirar
  const db = loadDB();
  const user = db.users.find(u => u.id === userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  if (!user.photoAllowList) user.photoAllowList = [];

  if (remover) {
    user.photoAllowList = user.photoAllowList.filter(id => id !== remover);
    saveDB(db);
    return res.json({ ok: true, allowList: user.photoAllowList });
  }

  if (!query) return res.status(400).json({ error: 'Informe o email ou usuário' });
  const alvo = findUserByEmailOrUsername(db, query);
  if (!alvo) return res.status(404).json({ error: 'Usuário não encontrado' });
  if (alvo.id === userId) return res.status(400).json({ error: 'Você já vê sua própria foto sempre' });
  if (!user.photoAllowList.includes(alvo.id)) user.photoAllowList.push(alvo.id);
  saveDB(db);
  res.json({ ok: true, added: { id: alvo.id, username: alvo.username } });
});

// ---------- Estatísticas (usado na home) ----------
app.get('/api/stats', (req, res) => {
  const db = loadDB();

  // Quem criou mais conversas (privadas + grupos)
  const contagemPorCriador = {};
  db.chats.forEach(c => {
    if (c.type === 'private' && c.members.length === 2 && c.members[0] === c.members[1]) return; // conversa com você mesmo não conta
    const criador = c.createdBy || c.members[0];
    if (!criador) return;
    contagemPorCriador[criador] = (contagemPorCriador[criador] || 0) + 1;
  });
  const usuariosMaisAtivos = Object.entries(contagemPorCriador)
    .map(([userId, total]) => {
      const u = db.users.find(x => x.id === userId);
      return u ? { username: u.username, total } : null; // conta removida não aparece na home
    })
    .filter(Boolean)
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  // Grupo com mais mensagens
  const grupos = db.chats
    .filter(c => c.type === 'group')
    .map(c => ({
      nome: c.name,
      totalMensagens: db.messages.filter(m => m.chatId === c.id).length,
      totalMembros: c.members.length
    }))
    .sort((a, b) => b.totalMensagens - a.totalMensagens);

  res.json({
    usuariosMaisAtivos,
    grupoMaisAtivo: grupos[0] || null
  });
});

// ---------- Chats ----------
app.post('/api/chats/private', (req, res) => {
  const { userId, targetUserId } = req.body;
  const db = loadDB();

  const targetExiste = db.users.some(u => u.id === targetUserId);
  if (!targetExiste) return res.status(404).json({ error: 'Esse usuário não existe (ou a conta foi removida)' });

  const euBloqueiEle = db.blocks.some(b => b.userId === userId && b.blockedId === targetUserId);
  const eleMeBloqueou = db.blocks.some(b => b.userId === targetUserId && b.blockedId === userId);

  if (euBloqueiEle) {
    return res.status(403).json({ error: 'Você bloqueou esse usuário.', bloqueadoPorMim: true });
  }
  if (eleMeBloqueou) {
    return res.status(403).json({ error: 'Não é possível conversar com esse usuário' });
  }

  // busca a conversa privada certa. Quando é "conversa comigo mesmo" (userId === targetUserId),
  // não dá pra usar só "includes(userId) && includes(targetUserId)" — as duas condições ficam
  // idênticas e isso combinaria com QUALQUER conversa privada que você já tenha, com QUALQUER
  // pessoa (já que ela também "includes(userId)"). Por isso trata esse caso à parte, exigindo
  // que os dois membros sejam você mesmo.
  let chat = db.chats.find(c => {
    if (c.type !== 'private') return false;
    if (userId === targetUserId) {
      return c.members.length === 2 && c.members[0] === userId && c.members[1] === userId;
    }
    return c.members.includes(userId) && c.members.includes(targetUserId);
  });

  if (!chat) {
    chat = {
      id: uuidv4(),
      type: 'private',
      name: null,
      members: [userId, targetUserId],
      createdBy: userId,
      createdAt: Date.now()
    };
    db.chats.push(chat);
    saveDB(db);
  }

  res.json({ chat });
});

// alguém está bloqueado em relação ao criador/quem está adicionando (nos dois sentidos)?
function estaBloqueado(db, idA, idB) {
  return db.blocks.some(b =>
    (b.userId === idA && b.blockedId === idB) ||
    (b.userId === idB && b.blockedId === idA)
  );
}

app.post('/api/chats/group', (req, res) => {
  const { userId, name, memberQueries } = req.body;
  const db = loadDB();
  const criador = db.users.find(u => u.id === userId);
  const agora = Date.now();

  const chat = {
    id: uuidv4(),
    type: 'group',
    name: name || 'Grupo sem nome',
    description: '',
    photoUrl: null,
    members: [userId],
    memberJoinedAt: { [userId]: agora },
    admins: [],
    modoEnvio: 'todos',
    removedMembers: [],
    inviteCode: uuidv4(),
    approvalRequired: false,
    joinRequests: [],
    createdBy: userId,
    createdAt: agora
  };

  const naoEncontrados = [];
  const bloqueados = [];
  const avisos = [];
  const jaAdicionados = new Set([userId]);

  (memberQueries || []).forEach(q => {
    const u = findUserByEmailOrUsername(db, q);
    if (!u) { naoEncontrados.push(q); return; }
    if (jaAdicionados.has(u.id)) return;

    if (estaBloqueado(db, userId, u.id)) {
      bloqueados.push(u.username);
      return;
    }

    chat.members.push(u.id);
    marcarEntradaNoGrupo(chat, u.id, agora);
    jaAdicionados.add(u.id);
    avisos.push(criarMensagemSistema(
      chat.id,
      `${criador ? criador.username : 'Alguém'} adicionou ${u.username} ao grupo`,
      { kind: 'add_member', actorId: userId, targetId: u.id }
    ));
  });

  if (chat.members.length < 2) {
    return res.status(400).json({
      error: 'Adicione pelo menos uma pessoa pra criar o grupo.',
      naoEncontrados,
      bloqueados
    });
  }

  db.chats.push(chat);
  avisos.forEach(m => db.messages.push(m));
  saveDB(db);

  avisos.forEach(m => emitirMensagemSistemaPersonalizada(db, chat.members, m));
  res.json({ chat, naoEncontrados, bloqueados });
});

// apaga arquivos de mídia de um conjunto de mensagens (usado ao apagar/sair de uma conversa)
function apagarArquivosDoChat(db, chatId) {
  db.messages
    .filter(m => m.chatId === chatId && m.mediaUrl)
    .forEach(m => {
      apagarArquivo(m.mediaUrl);
    });
}

// ---------- Apagar conversa (PV ou grupo) ----------
app.post('/api/chats/:chatId/delete', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat) return res.status(404).json({ error: 'Conversa não encontrada' });

  if (chat.type === 'private' && chat.members.includes(userId)) {
    const eAutoConversa = chat.members.every(m => m === userId);
    if (!eAutoConversa) {
      // PV: apagar é pessoal. Só some pra quem apagou (e o histórico antigo some pra ele);
      // a outra pessoa continua com a conversa. Se os dois apagarem, aí sim limpa tudo.
      if (!chat.hiddenAt) chat.hiddenAt = {};
      chat.hiddenAt[userId] = Date.now();
      if (chat.members.every(m => chat.hiddenAt[m])) {
        apagarArquivosDoChat(db, chatId);
        db.messages = db.messages.filter(m => m.chatId !== chatId);
        db.chats = db.chats.filter(c => c.id !== chatId);
      }
      saveDB(db);
      return res.json({ ok: true });
    }
  }

  if (chat.members.includes(userId)) {
    // membro de verdade: apaga a conversa inteira, pra todo mundo (comportamento de sempre)
    apagarArquivosDoChat(db, chatId);
    db.messages = db.messages.filter(m => m.chatId !== chatId);
    db.chats = db.chats.filter(c => c.id !== chatId);
    saveDB(db);
    return res.json({ ok: true });
  }

  // não é mais membro: só pode ser alguém que foi removido do grupo.
  // "apagar" aqui é pessoal — só some da lista dela, o grupo e as mensagens
  // continuam existindo normalmente pra quem ainda tá dentro.
  const eraMembro = (chat.removedMembers || []).some(r => r.userId === userId);
  if (!eraMembro) return res.status(404).json({ error: 'Conversa não encontrada' });

  chat.removedMembers = chat.removedMembers.filter(r => r.userId !== userId);
  saveDB(db);
  res.json({ ok: true });
});

// ---------- Sair de um grupo ----------
app.post('/api/chats/:chatId/leave', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') {
    return res.status(404).json({ error: 'Grupo não encontrado' });
  }
  if (!chat.members.includes(userId)) {
    return res.status(400).json({ error: 'Você não está nesse grupo' });
  }

  let novoAdminMsg = null;
  const quemSaiu = db.users.find(u => u.id === userId);
  const msg = criarMensagemSistema(
    chatId,
    `${quemSaiu ? quemSaiu.username : 'Alguém'} saiu do grupo`,
    { kind: 'leave_group', actorId: userId, targetId: userId }
  );

  // quem ainda vai ficar no grupo + quem tá saindo (pra ele ver a própria msg de saída antes de virar fantasma)
  const destinatarios = chat.members.slice();

  const eraDono = souDono(chat, userId);
  chat.members = chat.members.filter(m => m !== userId);
  if (chat.admins) chat.admins = chat.admins.filter(a => a !== userId);
  if (eraDono) {
    // o dono saiu: o grupo fica sem dono (quem criou continua registrado em createdBy).
    // Se não sobrou nenhum admin, um membro aleatório vira admin pro grupo não ficar sem ninguém.
    chat.ownerId = null;
    if (chat.members.length && !(chat.admins || []).length) {
      const sorteado = chat.members[Math.floor(Math.random() * chat.members.length)];
      chat.admins = [sorteado];
      const alvo = db.users.find(u => u.id === sorteado);
      novoAdminMsg = criarMensagemSistema(
        chatId,
        `${alvo ? alvo.username : 'Alguém'} agora é admin do grupo`,
        { kind: 'promote', actorId: sorteado, targetId: sorteado }
      );
    }
  }

  // mesma regra de quando é removido: continua vendo o histórico até agora
  // (modo fantasma), só não recebe mensagem nova nem consegue mandar
  if (!chat.removedMembers) chat.removedMembers = [];
  chat.removedMembers = chat.removedMembers.filter(r => r.userId !== userId);
  chat.removedMembers.push({ userId, removedAt: Date.now() });

  db.messages.push(msg);
  if (novoAdminMsg) db.messages.push(novoAdminMsg);

  if (chat.members.length === 0) {
    apagarArquivosDoChat(db, chatId);
    db.messages = db.messages.filter(m => m.chatId !== chatId);
    db.chats = db.chats.filter(c => c.id !== chatId);
  }

  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, destinatarios, msg);
  if (novoAdminMsg) emitirMensagemSistemaPersonalizada(db, chat.members, novoAdminMsg);
  res.json({ ok: true });
});

// ---------- Membros do grupo (dono, admins, membros comuns) ----------
app.get('/api/chats/:chatId/members', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.query;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group' || !chat.members.includes(userId)) {
    return res.status(404).json({ error: 'Grupo não encontrado' });
  }
  const admins = chat.admins || [];
  const membros = chat.members.map(id => {
    const u = db.users.find(x => x.id === id);
    return {
      id,
      username: u ? u.username : 'Usuário removido',
      email: u ? u.email : null,
      photoUrl: u ? fotoParaViewer(db, u, userId) : null,
      isOwner: id === donoDe(chat),
      isAdmin: admins.includes(id)
    };
  });
  const criador = db.users.find(u => u.id === chat.createdBy);
  // filtro extra de segurança: nunca mostra na lista de "Saíram" alguém que
  // já voltou e está em chat.members de novo (mesmo que sobre algum registro antigo)
  const saidos = (chat.removedMembers || [])
    .filter(r => !chat.members.includes(r.userId))
    .slice()
    .sort((a, b) => b.removedAt - a.removedAt)
    .map(r => {
      const u = db.users.find(x => x.id === r.userId);
      return {
        id: r.userId,
        username: u ? u.username : 'Usuário removido',
        photoUrl: u ? fotoParaViewer(db, u, userId) : null,
        saiuEm: r.removedAt
      };
    });
  res.json({
    membros,
    saidos,
    name: chat.name,
    photoUrl: chat.photoUrl || null,
    bannerUrl: chat.bannerUrl || null,
    description: chat.description || '',
    criadoPor: criador ? criador.username : 'Usuário removido',
    criadoEm: chat.createdAt,
    modoEnvio: chat.modoEnvio || 'todos',
    souDono: souDono(chat, userId),
    souAdmin: souAdminDoGrupo(chat, userId)
  });
});

// ---------- Adicionar pessoas a um grupo já existente (dono ou admins podem) ----------
app.post('/api/chats/:chatId/add-members', (req, res) => {
  const { chatId } = req.params;
  const { userId, memberQueries } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem adicionar pessoas' });

  const ator = db.users.find(u => u.id === userId);
  const naoEncontrados = [];
  const bloqueados = [];
  const jaNoGrupo = [];
  const avisos = [];

  (memberQueries || []).forEach(q => {
    const u = findUserByEmailOrUsername(db, q);
    if (!u) { naoEncontrados.push(q); return; }
    if (chat.members.includes(u.id)) { jaNoGrupo.push(u.username); return; }
    if (estaBloqueado(db, userId, u.id)) { bloqueados.push(u.username); return; }

    chat.members.push(u.id);
    marcarEntradaNoGrupo(chat, u.id);
    avisos.push(criarMensagemSistema(
      chatId,
      `${ator ? ator.username : 'Alguém'} adicionou ${u.username} ao grupo`,
      { kind: 'add_member', actorId: userId, targetId: u.id }
    ));
  });

  if (!avisos.length) {
    return res.status(400).json({
      error: 'Ninguém foi adicionado.',
      naoEncontrados,
      bloqueados,
      jaNoGrupo
    });
  }

  avisos.forEach(m => db.messages.push(m));
  saveDB(db);
  avisos.forEach(m => emitirMensagemSistemaPersonalizada(db, chat.members, m));

  res.json({ ok: true, naoEncontrados, bloqueados, jaNoGrupo });
});

// ---------- Convite por link (igual WhatsApp: link + opção de exigir aprovação) ----------

// ver o link (código) atual e os pedidos pendentes — só admin/dono
app.get('/api/chats/:chatId/invite', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.query;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem ver o link de convite' });

  const pedidos = (chat.joinRequests || []).map(r => {
    const u = db.users.find(x => x.id === r.userId);
    return {
      userId: r.userId,
      username: u ? u.username : 'Usuário removido',
      photoUrl: u ? fotoParaViewer(db, u, userId) : null,
      requestedAt: r.requestedAt
    };
  });

  res.json({
    code: chat.inviteCode,
    approvalRequired: !!chat.approvalRequired,
    joinRequests: pedidos
  });
});

// gerar um link novo, invalidando o antigo — só admin/dono
app.post('/api/chats/:chatId/invite/reset', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem redefinir o link' });

  chat.inviteCode = uuidv4();
  saveDB(db);
  res.json({ code: chat.inviteCode });
});

// ligar/desligar a exigência de aprovação pra entrar pelo link — só admin/dono
app.post('/api/chats/:chatId/invite/approval', (req, res) => {
  const { chatId } = req.params;
  const { userId, ativo } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem mudar isso' });

  chat.approvalRequired = !!ativo;
  saveDB(db);
  res.json({ ok: true, approvalRequired: chat.approvalRequired });
});

// entrar num grupo usando o código do link — qualquer usuário logado
// ---------- Só consulta o link de convite, sem entrar nem mandar pedido (usado pra mostrar a confirmação antes) ----------
app.get('/api/invite/:code/info', (req, res) => {
  const { code } = req.params;
  const { userId } = req.query;
  const db = loadDB();
  const chat = db.chats.find(c => c.type === 'group' && c.inviteCode === code);
  if (!chat) return res.status(404).json({ error: 'Link inválido ou expirado' });

  res.json({
    ok: true,
    chatId: chat.id,
    chatName: chat.name,
    approvalRequired: !!chat.approvalRequired,
    jaEstava: chat.members.includes(userId),
    jaPendente: (chat.joinRequests || []).some(r => r.userId === userId),
    bloqueado: estaBloqueado(db, userId, chat.createdBy)
  });
});

app.post('/api/invite/:code/join', (req, res) => {
  const { code } = req.params;
  const { userId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.type === 'group' && c.inviteCode === code);
  if (!chat) return res.status(404).json({ error: 'Link inválido ou expirado' });

  if (chat.members.includes(userId)) {
    return res.json({ ok: true, jaEstava: true, chat: { id: chat.id, name: chat.name, type: chat.type } });
  }
  if (estaBloqueado(db, userId, chat.createdBy)) {
    return res.status(403).json({ error: 'Não foi possível entrar nesse grupo' });
  }
  if ((chat.joinRequests || []).some(r => r.userId === userId)) {
    return res.json({ ok: true, pendente: true });
  }

  if (chat.approvalRequired) {
    if (!chat.joinRequests) chat.joinRequests = [];
    chat.joinRequests.push({ userId, requestedAt: Date.now() });
    saveDB(db);

    const solicitante = db.users.find(u => u.id === userId);
    const admins = [donoDe(chat), ...(chat.admins || [])].filter(Boolean);
    admins.forEach(adminId => {
      io.to('user:' + adminId).emit('solicitacao_entrada', {
        chatId: chat.id,
        chatName: chat.name,
        username: solicitante ? solicitante.username : 'Alguém'
      });
    });
    return res.json({ ok: true, pendente: true });
  }

  chat.members.push(userId);
  marcarEntradaNoGrupo(chat, userId);
  const msg = criarMensagemSistema(
    chat.id,
    `${db.users.find(u => u.id === userId)?.username || 'Alguém'} entrou no grupo pelo link de convite`,
    { kind: 'join_link', actorId: userId, targetId: userId }
  );
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);

  res.json({ ok: true, chat: { id: chat.id, name: chat.name, type: chat.type } });
});

// o próprio solicitante desiste do pedido de entrada (não precisa ser admin, só é dono do próprio pedido)
app.post('/api/invite/:code/cancelar', (req, res) => {
  const { code } = req.params;
  const { userId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.type === 'group' && c.inviteCode === code);
  if (!chat) return res.status(404).json({ error: 'Link inválido ou expirado' });

  chat.joinRequests = (chat.joinRequests || []).filter(r => r.userId !== userId);
  saveDB(db);
  res.json({ ok: true });
});

// aprovar ou recusar um pedido de entrada — só admin/dono
app.post('/api/chats/:chatId/invite/responder', (req, res) => {
  const { chatId } = req.params;
  const { userId, targetUserId, aprovar } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem responder pedidos' });

  const havia = (chat.joinRequests || []).some(r => r.userId === targetUserId);
  chat.joinRequests = (chat.joinRequests || []).filter(r => r.userId !== targetUserId);
  if (!havia) { saveDB(db); return res.json({ ok: true }); }

  if (!aprovar) {
    saveDB(db);
    io.to('user:' + targetUserId).emit('solicitacao_recusada', { chatName: chat.name });
    return res.json({ ok: true });
  }

  chat.members.push(targetUserId);
  marcarEntradaNoGrupo(chat, targetUserId);
  const msg = criarMensagemSistema(
    chatId,
    `${db.users.find(u => u.id === targetUserId)?.username || 'Alguém'} entrou no grupo pelo link de convite`,
    { kind: 'join_link', actorId: targetUserId, targetId: targetUserId }
  );
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  res.json({ ok: true });
});

// ---------- Editar o nome do grupo (dono ou admins podem) ----------
app.post('/api/chats/:chatId/rename', (req, res) => {
  const { chatId } = req.params;
  const { userId, name } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem mudar o nome do grupo' });

  const novoNome = (name || '').trim();
  if (!novoNome) return res.status(400).json({ error: 'O nome não pode ficar vazio' });
  if (novoNome === chat.name) return res.json({ ok: true, name: chat.name });

  chat.name = novoNome;
  const msg = criarMensagemSistema(
    chatId,
    `${db.users.find(u => u.id === userId)?.username || 'Alguém'} mudou o nome do grupo para "${novoNome}"`,
    { kind: 'rename', actorId: userId, novoNome }
  );
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  res.json({ ok: true, name: chat.name });
});

// ---------- Editar a descrição do grupo (dono ou admins podem) ----------
app.post('/api/chats/:chatId/description', (req, res) => {
  const { chatId } = req.params;
  const { userId, description } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem mudar a descrição do grupo' });

  const novaDescricao = (description || '').trim().slice(0, 300);
  if (novaDescricao === (chat.description || '')) return res.json({ ok: true, description: chat.description || '' });

  chat.description = novaDescricao;
  const msg = criarMensagemSistema(
    chatId,
    `${db.users.find(u => u.id === userId)?.username || 'Alguém'} mudou a descrição do grupo`,
    { kind: 'description', actorId: userId }
  );
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  res.json({ ok: true, description: chat.description });
});

// ---------- Trocar ou remover a foto do grupo (dono ou admins podem) ----------
app.post('/api/chats/:chatId/photo', (req, res) => {
  const { chatId } = req.params;
  const { userId, photoUrl } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem mudar a foto do grupo' });

  chat.photoUrl = photoUrl || null;
  const nomeAtor = db.users.find(u => u.id === userId)?.username || 'Alguém';
  const removida = !chat.photoUrl;
  const msg = criarMensagemSistema(
    chatId,
    removida ? `${nomeAtor} removeu a foto do grupo` : `${nomeAtor} mudou a foto do grupo`,
    { kind: 'photo', actorId: userId, removida }
  );
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  res.json({ ok: true, photoUrl: chat.photoUrl });
});

// ---------- Banner do grupo (dono/admin) ----------
app.post('/api/chats/:chatId/banner', (req, res) => {
  const { chatId } = req.params;
  const { userId, bannerUrl } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem mudar o banner do grupo' });
  chat.bannerUrl = typeof bannerUrl === 'string' && bannerUrl.trim() ? bannerUrl.trim() : null;
  const nomeAtor = db.users.find(u => u.id === userId)?.username || 'Alguém';
  const msg = criarMensagemSistema(chatId, `${nomeAtor} ${chat.bannerUrl ? 'alterou o banner' : 'removeu o banner'} do grupo`, { kind: 'banner', actorId: userId });
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  res.json({ ok: true, bannerUrl: chat.bannerUrl });
});

// ---------- Quem pode mandar mensagem no grupo: todos / só admins / só o dono ----------
// "dono" é a trava mais forte: nem os admins conseguem mandar mensagem, só quem criou o grupo.
// Por isso só o próprio dono pode ativar (ou desativar) essa opção.
app.post('/api/chats/:chatId/modo-envio', (req, res) => {
  const { chatId } = req.params;
  const { userId, modo } = req.body;
  const validos = ['todos', 'admins', 'dono'];
  if (!validos.includes(modo)) return res.status(400).json({ error: 'Opção inválida' });

  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });

  const modoAtual = chat.modoEnvio || 'todos';
  // enquanto o modo "só o dono" tiver ativo, só o dono pode mexer nisso de novo —
  // senão um admin poderia simplesmente reabrir e a trava não serviria pra nada
  if (modoAtual === 'dono' && !souDono(chat, userId)) {
    return res.status(403).json({ error: 'Só o dono pode mudar essa configuração agora' });
  }
  if (modo === 'dono') {
    if (!souDono(chat, userId)) return res.status(403).json({ error: 'Só o dono do grupo pode ativar essa opção' });
  } else if (!souAdminDoGrupo(chat, userId)) {
    return res.status(403).json({ error: 'Só o dono ou admins podem mudar isso' });
  }

  if (modo === modoAtual) return res.json({ ok: true, modoEnvio: modo });

  chat.modoEnvio = modo;
  const msg = criarMensagemSistema(
    chatId,
    'Configuração de envio do grupo foi alterada',
    { kind: 'modo_envio', actorId: userId, modo }
  );
  db.messages.push(msg);
  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  io.to('chat:' + chatId).emit('modo_envio_alterado', { chatId, modoEnvio: modo });

  res.json({ ok: true, modoEnvio: modo });
});

// ---------- Dar admin (só o dono do grupo pode) ----------
app.post('/api/chats/:chatId/promote', (req, res) => {
  const { chatId } = req.params;
  const { userId, targetUserId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem dar admin' });
  if (!chat.members.includes(targetUserId)) return res.status(400).json({ error: 'Essa pessoa não está no grupo' });

  if (!chat.admins) chat.admins = [];
  if (!chat.admins.includes(targetUserId)) {
    chat.admins.push(targetUserId);
    const alvo = db.users.find(u => u.id === targetUserId);
    const msg = criarMensagemSistema(
      chat.id,
      `${alvo ? alvo.username : 'Alguém'} agora é admin do grupo`,
      { kind: 'promote', actorId: userId, targetId: targetUserId }
    );
    db.messages.push(msg);
    saveDB(db);
    emitirMensagemSistemaPersonalizada(db, chat.members, msg);
  } else {
    saveDB(db);
  }
  res.json({ ok: true });
});

// ---------- Tirar admin (só o dono do grupo pode) ----------
app.post('/api/chats/:chatId/demote', (req, res) => {
  const { chatId } = req.params;
  const { userId, targetUserId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem tirar admin' });
  if (targetUserId === donoDe(chat)) return res.status(400).json({ error: 'O dono não pode perder o cargo' });
  if (!(chat.admins || []).includes(targetUserId)) return res.json({ ok: true });

  chat.admins = chat.admins.filter(a => a !== targetUserId);
  saveDB(db);
  res.json({ ok: true });
});

// ---------- Remover pessoa do grupo (dono ou admins podem) ----------
app.post('/api/chats/:chatId/remove-member', (req, res) => {
  const { chatId } = req.params;
  const { userId, targetUserId } = req.body;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || chat.type !== 'group') return res.status(404).json({ error: 'Grupo não encontrado' });
  if (!souAdminDoGrupo(chat, userId)) return res.status(403).json({ error: 'Só o dono ou admins podem remover pessoas' });
  if (targetUserId === donoDe(chat)) return res.status(403).json({ error: 'Não é possível remover o dono do grupo' });
  if (!chat.members.includes(targetUserId)) return res.status(400).json({ error: 'Essa pessoa não está no grupo' });

  const alvo = db.users.find(u => u.id === targetUserId);
  const msg = criarMensagemSistema(
    chatId,
    `${alvo ? alvo.username : 'Alguém'} foi removido do grupo`,
    { kind: 'remove_member', actorId: userId, targetId: targetUserId }
  );

  // quem ainda vai ficar no grupo depois da remoção (pra emitir pra eles) +
  // o próprio removido (pra ele ver "Você foi removido do grupo" antes de sair da tela)
  const destinatarios = chat.members.slice();

  chat.members = chat.members.filter(m => m !== targetUserId);
  if (chat.admins) chat.admins = chat.admins.filter(a => a !== targetUserId);

  // guarda o registro de remoção: a pessoa não é mais membro, mas continua
  // enxergando o histórico até esse momento (só não recebe mensagem nova
  // nem consegue mandar). Isso fica pra sempre, até ela mesma apagar a conversa.
  if (!chat.removedMembers) chat.removedMembers = [];
  chat.removedMembers = chat.removedMembers.filter(r => r.userId !== targetUserId);
  chat.removedMembers.push({ userId: targetUserId, removedAt: Date.now() });

  db.messages.push(msg);

  if (chat.members.length === 0) {
    apagarArquivosDoChat(db, chatId);
    db.messages = db.messages.filter(m => m.chatId !== chatId);
    db.chats = db.chats.filter(c => c.id !== chatId);
  }

  saveDB(db);
  emitirMensagemSistemaPersonalizada(db, destinatarios, msg);
  io.to('user:' + targetUserId).emit('removido_do_grupo', { chatId });
  res.json({ ok: true });
});

// ---------- Bloquear usuário ----------
app.post('/api/block', (req, res) => {
  const { userId, blockedId } = req.body;
  if (!userId || !blockedId) return res.status(400).json({ error: 'Dados incompletos' });
  const db = loadDB();
  const jaBloqueado = db.blocks.some(b => b.userId === userId && b.blockedId === blockedId);
  if (!jaBloqueado) {
    db.blocks.push({ userId, blockedId, createdAt: Date.now() });
    saveDB(db);
  }
  res.json({ ok: true });
});

// ---------- Desbloquear usuário ----------
app.post('/api/unblock', (req, res) => {
  const { userId, blockedId } = req.body;
  if (!userId || !blockedId) return res.status(400).json({ error: 'Dados incompletos' });
  const db = loadDB();
  db.blocks = db.blocks.filter(b => !(b.userId === userId && b.blockedId === blockedId));
  saveDB(db);
  res.json({ ok: true });
});

// ---------- Listar quem eu bloqueei ----------
app.get('/api/blocks', (req, res) => {
  const { userId } = req.query;
  if (!userId) return res.status(400).json({ error: 'Informe o userId' });
  const db = loadDB();
  const bloqueados = db.blocks
    .filter(b => b.userId === userId)
    .map(b => {
      const u = db.users.find(x => x.id === b.blockedId);
      return { id: b.blockedId, username: u ? u.username : 'Usuário removido' };
    });
  res.json({ bloqueados });
});

// ---------- Reações, mensagens fixadas e conversas arquivadas ----------
const EMOJIS_REACAO_PERMITIDOS = new Set(["❤️", "👍", "😂", "😮", "😢", "🙏", "🔥", "👏", "🎉", "💯", "😀", "😃", "😄", "😁", "😆", "😅", "🤣", "🥲", "☺️", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🥸", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺", "😭", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥", "😓", "🤗", "🤔", "🫣", "🤭", "🫢", "🫡", "🤫", "🫠", "🤥", "😶", "😐", "😑", "😬", "🫨", "🫥", "😴", "🥱", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "😵", "😵‍💫", "🤐", "🥴", "🤠", "🤑", "😈", "👿", "👹", "👺", "💀", "☠️", "👻", "👽", "👾", "🤖", "💩", "🎃", "😺", "😸", "😹", "😻", "😼", "😽", "🙀", "😿", "😾", "👋", "🤚", "🖐️", "✋", "🖖", "🫱", "🫲", "🫳", "🫴", "🫷", "🫸", "👌", "🤌", "🤏", "✌️", "🤞", "🫰", "🤟", "🤘", "🤙", "👈", "👉", "👆", "🖕", "👇", "☝️", "👎", "✊", "👊", "🤛", "🤜", "🙌", "🫶", "👐", "🤲", "🤝", "✍️", "💅", "🤳", "💪", "🦾", "🦿", "🦵", "🦶", "👂", "🦻", "👃", "👀", "👁️", "👅", "👄", "🫦", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💔", "❤️‍🔥", "❤️‍🩹", "💕", "💞", "💓", "💗", "💖", "💘", "💝", "💟", "❣️", "💌", "💋", "💢", "💥", "💫", "💦", "💨", "🕳️", "💣", "💬", "👁️‍🗨️", "🗨️", "🗯️", "💭", "💤", "🎊", "🎈", "🎁", "✨", "⭐", "🌟", "🌈", "☀️", "🌙", "⚡", "❄️", "☃️", "🌸", "🌹", "🌻", "🍀", "🏆", "🥇", "🎮", "🎯", "🚀", "💎", "🎵", "🎶", "📌", "📎", "🔗", "💡", "📷", "🎬", "🎤", "🎧", "📱", "💻", "⌚", "🔒", "🔑", "🐶", "🐱", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼", "🐻‍❄️", "🐨", "🐯", "🦁", "🐮", "🐷", "🐸", "🐵", "🙈", "🙉", "🙊", "🐔", "🐧", "🐦", "🐤", "🦆", "🦅", "🦉", "🦇", "🐺", "🐗", "🐴", "🦄", "🐝", "🪱", "🦋", "🐌", "🐞", "🐜", "🪰", "🪲", "🦟", "🦗", "🕷️", "🦂", "🐢", "🐍", "🦎", "🦖", "🦕", "🐙", "🦑", "🦐", "🦞", "🦀", "🐡", "🐠", "🐟", "🐬", "🐳", "🦈", "🐊", "🐅", "🐆", "🦓", "🦍", "🦧", "🐘", "🦛", "🦏", "🐪", "🐫", "🦒", "🦘", "🦬", "🐃", "🐂", "🐄", "🐎", "🐖", "🐏", "🐑", "🦙", "🐐", "🦌", "🐕", "🐩", "🦮", "🐈", "🐓", "🦃", "🦚", "🦜", "🦢", "🦩", "🕊️", "🐇", "🦝", "🦨", "🦡", "🦦", "🦥", "🐁", "🐀", "🐿️", "🦔", "🍎", "🍐", "🍊", "🍋", "🍌", "🍉", "🍇", "🍓", "🫐", "🍈", "🍒", "🍑", "🥭", "🍍", "🥥", "🥝", "🍅", "🍆", "🥑", "🥦", "🥬", "🥒", "🌶️", "🫑", "🌽", "🥕", "🫒", "🧄", "🧅", "🥔", "🍠", "🥐", "🥯", "🍞", "🥖", "🥨", "🧀", "🥚", "🍳", "🧈", "🥞", "🧇", "🥓", "🥩", "🍗", "🍖", "🌭", "🍔", "🍟", "🍕", "🫓", "🥪", "🥙", "🧆", "🌮", "🌯", "🫔", "🥗", "🥘", "🫕", "🍝", "🍜", "🍲", "🍛", "🍣", "🍱", "🥟", "🦪", "🍤", "🍙", "🍚", "🍘", "🍥", "🥠", "🥮", "🍢", "🍡", "🍧", "🍨", "🍦", "🥧", "🧁", "🍰", "🎂", "🍮", "🍭", "🍬", "🍫", "🍿", "🍩", "🍪", "🌰", "🥜", "🍯", "🥛", "🍼", "☕", "🫖", "🍵", "🧃", "🥤", "🧋", "🍶", "🍺", "🍻", "🥂", "🍷", "🥃", "🍸", "🍹", "🧉", "🚗", "🚕", "🚙", "🚌", "🚎", "🏎️", "🚓", "🚑", "🚒", "🚐", "🛻", "🚚", "🚛", "🚜", "🛵", "🏍️", "🚲", "🛴", "🛹", "🛼", "🚏", "🛣️", "🛤️", "🚦", "🚥", "🚧", "⚓", "⛵", "🚤", "🛳️", "🚢", "✈️", "🛩️", "🛫", "🛬", "🚁", "🚟", "🚠", "🚡", "🛰️", "🛸", "🌍", "🌎", "🌏", "🌋", "🗻", "🏕️", "🏖️", "🏝️", "🏜️", "🏞️", "🏟️", "🏛️", "🏗️", "🏘️", "🏠", "🏡", "🏢", "🏬", "🏥", "🏦", "🏨", "🏪", "🏫", "🏭", "🏰", "🗼", "🗽", "⛪", "🕌", "🛕", "⛩️", "⚽", "🏀", "🏈", "⚾", "🥎", "🎾", "🏐", "🏉", "🥏", "🎱", "🪀", "🏓", "🏸", "🏒", "🏑", "🥍", "🏏", "🪃", "🥅", "⛳", "🪁", "🏹", "🎣", "🤿", "🥊", "🥋", "🎽", "🛷", "⛸️", "🥌", "🎿", "⛷️", "🏂", "🏋️", "🤼", "🤸", "⛹️", "🤺", "🏇", "🧘", "🏄", "🏊", "🤽", "🚣", "🧗", "🚵", "🚴", "🥈", "🥉", "🏅", "🎖️", "🏳️", "🏴", "🏁", "🚩", "🏳️‍🌈", "🏳️‍⚧️", "🇧🇷", "🇵🇹", "🇺🇸", "🇬🇧", "🇯🇵", "🇰🇷", "🇨🇦", "🇦🇷", "🇲🇽", "🇫🇷", "🇩🇪", "🇮🇹", "🇪🇸", "🇨🇳", "🇮🇳", "🇷🇺", "🇺🇦", "🇦🇺", "🇳🇿", "🇿🇦", "🇦🇴", "🇲🇿", "🇨🇻", "🇬🇼", "🇹🇱", "🇸🇹", "🇹🇷", "🇸🇦", "🇦🇪", "🇮🇱", "🇪🇬", "🇳🇬", "🇰🇪", "🇨🇱", "🇨🇴", "🇵🇪", "🇺🇾", "🇵🇾", "🇧🇴", "🇻🇪", "🇪🇨", "🇨🇷", "🇵🇦", "🇨🇺", "🇩🇴", "🇭🇹", "🇯🇲", "🇵🇷", "🇹🇭", "🇻🇳", "🇮🇩", "🇵🇭", "🇲🇾", "🇸🇬", "🇹🇼", "🇭🇰", "🇵🇰", "🇧🇩", "🇳🇵", "🇱🇰", "🇮🇷", "🇮🇶", "🇬🇷", "🇳🇱", "🇧🇪", "🇨🇭", "🇦🇹", "🇸🇪", "🇳🇴", "🇩🇰", "🇫🇮", "🇵🇱", "🇨🇿", "🇸🇰", "🇭🇺", "🇷🇴", "🇧🇬", "🇭🇷", "🇷🇸", "🇸🇮", "🇮🇪", "🇮🇸", "🇱🇺", "🇲🇹", "🇨🇾", "🇪🇺"]);

app.post('/api/chats/:chatId/archive', (req, res) => {
  const { chatId } = req.params;
  const { userId, archived } = req.body || {};
  if (!userId) return res.status(400).json({ error: 'Informe o usuário.' });
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || (!chat.members.includes(userId) && !(chat.removedMembers || []).some(r => r.userId === userId))) {
    return res.status(404).json({ error: 'Conversa não encontrada.' });
  }
  if (!Array.isArray(chat.archivedBy)) chat.archivedBy = [];
  if (archived) {
    if (!chat.archivedBy.includes(userId)) chat.archivedBy.push(userId);
  } else {
    chat.archivedBy = chat.archivedBy.filter(id => id !== userId);
  }
  saveDB(db);
  res.json({ ok: true, archived: !!archived });
});

// Fixar mensagem: o usuário escolhe por quanto tempo (24h, 7 dias, 30 dias).
// Fixadas antigas (sem prazo) continuam valendo até serem desafixadas.
const DURACOES_FIXAR_MS = { '24h': 24 * 3600 * 1000, '7d': 7 * 24 * 3600 * 1000, '30d': 30 * 24 * 3600 * 1000 };

function pinAtivo(chat) {
  if (!chat || !chat.pinnedMessageId) return null;
  if (chat.pinnedUntil && Date.now() >= chat.pinnedUntil) {
    chat.pinnedMessageId = null;
    chat.pinnedUntil = null;
    return null;
  }
  return chat.pinnedMessageId;
}

app.post('/api/chats/:chatId/pin', (req, res) => {
  const { chatId } = req.params;
  const { userId, messageId, duration } = req.body || {};
  if (!userId || !messageId) return res.status(400).json({ error: 'Dados incompletos.' });
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || !chat.members.includes(userId)) return res.status(404).json({ error: 'Conversa não encontrada.' });
  const msg = db.messages.find(m => m.id === messageId && m.chatId === chatId && !m.deleted && m.type !== 'system');
  if (!msg) return res.status(404).json({ error: 'Mensagem não encontrada.' });

  const jaFixada = pinAtivo(chat) === messageId;
  let pinned = !jaFixada;
  let pinnedUntil = null;
  if (pinned) {
    const ms = DURACOES_FIXAR_MS[duration];
    if (!ms) return res.status(400).json({ error: 'Escolha por quanto tempo fixar (24 horas, 7 dias ou 30 dias).' });
    pinnedUntil = Date.now() + ms;
    chat.pinnedMessageId = messageId;
    chat.pinnedUntil = pinnedUntil;
  } else {
    chat.pinnedMessageId = null;
    chat.pinnedUntil = null;
  }
  saveDB(db);
  io.to('chat:' + chatId).emit('message_pin_updated', { chatId, messageId, pinned, pinnedUntil });
  res.json({ ok: true, pinned, messageId, pinnedUntil });
});

app.post('/api/messages/:messageId/reaction', (req, res) => {
  const { messageId } = req.params;
  const { userId, emoji } = req.body || {};
  if (!userId || !EMOJIS_REACAO_PERMITIDOS.has(emoji)) return res.status(400).json({ error: 'Reação inválida.' });
  const db = loadDB();
  const msg = db.messages.find(m => m.id === messageId && !m.deleted && m.type !== 'system');
  if (!msg) return res.status(404).json({ error: 'Mensagem não encontrada.' });
  const chat = db.chats.find(c => c.id === msg.chatId);
  if (!chat || !chat.members.includes(userId)) return res.status(403).json({ error: 'Sem acesso a essa conversa.' });
  if (!Array.isArray(msg.reactions)) msg.reactions = [];
  const existing = msg.reactions.find(r => r.userId === userId);
  if (existing && existing.emoji === emoji) {
    msg.reactions = msg.reactions.filter(r => r.userId !== userId);
  } else if (existing) {
    existing.emoji = emoji;
    existing.updatedAt = Date.now();
  } else {
    msg.reactions.push({ userId, emoji, updatedAt: Date.now() });
  }
  saveDB(db);
  const payload = { chatId: msg.chatId, messageId, reactions: msg.reactions };
  io.to('chat:' + msg.chatId).emit('message_reactions_updated', payload);
  res.json({ ok: true, reactions: msg.reactions });
});

app.get('/api/chats', (req, res) => {
  const { userId, view } = req.query;
  const db = loadDB();

  const chats = db.chats.filter(c => {
    const isArchived = Array.isArray(c.archivedBy) && c.archivedBy.includes(userId);
    if ((view === 'archived') !== isArchived) return false;
    if (c.type === 'private' && c.hiddenAt && c.hiddenAt[userId]) {
      // apaguei essa conversa: só volta pra lista se chegou mensagem depois disso
      return db.messages.some(m => m.chatId === c.id && m.createdAt > c.hiddenAt[userId]);
    }
    if (c.members.includes(userId)) return true;
    // grupo do qual a pessoa foi removida: continua na lista, em modo fantasma
    return (c.removedMembers || []).some(r => r.userId === userId);
  });

  const resultado = chats.map(c => {
    let displayName = c.name;
    let displayPhoto = c.type === 'group' ? (c.photoUrl || null) : null;
    let otherUserId = null;
    let otherEmail = null;
    let ehAutoConversa = false;

    const souMembro = c.members.includes(userId);
    const registroRemocao = !souMembro
      ? (c.removedMembers || []).find(r => r.userId === userId)
      : null;
    const removidoDoGrupo = !!registroRemocao;

    if (c.type === 'private') {
      ehAutoConversa = c.members.every(m => m === userId);
      if (ehAutoConversa) {
        displayName = '(você)';
        otherUserId = userId;
        const eu = db.users.find(u => u.id === userId);
        otherEmail = eu ? eu.email : null;
        displayPhoto = eu ? (eu.photoUrl || null) : null;
      } else {
        otherUserId = c.members.find(m => m !== userId);
        const other = db.users.find(u => u.id === otherUserId);
        displayName = other ? other.username : 'Usuário removido';
        otherEmail = other ? other.email : null;
        displayPhoto = other ? fotoParaViewer(db, other, userId) : null;
      }
    }

    // em modo fantasma, só enxerga (e só conta) mensagens de até o momento da remoção
    const jaEntrouEm = c.type === 'group'
      ? ((c.memberJoinedAt && c.memberJoinedAt[userId]) || 0)
      : ((c.hiddenAt && c.hiddenAt[userId]) || 0);
    const msgsDoChat = db.messages.filter(m =>
      m.chatId === c.id
      && (!removidoDoGrupo || m.createdAt <= registroRemocao.removedAt)
      && m.createdAt >= jaEntrouEm
    );
    const ultima = msgsDoChat[msgsDoChat.length - 1];

    const ultimaLeitura = db.reads[userId + '|' + c.id] || 0;
    const unreadCount = removidoDoGrupo ? 0 : msgsDoChat.filter(
      m => m.createdAt > ultimaLeitura && m.senderId !== userId
    ).length;

    return {
      id: c.id,
      type: c.type,
      name: displayName,
      photoUrl: displayPhoto,
      otherUserId,
      otherEmail,
      ehAutoConversa,
      removidoDoGrupo,
      archived: Array.isArray(c.archivedBy) && c.archivedBy.includes(userId),
      pinnedMessageId: pinAtivo(c),
      pinnedUntil: pinAtivo(c) ? (c.pinnedUntil || null) : null,
      lastMessage: ultima ? (ultima.deleted ? 'Mensagem apagada' : (ultima.type === 'sticker' ? 'Figurinha' : (['image','video'].includes(ultima.type) ? (ultima.type === 'image' ? '📷 Foto' : '🎬 Vídeo') : ultima.type === 'audio' ? '🎤 Áudio' : ultima.type === 'file' ? '📎 Arquivo' : ultima.content))) : null,
      lastMessageAt: ultima ? ultima.createdAt : null,
      unreadCount
    };
  });

  res.json({ chats: resultado });
});

// ---------- Marcar conversa como lida ----------
app.post('/api/chats/:chatId/read', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ error: 'Dados incompletos' });
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || !chat.members.includes(userId)) {
    return res.status(404).json({ error: 'Conversa não encontrada' });
  }
  db.reads[userId + '|' + chatId] = Date.now();
  saveDB(db);
  res.json({ ok: true });
});

app.get('/api/chats/:chatId/messages', (req, res) => {
  const { chatId } = req.params;
  const { userId } = req.query;
  const db = loadDB();
  if (limparMensagensExpiradas(db)) saveDB(db);
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat) return res.status(403).json({ error: 'Sem acesso a esse chat' });

  const souMembro = chat.members.includes(userId);
  const registroRemocao = !souMembro
    ? (chat.removedMembers || []).find(r => r.userId === userId)
    : null;
  if (!souMembro && !registroRemocao) {
    return res.status(403).json({ error: 'Sem acesso a esse chat' });
  }

  const mensagens = db.messages
    .filter(m => {
      if (m.chatId !== chatId) return false;
      if (!souMembro && m.createdAt > registroRemocao.removedAt) return false;
      // quem entrou no grupo depois não vê mensagens de antes de ter entrado
      const jaEntrouEm = chat.type === 'group'
        ? ((chat.memberJoinedAt && chat.memberJoinedAt[userId]) || 0)
        : ((chat.hiddenAt && chat.hiddenAt[userId]) || 0);
      return m.createdAt >= jaEntrouEm && (!m.expiresAt || m.expiresAt > Date.now());
    })
    .map(m => personalizarMensagem(m, userId, db))
    .map(m => {
      const remetente = m.senderId ? db.users.find(u => u.id === m.senderId) : null;
      return Object.assign({}, m, {
        isOwnMessage: String(m.senderId) === String(userId),
        reactions: Array.isArray(m.reactions) ? m.reactions : [],
        pinned: pinAtivo(chat) === m.id,
        pinnedUntil: pinAtivo(chat) === m.id ? (chat.pinnedUntil || null) : null,
        senderUsername: remetente ? remetente.username : (m.senderId ? 'Usuário removido' : m.senderUsername),
        senderPhotoUrl: remetente ? fotoParaViewer(db, remetente, userId) : null,
        senderIsOwner: !!(chat.type === 'group' && m.senderId && m.senderId === donoDe(chat)),
        senderIsAdmin: !!(chat.type === 'group' && m.senderId && (chat.admins || []).includes(m.senderId)),
        senderSaiuDoGrupo: !!(m.senderId && chat.type === 'group' && !chat.members.includes(m.senderId))
      });
    });
  res.json({ messages: mensagens });
});

// ---------- Mídias, links e arquivos do chat ----------
// GET /api/chats/:chatId/midias?userId=...&tipo=midia|links|arquivos
// Respeita as mesmas regras de visibilidade das mensagens (removido do grupo, entrou depois etc.).
app.get('/api/chats/:chatId/midias', (req, res) => {
  const { chatId } = req.params;
  const { userId, tipo } = req.query;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === chatId);
  if (!chat || !userId) return res.status(403).json({ error: 'Sem acesso a esse chat' });
  const souMembro = chat.members.includes(userId);
  const registroRemocao = !souMembro ? (chat.removedMembers || []).find(r => r.userId === userId) : null;
  if (!souMembro && !registroRemocao) return res.status(403).json({ error: 'Sem acesso a esse chat' });

  const jaEntrouEm = chat.type === 'group'
    ? ((chat.memberJoinedAt && chat.memberJoinedAt[userId]) || 0)
    : ((chat.hiddenAt && chat.hiddenAt[userId]) || 0);
  const regexLink = /https?:\/\/[^\s<>"']+/gi;

  const itens = [];
  for (const m of db.messages) {
    if (m.chatId !== chatId || m.deleted || m.type === 'system') continue;
    if (!souMembro && m.createdAt > registroRemocao.removedAt) continue;
    if (m.createdAt < jaEntrouEm) continue;
    const remetente = m.senderId ? db.users.find(u => u.id === m.senderId) : null;
    const base = { id: m.id, createdAt: m.createdAt, senderId: m.senderId, senderUsername: remetente ? remetente.username : 'Usuário removido' };

    if (tipo === 'links') {
      if (m.type !== 'text' || !m.content) continue;
      const achados = m.content.match(regexLink);
      if (!achados) continue;
      [...new Set(achados)].forEach(url => itens.push(Object.assign({}, base, { url: url.replace(/[).,;!?]+$/, '') })));
    } else if (tipo === 'arquivos') {
      if (m.type !== 'file' && m.type !== 'audio') continue;
      itens.push(Object.assign({}, base, { type: m.type, nome: m.content || null, mediaUrl: m.mediaUrl || null, expirada: !m.mediaUrl }));
    } else {
      if (m.type !== 'image' && m.type !== 'video') continue;
      itens.push(Object.assign({}, base, { type: m.type, mediaUrl: m.mediaUrl || null, expirada: !m.mediaUrl }));
    }
  }
  itens.sort((a, b) => b.createdAt - a.createdAt);
  res.json({ itens });
});

// ---------- Configuração ICE para chamadas WebRTC (Metered Open Relay) ----------
// Configure METERED_DOMAIN (ex.: suaapp.metered.live) e METERED_TURN_API_KEY no Railway.
// A API key do Open Relay fica no servidor e nunca é enviada ao navegador.
app.get('/api/calls/ice-config', async (req, res) => {
  try {
    const db = loadDB();
    const userId = String(req.query.userId || '');
    if (!userId || !db.users.some(u => u.id === userId)) {
      return res.status(400).json({ error: 'Usuário inválido.' });
    }

    const fallback = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
    const domain = String(process.env.METERED_DOMAIN || '').trim().replace(/^https?:\/\//i, '').replace(/\/$/, '');
    const apiKey = String(process.env.METERED_TURN_API_KEY || '').trim();
    if (!domain || !apiKey) {
      res.set('Cache-Control', 'no-store').json({ iceServers: fallback, turnConfigured: false });
      return;
    }

    // Metered recomenda consultar o endpoint de credenciais ICE da credencial Open Relay.
    const url = `https://${domain}/api/v1/turn/credentials?apiKey=${encodeURIComponent(apiKey)}`;
    const response = await fetch(url, { method: 'GET', headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(8000) });
    if (!response.ok) {
      console.error('[ICE] Metered Open Relay respondeu HTTP', response.status);
      res.set('Cache-Control', 'no-store').json({ iceServers: fallback, turnConfigured: false, turnError: 'provider_unavailable' });
      return;
    }
    const payload = await response.json();
    const provided = Array.isArray(payload) ? payload : payload.iceServers;
    const validServers = Array.isArray(provided) ? provided.filter(item => item && (typeof item.urls === 'string' || (Array.isArray(item.urls) && item.urls.length)) && (String(item.urls).startsWith('stun:') || String(item.urls).includes('turn:') || String(item.urls).includes('turns:') || (Array.isArray(item.urls) && item.urls.some(u => /^(stun|turns?):/i.test(String(u)))))) : [];
    const iceServers = [...fallback, ...validServers];
    res.set('Cache-Control', 'no-store').json({ iceServers, turnConfigured: validServers.some(item => (Array.isArray(item.urls) ? item.urls : [item.urls]).some(u => /^(turn|turns):/i.test(String(u)))) });
  } catch (err) {
    console.error('[ICE] Falha ao obter configuração do Metered Open Relay:', err.message);
    res.set('Cache-Control', 'no-store').json({ iceServers: [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }], turnConfigured: false });
  }
});

// Sessões em memória: uma chamada ativa por usuário; apenas conversas privadas são permitidas.
const activeCalls = new Map();
const busyUsers = new Map();
function outraParte(call, userId) { return call.callerId === userId ? call.calleeId : call.callerId; }
function chamadaDoSocket(socket, callId) {
  const call = activeCalls.get(String(callId || ''));
  if (!call || !socket.userId || ![call.callerId, call.calleeId].includes(socket.userId)) return null;
  if (socket.id !== call.callerSocketId && socket.id !== call.calleeSocketId) return null;
  return call;
}

// Chamadas de grupo: malha WebRTC (cada participante conecta-se aos demais).
// O estado é volátil: se o processo reiniciar, a chamada desaparece e pode ser recriada.
const activeGroupCalls = new Map();
function groupCallPublicState(call, db) {
  if (!call) return null;
  return {
    callId: call.id, chatId: call.chatId, mode: call.mode, startedAt: call.startedAt,
    participants: [...call.participants.keys()].map(userId => {
      const user = db.users.find(u => u.id === userId);
      return { userId, username: user?.username || 'Membro' };
    })
  };
}
function groupCallBroadcast(call, db) {
  const state = groupCallPublicState(call, db);
  const chat = db.chats.find(c => c.id === call.chatId);
  (chat?.members || []).forEach(id => io.to('user:' + id).emit('group:call:state', { chatId: call.chatId, call: state }));
}
function leaveGroupCall(call, userId, reason) {
  if (!call || !call.participants.has(userId)) return;
  const participant = call.participants.get(userId);
  call.participants.delete(userId);
  if (busyUsers.get(userId) === 'group:' + call.id) busyUsers.delete(userId);
  call.participants.forEach((p, otherId) => {
    io.to(p.socketId).emit('group:call:peer-left', { callId: call.id, userId, reason: reason || 'left' });
  });
  if (!call.participants.size) {
    activeGroupCalls.delete(call.id);
    const db = loadDB();
    const chat = db.chats.find(c => c.id === call.chatId);
    (chat?.members || []).forEach(id => io.to('user:' + id).emit('group:call:state', { chatId: call.chatId, call: null }));
  } else groupCallBroadcast(call, loadDB());
  return participant;
}

// ---------- Presença, recibos e digitação ----------
const socketsPorUsuario = new Map();
function usuarioEstaOnline(userId) { return !!(socketsPorUsuario.get(String(userId)) && socketsPorUsuario.get(String(userId)).size); }
function emitirPresenca(userId, online) {
  const db = loadDB();
  const user = db.users.find(u => String(u.id) === String(userId));
  if (!user) return;
  if (!online) { user.lastSeen = Date.now(); saveDB(db); }
  const payload = { userId: String(userId), online: !!online, lastSeen: user.lastSeenVisibility === false ? null : (user.lastSeen || null) };
  const recipients = new Set();
  db.chats.filter(c => (c.members || []).some(id => String(id) === String(userId))).forEach(c => (c.members || []).forEach(id => { if (String(id) !== String(userId)) recipients.add(String(id)); }));
  recipients.forEach(id => io.to('user:' + id).emit('presence:update', payload));
}
function atualizarReciboMensagem(message, kind, userId) {
  if (!message || !userId || String(message.senderId) === String(userId)) return false;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === message.chatId);
  if (!chat || !(chat.members || []).some(id => String(id) === String(userId))) return false;
  const msg = db.messages.find(m => String(m.id) === String(message.id));
  if (!msg) return false;
  msg.deliveredTo = Array.isArray(msg.deliveredTo) ? msg.deliveredTo : [];
  msg.readBy = Array.isArray(msg.readBy) ? msg.readBy : [];
  const field = kind === 'read' ? 'readBy' : 'deliveredTo';
  if (!msg[field].some(id => String(id) === String(userId))) msg[field].push(String(userId));
  if (kind === 'read' && !msg.deliveredTo.some(id => String(id) === String(userId))) msg.deliveredTo.push(String(userId));
  saveDB(db);
  const status = { messageId: msg.id, chatId: msg.chatId, senderId: msg.senderId, deliveredTo: msg.deliveredTo, readBy: msg.readBy };
  io.to('user:' + msg.senderId).emit('message:receipt', status);
  return true;
}

// ---------- Socket.io (tempo real) ----------
// Resposta rápida pela notificação do APK: envia a mensagem de verdade (mesma lógica do socket).
// Autenticação: o token FCM registrado pelo aparelho em /api/push-token.
app.post('/api/chats/:chatId/messages', (req, res) => {
  const { userId, token, content, replyTo } = req.body || {};
  const db = loadDB();
  const u = db.users.find(x => String(x.id) === String(userId));
  if (!u || !token || !Array.isArray(u.pushTokens) || !u.pushTokens.includes(String(token))) return res.status(401).json({ error: 'Não autorizado' });
  const texto = typeof content === 'string' ? content.trim() : '';
  if (!texto) return res.status(400).json({ error: 'Mensagem vazia' });
  let erro = null;
  const msg = processarEnvioMensagem({ chatId: req.params.chatId, userId: String(u.id), type: 'text', content: texto, replyTo: replyTo || null }, m => { erro = m; });
  if (!msg) return res.status(erro ? 400 : 403).json({ error: erro || 'Não foi possível enviar a mensagem' });
  res.json({ ok: true, messageId: msg.id });
});

// true quando o usuário está com o app aberto (tela visível) exatamente nessa conversa:
// nesse caso não faz sentido mandar push, a mensagem já aparece na tela.
function usuarioEstaVendoChat(userId, chatId) {
  for (const sk of io.sockets.sockets.values()) {
    if (String(sk.userId) === String(userId) && sk.appVisible && sk.appChatId === String(chatId)) return true;
  }
  return false;
}

// Envio de mensagem compartilhado entre o socket (site/APK aberto) e o endpoint HTTP (resposta pela notificação).
function processarEnvioMensagem({ chatId, userId, type, content, replyTo, mediaUrl, expiresIn, threadId, highQuality }, onError = () => {}) {
    userId = String(userId || '');
    if (!userId) return;
    const tiposComMidia = ['audio', 'video', 'image', 'file', 'sticker'];
    if (tiposComMidia.includes(type) && (typeof mediaUrl !== 'string' || !mediaUrl.trim())) {
      onError('A mídia não foi carregada. Tente enviar novamente.');
      return;
    }
    const db = loadDB();
    const chat = db.chats.find(c => c.id === chatId);
    if (!chat || !chat.members.includes(userId)) return;
    if (!podeEnviarMensagem(chat, userId)) return;

    if (chat.type === 'private') {
      const outro = chat.members.find(m => m !== userId);
      const bloqueado = db.blocks.some(b =>
        (b.userId === userId && b.blockedId === outro) ||
        (b.userId === outro && b.blockedId === userId)
      );
      if (bloqueado) return;
    }

    const expiresAt = TEMPOS_MENSAGEM_MS[expiresIn] ? Date.now() + TEMPOS_MENSAGEM_MS[expiresIn] : null;
    const message = {
      id: uuidv4(),
      chatId,
      senderId: userId,
      type: type || 'text', // 'text' | 'audio' | 'video'
      content: content || null,
      mediaUrl: mediaUrl || null,
      mediaCreatedAt: mediaUrl ? Date.now() : null,
      replyTo: replyTo || null,
      threadId: threadId || (replyTo && replyTo.id ? replyTo.id : null),
      expiresAt,
      highQuality: !!highQuality,
      createdAt: Date.now(),
      editedAt: null,
      deleted: false,
      reactions: [],
      deliveredTo: [],
      readBy: []
    };
    db.messages.push(message);
    saveDB(db);

    const remetente = db.users.find(u => u.id === userId);
    chat.members.forEach(memberId => {
      io.to('user:' + memberId).emit('new_message', Object.assign({}, message, {
        isOwnMessage: String(memberId) === String(userId),
        senderUsername: remetente ? remetente.username : 'Usuário removido',
        senderPhotoUrl: remetente ? fotoParaViewer(db, remetente, memberId) : null,
        senderIsOwner: chat.type === 'group' && userId === donoDe(chat),
        senderIsAdmin: chat.type === 'group' && (chat.admins || []).includes(userId)
      }));
    });
    chat.members.filter(memberId => String(memberId) !== String(userId) && !usuarioEstaVendoChat(memberId, message.chatId)).forEach(memberId => {
      enviarPushParaUsuario(db, memberId, {
        title: remetente?.username || 'Nova mensagem',
        body: message.type === 'text' ? (message.content || 'Nova mensagem') : 'Enviou uma mídia',
      }, { type: 'message', chatId: message.chatId, messageId: message.id, senderId: userId,
        senderName: remetente?.username || 'Contato',
        conversationName: chat.type === 'group' ? (chat.name || 'Grupo') : (remetente?.username || 'Contato'),
        messagePreview: message.type === 'text' ? (message.content || 'Nova mensagem') : 'Enviou uma mídia' });
    });
    return message;

}

io.on('connection', socket => {
  socket.on('join', ({ userId }) => {
    if (!userId) return;
    socket.userId = String(userId);
    socket.join('user:' + userId);
    const sockets = socketsPorUsuario.get(String(userId)) || new Set();
    const wasOffline = sockets.size === 0;
    sockets.add(socket.id); socketsPorUsuario.set(String(userId), sockets);
    const db = loadDB();
    const contacts = new Set();
    db.chats.filter(c => (c.members || []).some(id => String(id) === String(userId))).forEach(c => (c.members || []).forEach(id => { if (String(id) !== String(userId)) contacts.add(String(id)); }));
    contacts.forEach(id => {
      const user = db.users.find(u => String(u.id) === id);
      socket.emit('presence:update', { userId: id, online: usuarioEstaOnline(id), lastSeen: user?.lastSeen || null });
    });
    if (wasOffline) emitirPresenca(userId, true);
  });

  socket.on('presence:check', ({ userId } = {}) => {
    if (!socket.userId || !userId) return;
    const db = loadDB();
    const chat = db.chats.find(c => (c.members || []).some(id => String(id) === String(socket.userId)) && (c.members || []).some(id => String(id) === String(userId)));
    if (!chat) return;
    const user = db.users.find(u => String(u.id) === String(userId));
    socket.emit('presence:update', { userId: String(userId), online: usuarioEstaOnline(userId), lastSeen: user?.lastSeen || null });
  });

  socket.on('typing:start', ({ chatId } = {}) => {
    if (!socket.userId || !chatId) return;
    const db = loadDB(); const chat = db.chats.find(c => String(c.id) === String(chatId));
    const user = db.users.find(u => String(u.id) === String(socket.userId));
    if (user?.typingVisibility === false) return;
    if (!chat || !(chat.members || []).some(id => String(id) === String(socket.userId))) return;
    (chat.members || []).filter(id => String(id) !== String(socket.userId)).forEach(id => io.to('user:' + id).emit('typing:update', { chatId, userId: socket.userId, typing: true }));
  });
  socket.on('typing:stop', ({ chatId } = {}) => {
    if (!socket.userId || !chatId) return;
    const db = loadDB(); const chat = db.chats.find(c => String(c.id) === String(chatId));
    const user = db.users.find(u => String(u.id) === String(socket.userId));
    if (user?.typingVisibility === false) return;
    if (!chat || !(chat.members || []).some(id => String(id) === String(socket.userId))) return;
    (chat.members || []).filter(id => String(id) !== String(socket.userId)).forEach(id => io.to('user:' + id).emit('typing:update', { chatId, userId: socket.userId, typing: false }));
  });

  socket.on('message:delivered', ({ messageId } = {}) => {
    if (!socket.userId || !messageId) return;
    const db = loadDB(); const msg = db.messages.find(m => String(m.id) === String(messageId));
    if (msg) atualizarReciboMensagem(msg, 'delivered', socket.userId);
  });
  socket.on('message:read', ({ chatId } = {}) => {
    if (!socket.userId || !chatId) return;
    const db = loadDB(); const chat = db.chats.find(c => String(c.id) === String(chatId));
    const user = db.users.find(u => String(u.id) === String(socket.userId));
    if (user?.readReceipts === false) return;
    if (!chat || !(chat.members || []).some(id => String(id) === String(socket.userId))) return;
    db.messages.filter(m => String(m.chatId) === String(chatId) && String(m.senderId) !== String(socket.userId)).forEach(m => atualizarReciboMensagem(m, 'read', socket.userId));
  });

  socket.on('join_chat', chatId => {
    // quem foi removido do grupo pode continuar lendo o histórico (via REST),
    // mas não deve receber mensagem nova em tempo real — então nem entra nessa room.
    const db = loadDB();
    const chat = db.chats.find(c => c.id === chatId);
    if (!chat || !socket.userId || !chat.members.includes(socket.userId)) return;
    socket.join('chat:' + chatId);
  });

  socket.on('call:invite', async ({ chatId, callId, mode } = {}) => {
    const db = loadDB();
    const chat = db.chats.find(c => c.id === chatId);
    const callerId = socket.userId;
    if (!callerId || !db.users.some(u => u.id === callerId)) return socket.emit('call:error', { message: 'Sua sessão não está pronta para chamadas.' });
    if (!chat || chat.type !== 'private' || !Array.isArray(chat.members) || !chat.members.includes(callerId) || chat.members.length !== 2) return socket.emit('call:error', { message: 'Chamadas estão disponíveis apenas em conversas individuais.' });
    const calleeId = chat.members.find(id => id !== callerId);
    if (!calleeId || calleeId === callerId) return socket.emit('call:error', { message: 'Não é possível ligar para esta conversa.' });
    if (db.blocks.some(b => (b.userId === callerId && b.blockedId === calleeId) || (b.userId === calleeId && b.blockedId === callerId))) return socket.emit('call:error', { message: 'A chamada não pode ser iniciada porque existe um bloqueio entre as contas.' });
    if (!['audio', 'video'].includes(mode)) return socket.emit('call:error', { message: 'Tipo de chamada inválido.' });
    if (busyUsers.has(callerId) || busyUsers.has(calleeId)) return socket.emit('call:busy', { message: busyUsers.has(calleeId) ? 'Este usuário já está em outra chamada.' : 'Você já está em outra chamada.' });
    const recipientSockets = await io.in('user:' + calleeId).fetchSockets();
    const recipientSocket = recipientSockets.find(s => s.id !== socket.id) || null;
    // A chamada não depende mais de o destinatário estar conectado: o FCM acorda
    // o APK e o destinatário retoma a sessão pelo callId ao tocar em Atender.
    const id = String(callId || uuidv4());
    if (activeCalls.has(id)) return socket.emit('call:error', { message: 'Não foi possível iniciar esta chamada. Tente novamente.' });
    const caller = db.users.find(u => u.id === callerId);
    const call = { id, chatId, mode, callerId, calleeId, callerSocketId: socket.id, calleeSocketId: recipientSocket?.id || null, accepted: false, createdAt: Date.now() };
    activeCalls.set(id, call); busyUsers.set(callerId, id); busyUsers.set(calleeId, id);
    socket.emit('call:outgoing', { callId: id, chatId, mode, peerId: calleeId, peerName: db.users.find(u => u.id === calleeId)?.username || 'Contato' });
    if (recipientSocket) recipientSocket.emit('call:incoming', { callId: id, chatId, mode, callerId, callerName: caller ? caller.username : 'Contato', callerPhotoUrl: caller ? fotoParaViewer(db, caller, calleeId) : null });
    enviarPushParaUsuario(db, calleeId, {
      title: mode === 'video' ? 'Chamada de vídeo recebida' : 'Chamada de áudio recebida',
      body: `${caller ? caller.username : 'Contato'} está ligando`,
    }, { type: 'call', callId: id, chatId, mode, callerId, callerName: caller?.username || 'Contato' });
  });

  socket.on('call:resume', ({ callId } = {}) => {
    const call = activeCalls.get(String(callId || ''));
    if (!call || call.calleeId !== socket.userId || call.accepted) return;
    call.calleeSocketId = socket.id;
    const db = loadDB(); const caller = db.users.find(u => u.id === call.callerId);
    socket.emit('call:incoming', { callId: call.id, chatId: call.chatId, mode: call.mode, callerId: call.callerId, callerName: caller?.username || 'Contato', callerPhotoUrl: caller ? fotoParaViewer(db, caller, call.calleeId) : null });
  });

  socket.on('call:accept', ({ callId } = {}) => {
    const call = activeCalls.get(String(callId || ''));
    if (!call || call.calleeId !== socket.userId || (call.calleeSocketId && call.calleeSocketId !== socket.id) || call.accepted) return;
    call.calleeSocketId = socket.id;
    call.accepted = true;
    io.to(call.callerSocketId).emit('call:accepted', { callId: call.id, peerId: call.calleeId });
    socket.emit('call:accepted-local', { callId: call.id, peerId: call.callerId, mode: call.mode });
  });

  socket.on('call:reject', ({ callId } = {}) => {
    const call = chamadaDoSocket(socket, callId);
    if (!call || call.calleeId !== socket.userId) return;
    if (call.calleeSocketId !== socket.id) return;
    const callerId = call.callerId;
    activeCalls.delete(call.id); if (busyUsers.get(call.callerId) === call.id) busyUsers.delete(call.callerId); if (busyUsers.get(call.calleeId) === call.id) busyUsers.delete(call.calleeId);
    enviarPushFimDeChamada(loadDB(), callerId, call.id, 'rejected');
    io.to(call.callerSocketId).emit('call:rejected', { callId: call.id });
  });

  socket.on('call:cancel', ({ callId } = {}) => {
    const call = chamadaDoSocket(socket, callId);
    if (!call || call.callerId !== socket.userId) return;
    const calleeId = call.calleeId;
    activeCalls.delete(call.id); if (busyUsers.get(call.callerId) === call.id) busyUsers.delete(call.callerId); if (busyUsers.get(call.calleeId) === call.id) busyUsers.delete(call.calleeId);
    enviarPushFimDeChamada(loadDB(), calleeId, call.id, 'cancelled');
    io.to(call.calleeSocketId || ('user:' + calleeId)).emit('call:cancelled', { callId: call.id });
  });

  socket.on('call:end', ({ callId } = {}) => {
    const call = chamadaDoSocket(socket, callId);
    if (!call) return;
    const otherId = outraParte(call, socket.userId);
    activeCalls.delete(call.id); if (busyUsers.get(call.callerId) === call.id) busyUsers.delete(call.callerId); if (busyUsers.get(call.calleeId) === call.id) busyUsers.delete(call.calleeId);
    enviarPushFimDeChamada(loadDB(), otherId, call.id, 'ended');
    io.to((socket.userId === call.callerId ? call.calleeSocketId : call.callerSocketId) || ('user:' + otherId)).emit('call:ended', { callId: call.id });
  });

  socket.on('call:signal', ({ callId, kind, data } = {}) => {
    const call = chamadaDoSocket(socket, callId);
    if (!call || !call.accepted || !['offer', 'answer', 'ice'].includes(kind)) return;
    if (kind === 'offer' && socket.userId !== call.callerId) return;
    if (kind === 'answer' && socket.userId !== call.calleeId) return;
    const otherId = outraParte(call, socket.userId);
    const payload = { callId: call.id, fromUserId: socket.userId, kind, data };
    io.to((socket.userId === call.callerId ? call.calleeSocketId : call.callerSocketId) || ('user:' + otherId)).emit('call:signal', payload);
  });

  socket.on('disconnect', () => {
    const disconnectedUserId = socket.userId;
    if (disconnectedUserId && socketsPorUsuario.has(String(disconnectedUserId))) {
      const sockets = socketsPorUsuario.get(String(disconnectedUserId));
      sockets.delete(socket.id);
      if (!sockets.size) { socketsPorUsuario.delete(String(disconnectedUserId)); emitirPresenca(disconnectedUserId, false); }
    }
    for (const groupCall of [...activeGroupCalls.values()]) {
      const userId = socket.userId;
      if (userId && groupCall.participants.get(userId)?.socketId === socket.id) leaveGroupCall(groupCall, userId, 'disconnect');
    }
    for (const call of activeCalls.values()) {
      if ((call.callerSocketId === socket.id || call.calleeSocketId === socket.id) && call.accepted) {
        const otherId = outraParte(call, socket.userId);
        activeCalls.delete(call.id); if (busyUsers.get(call.callerId) === call.id) busyUsers.delete(call.callerId); if (busyUsers.get(call.calleeId) === call.id) busyUsers.delete(call.calleeId);
        enviarPushFimDeChamada(loadDB(), otherId, call.id, 'disconnect');
        io.to((socket.userId === call.callerId ? call.calleeSocketId : call.callerSocketId) || ('user:' + otherId)).emit('call:ended', { callId: call.id, reason: 'disconnect' });
      } else if (call.callerSocketId === socket.id || call.calleeSocketId === socket.id) {
        const otherId = call.callerSocketId === socket.id ? call.calleeId : call.callerId;
        const targetSocketId = call.callerSocketId === socket.id ? call.calleeSocketId : call.callerSocketId;
        activeCalls.delete(call.id); if (busyUsers.get(call.callerId) === call.id) busyUsers.delete(call.callerId); if (busyUsers.get(call.calleeId) === call.id) busyUsers.delete(call.calleeId);
        enviarPushFimDeChamada(loadDB(), otherId, call.id, 'cancelled');
        io.to(targetSocketId || ('user:' + otherId)).emit('call:cancelled', { callId: call.id });
      }
    }
  });

  socket.on('group:call:get-state', ({ chatId } = {}) => {
    const db = loadDB(); const chat = db.chats.find(c => String(c.id) === String(chatId));
    if (!socket.userId || !chat || chat.type !== 'group' || !chat.members.includes(socket.userId)) return;
    const call = [...activeGroupCalls.values()].find(c => c.chatId === chatId);
    socket.emit('group:call:state', { chatId, call: groupCallPublicState(call, db) });
  });

  socket.on('group:call:start', ({ chatId, mode } = {}) => {
    const db = loadDB(); const chat = db.chats.find(c => String(c.id) === String(chatId)); const userId = socket.userId;
    if (!userId || !chat || chat.type !== 'group' || !chat.members.includes(userId) || !socket.rooms.has('chat:' + chatId)) return socket.emit('group:call:error', { message: 'Você precisa ser membro do grupo para iniciar uma chamada.' });
    if (!['audio', 'video'].includes(mode)) return socket.emit('group:call:error', { message: 'Tipo de chamada inválido.' });
    if (busyUsers.has(userId)) return socket.emit('group:call:error', { message: 'Você já está em outra chamada.' });
    const existing = [...activeGroupCalls.values()].find(c => c.chatId === chatId);
    if (existing) return socket.emit('group:call:state', { chatId, call: groupCallPublicState(existing, db) });
    const id = 'gcall-' + uuidv4();
    const call = { id, chatId, mode, startedAt: Date.now(), participants: new Map([[userId, { socketId: socket.id, joinedAt: Date.now() }]]) };
    activeGroupCalls.set(id, call); busyUsers.set(userId, 'group:' + id);
    socket.emit('group:call:joined', { callId: id, chatId, mode, startedAt: call.startedAt, peers: [] });
    groupCallBroadcast(call, db);
  });

  socket.on('group:call:join', ({ chatId } = {}) => {
    const db = loadDB(); const chat = db.chats.find(c => String(c.id) === String(chatId)); const userId = socket.userId;
    if (!userId || !chat || chat.type !== 'group' || !chat.members.includes(userId)) return socket.emit('group:call:error', { message: 'Você não faz parte deste grupo.' });
    const call = [...activeGroupCalls.values()].find(c => c.chatId === chatId);
    if (!call) return socket.emit('group:call:state', { chatId, call: null });
    if (busyUsers.has(userId) && busyUsers.get(userId) !== 'group:' + call.id) return socket.emit('group:call:error', { message: 'Você já está em outra chamada.' });
    const jaParticipava = call.participants.has(userId);
    const peers = [...call.participants.keys()].filter(peerId => peerId !== userId).map(peerId => {
      const u = db.users.find(x => x.id === peerId);
      return { userId: peerId, username: u?.username || 'Membro' };
    });
    call.participants.set(userId, { socketId: socket.id, joinedAt: call.participants.get(userId)?.joinedAt || Date.now() });
    busyUsers.set(userId, 'group:' + call.id);
    call.participants.forEach((participant, peerId) => {
      if (peerId !== userId) io.to(participant.socketId).emit('group:call:peer-joined', { callId: call.id, userId, username: db.users.find(u => u.id === userId)?.username || 'Membro' });
    });
    socket.emit('group:call:joined', { callId: call.id, chatId, mode: call.mode, startedAt: call.startedAt, peers });
    if (!jaParticipava) groupCallBroadcast(call, db);
  });

  socket.on('group:call:leave', ({ callId } = {}) => {
    const call = activeGroupCalls.get(String(callId || ''));
    if (!call || !socket.userId || call.participants.get(socket.userId)?.socketId !== socket.id) return;
    leaveGroupCall(call, socket.userId, 'left');
    socket.emit('group:call:left', { callId: call.id });
  });

  socket.on('group:call:signal', ({ callId, toUserId, kind, data } = {}) => {
    const call = activeGroupCalls.get(String(callId || ''));
    if (!call || !socket.userId || !call.participants.has(socket.userId) || !call.participants.has(toUserId)) return;
    if (!['offer', 'answer', 'ice'].includes(kind) || !data) return;
    const target = call.participants.get(toUserId);
    io.to(target.socketId).emit('group:call:signal', { callId: call.id, fromUserId: socket.userId, kind, data });
  });

  socket.on('send_message', (payload) => {
    payload = payload || {};
    // Nunca confiar no userId enviado pelo cliente: o socket autenticado é o remetente real.
    processarEnvioMensagem(Object.assign({}, payload, { userId: String(socket.userId || payload.userId || '') }),
      m => socket.emit('send_message_error', { message: m }));
  });

  // O app informa se a tela está visível e qual conversa está aberta (evita push de quem já está lendo).
  socket.on('app:foreground', ({ visible, chatId } = {}) => {
    socket.appVisible = !!visible;
    socket.appChatId = visible && chatId ? String(chatId) : null;
  });

  socket.on('edit_message', ({ messageId, userId, newContent }) => {
    const db = loadDB();
    const msg = db.messages.find(m => m.id === messageId);
    if (!msg || msg.senderId !== userId || msg.deleted) return;
    if (Date.now() - msg.createdAt > LIMITE_EDICAO_MS) return; // passou de 1 min

    msg.content = newContent;
    msg.editedAt = Date.now();
    saveDB(db);

    io.to('chat:' + msg.chatId).emit('message_edited', msg);
  });

  socket.on('delete_message', ({ messageId, userId }) => {
    const db = loadDB();
    const msg = db.messages.find(m => m.id === messageId);
    if (!msg || msg.senderId !== userId) return;

    if (msg.mediaUrl) {
      apagarArquivo(msg.mediaUrl);
    }

    msg.deleted = true;
    msg.content = null;
    msg.mediaUrl = null;
    saveDB(db);

    io.to('chat:' + msg.chatId).emit('message_deleted', { id: msg.id });
  });
});

// ---------- Limpeza automática de mídia com mais de 12h ----------
function limparMidiaAntiga() {
  const db = loadDB();
  let mudou = limparMensagensExpiradas(db);
  db.messages.forEach(m => {
    if (m.mediaUrl && m.mediaCreatedAt && Date.now() - m.mediaCreatedAt > VIDA_MIDIA_MS) {
      apagarArquivo(m.mediaUrl);
      m.mediaUrl = null;
      m.mediaExpired = true;
      mudou = true;
    }
  });
  if (mudou) saveDB(db);
}
setInterval(limparMidiaAntiga, 30 * 60 * 1000); // checa a cada 30 min

// ---------- Preferências e recursos avançados de conversa ----------
app.get('/api/chats/:chatId/preferences', (req, res) => {
  const db = loadDB(); const chat = db.chats.find(c => c.id === req.params.chatId);
  const userId = String(req.query.userId || '');
  if (!chat || !chat.members.includes(userId)) return res.status(403).json({ error: 'Sem acesso a esse chat.' });
  res.json({ preferences: (chat.userPreferences && chat.userPreferences[userId]) || { mutedUntil: null, pinned: false, ephemeral: null } });
});

app.patch('/api/chats/:chatId/preferences', (req, res) => {
  const db = loadDB(); const chat = db.chats.find(c => c.id === req.params.chatId);
  const userId = String(req.body?.userId || '');
  if (!chat || !chat.members.includes(userId)) return res.status(403).json({ error: 'Sem acesso a esse chat.' });
  if (!chat.userPreferences) chat.userPreferences = {};
  const atual = chat.userPreferences[userId] || {};
  const body = req.body || {};
  if (body.mutedUntil !== undefined) atual.mutedUntil = body.mutedUntil ? Number(body.mutedUntil) : null;
  if (body.pinned !== undefined) atual.pinned = !!body.pinned;
  if (body.ephemeral === null || ['1h','8h','24h','7d'].includes(body.ephemeral)) atual.ephemeral = body.ephemeral;
  chat.userPreferences[userId] = atual; saveDB(db); res.json({ ok: true, preferences: atual });
});

app.get('/api/search/messages', (req, res) => {
  const db = loadDB(); const userId = String(req.query.userId || '');
  const q = String(req.query.q || '').trim().toLowerCase();
  if (!userId || !q) return res.json({ messages: [] });
  const from = req.query.from ? Number(req.query.from) : 0; const to = req.query.to ? Number(req.query.to) : Date.now();
  const tipo = req.query.type ? String(req.query.type) : '';
  const chatIds = new Set(db.chats.filter(c => (c.members || []).some(id => String(id) === userId)).map(c => c.id));
  const messages = db.messages.filter(m => chatIds.has(m.chatId) && !m.deleted && m.createdAt >= from && m.createdAt <= to && (!tipo || m.type === tipo) && [m.content, m.mediaUrl].some(v => String(v || '').toLowerCase().includes(q))).slice(-100).reverse();
  res.json({ messages });
});

app.patch('/api/users/:userId/status', (req, res) => {
  const db = loadDB(); const user = db.users.find(u => String(u.id) === String(req.params.userId));
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado.' });
  const b = req.body || {}; if (b.statusText !== undefined) user.statusText = String(b.statusText).slice(0, 120);
  if (b.readReceipts !== undefined) user.readReceipts = !!b.readReceipts;
  if (b.typingVisibility !== undefined) user.typingVisibility = !!b.typingVisibility;
  if (b.lastSeenVisibility !== undefined) user.lastSeenVisibility = !!b.lastSeenVisibility;
  saveDB(db); res.json({ ok: true, user: { id: user.id, statusText: user.statusText || '', readReceipts: user.readReceipts !== false, typingVisibility: user.typingVisibility !== false, lastSeenVisibility: user.lastSeenVisibility !== false } });
});

app.post('/api/chats/:chatId/polls', (req, res) => {
  const db = loadDB(); const chat = db.chats.find(c => c.id === req.params.chatId); const userId = String(req.body?.userId || '');
  const question = String(req.body?.question || '').trim(); const options = Array.isArray(req.body?.options) ? req.body.options.map(x => String(x).trim()).filter(Boolean).slice(0, 10) : [];
  if (!chat || !chat.members.includes(userId) || !question || options.length < 2) return res.status(400).json({ error: 'Enquete inválida.' });
  const message = { id: uuidv4(), chatId: chat.id, senderId: userId, type: 'poll', content: question, poll: { question, options: options.map((text, index) => ({ id: String(index), text, votes: [] })), multiple: !!req.body.multiple }, createdAt: Date.now(), editedAt: null, deleted: false, reactions: [], deliveredTo: [], readBy: [] };
  db.messages.push(message); saveDB(db); io.to('chat:' + chat.id).emit('new_message', message); res.json({ ok: true, message });
});

app.post('/api/messages/:messageId/vote', (req, res) => {
  const db = loadDB(); const msg = db.messages.find(m => m.id === req.params.messageId && m.type === 'poll'); const userId = String(req.body?.userId || '');
  const chat = msg && db.chats.find(c => c.id === msg.chatId); const optionId = String(req.body?.optionId || '');
  if (!msg || !chat || !chat.members.includes(userId)) return res.status(403).json({ error: 'Sem acesso.' });
  const option = (msg.poll.options || []).find(o => o.id === optionId); if (!option) return res.status(400).json({ error: 'Opção inválida.' });
  msg.poll.options.forEach(o => { o.votes = (o.votes || []).filter(id => id !== userId); }); option.votes.push(userId); saveDB(db); io.to('chat:' + msg.chatId).emit('poll_updated', { messageId: msg.id, poll: msg.poll }); res.json({ ok: true, poll: msg.poll });
});


// ==========================================================================
//  PAINEL ADMIN
// ==========================================================================
const ADMIN_KEY = process.env.ADMIN_KEY || 'chatdevs-admin-2024';

function checkAdmin(req, res) {
  const key = req.headers['x-admin-key'] || req.query.key;
  if (key !== ADMIN_KEY) { res.status(401).json({ error: 'Não autorizado' }); return false; }
  return true;
}

// ── Novidades ──────────────────────────────────────────────────────────────
app.get('/api/novidades', (req, res) => {
  const db = loadDB();
  res.json({ novidades: db.novidades || [] });
});

app.post('/api/admin/novidades', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const { titulo, texto, imageUrl } = req.body;
  if (!titulo || !texto) return res.status(400).json({ error: 'Título e texto são obrigatórios' });
  const db = loadDB();
  if (!db.novidades) db.novidades = [];
  const nova = { id: uuidv4(), titulo, texto, imageUrl: imageUrl || null, criadaEm: Date.now() };
  db.novidades.unshift(nova);
  saveDB(db);
  res.json({ ok: true, novidade: nova });
});

app.put('/api/admin/novidades/:id', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  if (!db.novidades) db.novidades = [];
  const n = db.novidades.find(x => x.id === req.params.id);
  if (!n) return res.status(404).json({ error: 'Não encontrada' });
  const { titulo, texto, imageUrl } = req.body;
  if (titulo) n.titulo = titulo;
  if (texto) n.texto = texto;
  if (imageUrl !== undefined) n.imageUrl = imageUrl || null;
  n.editadaEm = Date.now();
  saveDB(db);
  res.json({ ok: true, novidade: n });
});

app.delete('/api/admin/novidades/:id', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  db.novidades = (db.novidades || []).filter(x => x.id !== req.params.id);
  saveDB(db);
  res.json({ ok: true });
});

// ── Grupos ─────────────────────────────────────────────────────────────────
// ── Helpers do painel ──────────────────────────────────────────────────────
const TIPOS_ADMIN = { text: 'texto', image: 'foto', video: 'video', audio: 'audio', file: 'arquivo' };
const DIA_MS = 24 * 60 * 60 * 1000;
function mensagensReais(db) { return (db.messages || []).filter(m => m.type !== 'system' && m.senderId); }
function inicioDoDia(ts) { const d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); }
function ehConversaConsigo(c) { return c.type === 'private' && (c.members || []).length === 2 && c.members[0] === c.members[1]; }
// conversa privada entre duas contas que ainda existem (ignora conversa consigo mesmo e com conta removida)
function privadaValida(db, c) {
  return c.type === 'private' && !ehConversaConsigo(c) && (c.members || []).length === 2
    && c.members.every(id => db.users.some(u => u.id === id));
}
function cargoNoGrupo(chat, userId) {
  if (userId === donoDe(chat)) return 'dono';
  return (chat.admins || []).includes(userId) ? 'admin' : 'membro';
}

// ── Visão geral (números, gráficos, rankings e atividade) ──────────────────
app.get('/api/admin/resumo', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const dias = Math.max(7, Math.min(90, parseInt(req.query.dias, 10) || 14));
  const agora = Date.now();
  const hoje0 = inicioDoDia(agora);
  const inicio = hoje0 - (dias - 1) * DIA_MS;
  const msgs = mensagensReais(db);
  const usuarios = db.users || [];
  const porId = new Map(usuarios.map(u => [u.id, u]));
  const chatPorId = new Map((db.chats || []).map(c => [c.id, c]));

  const serieMsgs = new Array(dias).fill(0);
  const serieCad = new Array(dias).fill(0);
  const tipos = { texto: 0, foto: 0, video: 0, audio: 0, arquivo: 0 };
  const msgsPorGrupo = {}, msgsPorUser = {};
  const ativosHojeSet = new Set(), ativos7dSet = new Set();
  let mensagensHoje = 0;

  msgs.forEach(m => {
    const t = m.createdAt || 0;
    const i = Math.floor((inicioDoDia(t) - inicio) / DIA_MS);
    if (i >= 0 && i < dias) serieMsgs[i]++;
    const k = TIPOS_ADMIN[m.type] || 'texto';
    tipos[k]++;
    if (t >= hoje0) { mensagensHoje++; ativosHojeSet.add(m.senderId); }
    if (t >= agora - 7 * DIA_MS) ativos7dSet.add(m.senderId);
    msgsPorUser[m.senderId] = (msgsPorUser[m.senderId] || 0) + 1;
    msgsPorGrupo[m.chatId] = (msgsPorGrupo[m.chatId] || 0) + 1;
  });

  let cadastrosSemData = 0;
  usuarios.forEach(u => {
    if (!u.createdAt) { cadastrosSemData++; return; }
    const i = Math.floor((inicioDoDia(u.createdAt) - inicio) / DIA_MS);
    if (i >= 0 && i < dias) serieCad[i]++;
  });

  const online = usuarios.filter(u => usuarioEstaOnline(u.id));
  online.forEach(u => ativosHojeSet.add(u.id));
  const grupos = (db.chats || []).filter(c => c.type === 'group');

  const topGrupos = grupos
    .map(c => ({ id: c.id, nome: c.name, mensagens: msgsPorGrupo[c.id] || 0 }))
    .filter(g => g.mensagens > 0).sort((a, b) => b.mensagens - a.mensagens).slice(0, 5);
  const topUsuarios = Object.entries(msgsPorUser)
    .map(([id, n]) => { const u = porId.get(id); return u ? { id, username: u.username, mensagens: n } : null; })
    .filter(Boolean).sort((a, b) => b.mensagens - a.mensagens).slice(0, 5);

  const atividade = [];
  msgs.slice(-40).forEach(m => {
    const u = porId.get(m.senderId), c = chatPorId.get(m.chatId);
    if (!u) return;
    const onde = c && c.type === 'group' ? `no grupo "${c.name}"` : 'numa conversa privada';
    const oque = { text: 'uma mensagem', image: 'uma foto', video: 'um vídeo', audio: 'um áudio', file: 'um arquivo' }[m.type] || 'uma mensagem';
    atividade.push({ tipo: 'mensagem', texto: `${u.username} enviou ${oque} ${onde}`, quando: m.createdAt });
  });
  usuarios.filter(u => u.createdAt).sort((a, b) => b.createdAt - a.createdAt).slice(0, 15)
    .forEach(u => atividade.push({ tipo: 'cadastro', texto: `${u.username} criou uma conta`, quando: u.createdAt }));
  grupos.filter(c => c.createdAt).sort((a, b) => b.createdAt - a.createdAt).slice(0, 15).forEach(c => {
    const dono = porId.get(donoDe(c));
    atividade.push({ tipo: 'grupo', texto: `Grupo "${c.name}" criado${dono ? ' por ' + dono.username : ''}`, quando: c.createdAt });
  });
  atividade.sort((a, b) => b.quando - a.quando);

  res.json({
    dias,
    totais: {
      usuarios: usuarios.length,
      bloqueados: usuarios.filter(u => u.bloqueadoAdmin).length,
      online: online.length,
      ativosHoje: ativosHojeSet.size,
      grupos: grupos.length,
      gruposTrancados: grupos.filter(c => c.trancado).length,
      conversasPrivadas: (db.chats || []).filter(c => privadaValida(db, c)).length,
      mensagens: msgs.length,
      mensagensHoje,
      ativos7d: ativos7dSet.size,
      cadastrosSemData
    },
    serie: { inicio, mensagens: serieMsgs, cadastros: serieCad },
    tipos, topGrupos, topUsuarios,
    atividade: atividade.slice(0, 40)
  });
});

app.get('/api/admin/grupos', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const contagem = {}, ultima = {};
  mensagensReais(db).forEach(m => {
    contagem[m.chatId] = (contagem[m.chatId] || 0) + 1;
    if (!ultima[m.chatId] || m.createdAt > ultima[m.chatId]) ultima[m.chatId] = m.createdAt;
  });
  const grupos = db.chats
    .filter(c => c.type === 'group')
    .map(c => {
      const dono = db.users.find(u => u.id === donoDe(c));
      return {
        id: c.id,
        name: c.name,
        description: c.description || '',
        photoUrl: c.photoUrl || null,
        membros: (c.members || []).length,
        mensagens: contagem[c.id] || 0,
        ultimaAtividade: ultima[c.id] || null,
        trancado: !!c.trancado,
        emailDono: dono ? dono.email : 'desconhecido',
        usernameDono: dono ? dono.username : 'desconhecido',
        criadoEm: c.createdAt || null
      };
    });
  res.json({ grupos });
});

// detalhes de um grupo (janela "Detalhes")
app.get('/api/admin/grupos/:chatId', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === req.params.chatId && c.type === 'group');
  if (!chat) return res.status(404).json({ error: 'Grupo não encontrado' });
  const msgs = mensagensReais(db).filter(m => m.chatId === chat.id);
  const membros = (chat.members || []).map(id => {
    const u = db.users.find(x => x.id === id);
    return u ? { id: u.id, username: u.username, email: u.email, photoUrl: u.photoUrl || null, cargo: cargoNoGrupo(chat, id) } : null;
  }).filter(Boolean);
  const ordem = { dono: 0, admin: 1, membro: 2 };
  membros.sort((a, b) => ordem[a.cargo] - ordem[b.cargo]);
  res.json({
    id: chat.id, name: chat.name, description: chat.description || '', photoUrl: chat.photoUrl || null,
    trancado: !!chat.trancado, membros,
    mensagens: msgs.length,
    mensagens7d: msgs.filter(m => m.createdAt >= Date.now() - 7 * DIA_MS).length,
    criadoEm: chat.createdAt || null
  });
});

app.post('/api/admin/grupos/:chatId/trancar', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const chat = db.chats.find(c => c.id === req.params.chatId);
  if (!chat) return res.status(404).json({ error: 'Grupo não encontrado' });
  chat.trancado = !chat.trancado;
  chat.modoEnvio = chat.trancado ? 'dono' : 'todos';
  saveDB(db);
  res.json({ ok: true, trancado: chat.trancado });
});

app.delete('/api/admin/grupos/:chatId', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  db.chats = db.chats.filter(c => c.id !== req.params.chatId);
  db.messages = db.messages.filter(m => m.chatId !== req.params.chatId);
  saveDB(db);
  res.json({ ok: true });
});

// ── Membros ────────────────────────────────────────────────────────────────
app.get('/api/admin/membros', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const contagem = {}, ultima = {};
  mensagensReais(db).forEach(m => {
    contagem[m.senderId] = (contagem[m.senderId] || 0) + 1;
    if (!ultima[m.senderId] || m.createdAt > ultima[m.senderId]) ultima[m.senderId] = m.createdAt;
  });
  const admins = db.painelAdmins || [];
  const membros = db.users.map(u => ({
    id: u.id,
    username: u.username,
    email: u.email,
    photoUrl: u.photoUrl || null,
    bloqueado: !!u.bloqueadoAdmin,
    online: usuarioEstaOnline(u.id),
    ehAdmin: admins.includes(u.id),
    mensagens: contagem[u.id] || 0,
    grupos: db.chats.filter(c => c.type === 'group' && (c.members || []).includes(u.id)).length,
    ultimaMensagem: ultima[u.id] || null,
    criadoEm: u.createdAt || null
  }));
  res.json({ membros });
});

// detalhes de um usuário (janela "Detalhes")
app.get('/api/admin/membros/:userId', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const u = db.users.find(x => x.id === req.params.userId);
  if (!u) return res.status(404).json({ error: 'Usuário não encontrado' });
  const minhas = mensagensReais(db).filter(m => m.senderId === u.id);
  const grupos = db.chats
    .filter(c => c.type === 'group' && (c.members || []).includes(u.id))
    .map(c => ({ id: c.id, nome: c.name, cargo: cargoNoGrupo(c, u.id) }));
  res.json({
    id: u.id, username: u.username, email: u.email, photoUrl: u.photoUrl || null,
    bloqueado: !!u.bloqueadoAdmin,
    online: usuarioEstaOnline(u.id),
    ehAdmin: (db.painelAdmins || []).includes(u.id),
    mensagens: minhas.length,
    grupos,
    conversasPrivadas: db.chats.filter(c => privadaValida(db, c) && c.members.includes(u.id)).length,
    criadoEm: u.createdAt || null,
    ultimaMensagem: minhas.reduce((mx, m) => Math.max(mx, m.createdAt || 0), 0) || null,
    emailVerificado: u.emailVerified !== false
  });
});

app.post('/api/admin/membros/:userId/bloquear', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const user = db.users.find(u => u.id === req.params.userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  user.bloqueadoAdmin = !user.bloqueadoAdmin;
  saveDB(db);
  res.json({ ok: true, bloqueado: user.bloqueadoAdmin });
});

app.delete('/api/admin/membros/:userId', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  db.users = db.users.filter(u => u.id !== req.params.userId);
  // remove de todos os grupos
  db.chats.forEach(c => {
    if (c.members) c.members = c.members.filter(id => id !== req.params.userId);
    if (c.admins) c.admins = c.admins.filter(id => id !== req.params.userId);
  });
  db.messages = db.messages.filter(m => m.senderId !== req.params.userId);
  saveDB(db);
  res.json({ ok: true });
});

// ── Admins do painel ───────────────────────────────────────────────────────
app.get('/api/admin/admins', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  const admins = (db.painelAdmins || []).map(id => {
    const u = db.users.find(u => u.id === id);
    return u ? { id: u.id, username: u.username, email: u.email, photoUrl: u.photoUrl || null } : null;
  }).filter(Boolean);
  res.json({ admins });
});

app.post('/api/admin/admins/:userId', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  if (!db.painelAdmins) db.painelAdmins = [];
  const user = db.users.find(u => u.id === req.params.userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  if (!db.painelAdmins.includes(user.id)) db.painelAdmins.push(user.id);
  saveDB(db);
  res.json({ ok: true });
});
  
app.delete('/api/admin/admins/:userId', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const db = loadDB();
  db.painelAdmins = (db.painelAdmins || []).filter(id => id !== req.params.userId);
  saveDB(db);
  res.json({ ok: true });
});

// Buscar usuário por username (pra adicionar admin)
app.get('/api/admin/buscar-usuario', (req, res) => {
  if (!checkAdmin(req, res)) return;
  const { q } = req.query;
  const db = loadDB();
  const u = db.users.find(x => x.username.toLowerCase() === (q || '').toLowerCase() || x.email.toLowerCase() === (q || '').toLowerCase());
  if (!u) return res.status(404).json({ error: 'Usuário não encontrado' });
  res.json({ id: u.id, username: u.username, email: u.email, photoUrl: u.photoUrl || null });
});


// ---------- Figurinhas da coleção (aditivo; não altera as APIs existentes) ----------
function figurinhaPublica(s, db) { const autor = db.users.find(u => String(u.id) === String(s.ownerId)); return { id:s.id, ownerId:s.ownerId, authorUsername:autor?.username || 'Usuário', mediaUrl:s.mediaUrl, mimeType:s.mimeType || 'image/*', description:s.description || '', createdAt:s.createdAt, savedAt:s.savedAt || null }; }
app.get('/api/stickers', (req,res) => { const db=loadDB(), userId=String(req.query.userId||''), user=db.users.find(u=>String(u.id)===userId); if(!user) return res.status(404).json({error:'Usuário não encontrado.'}); const all=[...(user.stickers||[]),...(user.savedStickers||[])].filter((s,i,a)=>s&&s.id&&a.findIndex(x=>x.id===s.id)===i); res.json({stickers:all.map(s=>figurinhaPublica(s,db))}); });
app.post('/api/stickers', (req,res) => { const db=loadDB(), {userId,mediaUrl,mimeType,description}=req.body||{}, user=db.users.find(u=>String(u.id)===String(userId)); if(!user||typeof mediaUrl!=='string'||!mediaUrl.startsWith('/uploads/')) return res.status(400).json({error:'Dados da figurinha inválidos.'}); const s={id:uuidv4(),ownerId:user.id,mediaUrl:mediaUrl.slice(0,500),mimeType:String(mimeType||'image/*').slice(0,80),description:String(description||'Minha figurinha').trim().slice(0,80),createdAt:Date.now()}; user.stickers=Array.isArray(user.stickers)?user.stickers:[]; user.stickers.unshift(s); user.stickers=user.stickers.slice(0,200); saveDB(db); res.status(201).json({sticker:figurinhaPublica(s,db)}); });
app.patch('/api/stickers/:id', (req,res) => { const db=loadDB(), user=db.users.find(u=>String(u.id)===String(req.body?.userId)); if(!user) return res.status(404).json({error:'Usuário não encontrado.'}); const s=[...(user.stickers||[]),...(user.savedStickers||[])].find(x=>x.id===req.params.id); if(!s) return res.status(404).json({error:'Figurinha não encontrada.'}); s.description=String(req.body?.description||'').trim().slice(0,80)||'Figurinha'; saveDB(db); res.json({sticker:figurinhaPublica(s,db)}); });
app.delete('/api/stickers/:id', (req,res) => { const db=loadDB(), user=db.users.find(u=>String(u.id)===String(req.body?.userId)); if(!user) return res.status(404).json({error:'Usuário não encontrado.'}); const found=[...(user.stickers||[]),...(user.savedStickers||[])].some(x=>x.id===req.params.id); if(!found) return res.status(404).json({error:'Figurinha não encontrada.'}); user.stickers=(user.stickers||[]).filter(x=>x.id!==req.params.id); user.savedStickers=(user.savedStickers||[]).filter(x=>x.id!==req.params.id); saveDB(db); res.json({ok:true}); });

app.post('/api/stickers/save', (req,res) => {
  const db=loadDB(), {userId,ownerId,description}=req.body||{};
  let mediaUrl = typeof req.body?.mediaUrl === 'string' ? req.body.mediaUrl.trim() : '';
  const user=db.users.find(u=>String(u.id)===String(userId));
  // Aceita caminho relativo ou URL absoluta do próprio Mitto, normalizando para /uploads/.
  try { if (/^https?:\/\//i.test(mediaUrl)) { const parsed = new URL(mediaUrl); const host = String(req.get('host') || '').toLowerCase(); if (parsed.host.toLowerCase() !== host) mediaUrl = ''; else mediaUrl = parsed.pathname + parsed.search; } } catch (_) { mediaUrl = ''; }
  if(!user || !mediaUrl.startsWith('/uploads/') || mediaUrl.includes('..')) return res.status(400).json({error:'Figurinha inválida.'});
  user.savedStickers=Array.isArray(user.savedStickers)?user.savedStickers:[];
  const existing = user.savedStickers.find(x=>x.mediaUrl===mediaUrl);
  if (!existing) user.savedStickers.unshift({id:uuidv4(),ownerId:ownerId||null,mediaUrl:mediaUrl.slice(0,500),mimeType:'image/*',description:String(description||'Figurinha').slice(0,80),createdAt:Date.now(),savedAt:Date.now()});
  saveDB(db); res.status(existing ? 200 : 201).json({ok:true});
});
init()
  .then(() => {
    logarStatusInicialFcm();
    const db = loadDB(); let changed = false;
    for (const u of db.users) {
      // Contas antigas já existentes não devem perder acesso por causa da nova etapa de verificação.
      if (u.emailVerified === undefined) { u.emailVerified = true; changed = true; }
      if (!u.contactNumber) { u.contactNumber = novoNumeroContato(db); changed = true; }
    }
    if (!db.pendingVerifications) { db.pendingVerifications = {}; changed = true; }
    if (changed) saveDB(db);
    server.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('[db] Erro ao inicializar o MongoDB:', err);
    process.exit(1);
  });
